import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from "class-validator";
import { ValidationOptions, Validate } from "class-validator";
import * as validator from "dns-email-validation";

@ValidatorConstraint({ name: "EmailValidator", async: false })
export class EmailValidator implements ValidatorConstraintInterface {
  async validate(value: any, args: ValidationArguments) {
    // Your validation logic goes here
    const isValid = await validator.default.verify(value);
    return isValid.verification;
  }

  defaultMessage(args: ValidationArguments) {
    return "Invalid email format";
  }
}

export function IsValidEmail(validationOptions?: ValidationOptions) {
  return Validate(EmailValidator, validationOptions);
}
