import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
  registerDecorator,
} from "class-validator";

const phoneUtil =
  require("google-libphonenumber").PhoneNumberUtil.getInstance();

@ValidatorConstraint({ name: "isValidPhoneNumber", async: false })
export class IsValidPhoneNumber implements ValidatorConstraintInterface {
  validate(phoneNumber: string, args: ValidationArguments) {
    const countryCodes = args.constraints as string[];
    for (const countryCode of countryCodes) {
      try {
        const parsedNumber = phoneUtil.parseAndKeepRawInput(
          phoneNumber,
          countryCode
        );
        if (phoneUtil.isValidNumber(parsedNumber)) {
          return true;
        }
      } catch (e) {}
    }
    return false;
  }

  defaultMessage(args: ValidationArguments) {
    const countryCodes = args.constraints as string[];
    const countryCodeString =
      countryCodes.length === 1 ? countryCodes[0] : countryCodes.join(", ");
    return `Mobile number is not a valid mobile number.`;
  }
}

export function IsValidPhone(countryCodes?: string[], validationOptions?: any) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: "isValidPhone",
      target: object.constructor,
      propertyName: propertyName,
      constraints: countryCodes,
      options: validationOptions,
      validator: IsValidPhoneNumber,
    });
  };
}
