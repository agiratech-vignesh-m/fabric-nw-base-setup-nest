import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
  registerDecorator,
  ValidationOptions,
} from "class-validator";
import { Injectable } from "@nestjs/common";

@ValidatorConstraint({ name: "dateRange", async: false })
@Injectable()
export class DateRangeValidator implements ValidatorConstraintInterface {
  validate(value: any, args: ValidationArguments) {
    const start_date = args.object["start_date"];
    const end_date = args.object["end_date"];

    return start_date <= end_date;
  }

  defaultMessage(args: ValidationArguments) {
    return "The end date must be after the start date";
  }
}

export function IsDateRangeValid() {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: { message: "The end date must be after the start date" },
      constraints: [],
      validator: DateRangeValidator,
    });
  };
}

@ValidatorConstraint({ name: "isAfterDate", async: false })
export class IsAfterDateConstraint implements ValidatorConstraintInterface {
  validate(value: any, args: any) {
    const [comparisonDate] = args.constraints;
    return new Date(value) instanceof Date && new Date(value) > comparisonDate;
  }

  defaultMessage() {
    return "The date must be after the today date";
  }
}

export function IsAfterDate(
  comparisonDate: Date,
  validationOptions?: ValidationOptions
) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: "isAfterDate",
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [comparisonDate],
      validator: IsAfterDateConstraint,
    });
  };
}
