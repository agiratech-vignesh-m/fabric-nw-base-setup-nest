import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";
// import PhoneNumber from 'libphonenumber-js';

const phoneUtil =
  require("google-libphonenumber").PhoneNumberUtil.getInstance();

@ValidatorConstraint({ name: "isValidPhoneNumber", async: false })
export class IsValidPhoneNumberConstraint
  implements ValidatorConstraintInterface
{
  validate(value: any, args: ValidationArguments) {
    if (typeof value !== "string") {
      return false;
    }
    console.log("value", value);
    const number = `${value}`;
    try {
      const phoneNumber = phoneUtil.parseAndKeepRawInput(number);
      return phoneUtil.isValidNumber(phoneNumber);
    } catch (error) {
      return false;
    }
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} must be a valid phone number with country code`;
  }
}

export function IsValidMobileNumber(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: IsValidPhoneNumberConstraint,
    });
  };
}
