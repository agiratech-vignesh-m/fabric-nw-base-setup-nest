import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from "class-validator";
import * as dotenv from "dotenv";
dotenv.config();

@ValidatorConstraint({ name: "validateAge", async: false })
export class validateAge implements ValidatorConstraintInterface {
  validate(param: Date, args: ValidationArguments) {
    const today = new Date();
    param = new Date(param);

    let age = today.getFullYear() - param.getFullYear();
    const months = today.getMonth() - param.getMonth();
    if (months < 0 || (months === 0 && today.getDate() < param.getDate())) {
      age--;
    }

    const legalAge = Number(process.env.LEGAL_AGE_FOR_DRIVER_LICENSE) || 18;

    return age >= legalAge;
  }

  defaultMessage(args: ValidationArguments) {
    return "Driver is not old enough to have Driver Licence";
  }
}
