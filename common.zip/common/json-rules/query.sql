-- Permission Query

INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('07151cf9-f715-4f88-93ca-657369c34272', 'edit', 'fleet_operator_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('1c66c100-2309-4756-8c8d-55d9ea709ba5', 'kyc', 'verification', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('2825e93a-40f5-41a7-a33e-c19fc2d7a556', 'create', 'vehicle', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('4865046c-0823-4092-824a-2084cbf9742a', 'create', 'plugin', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('55545ba8-3510-4299-9bc5-36c656c71334', 'delete', 'vehicle_owner_house', '2023-12-15 19:34:07.815510', '2023-12-15 19:34:07.815510');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('6542388e-819e-4350-9515-ccae7e3d2114', 'entra', 'company_verification', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('6d50cf75-8616-4843-862e-e1eb5656f86e', 'self', 'vehicle_owner', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('72905f66-0c17-4807-9f07-bd22598918ba', 'view', 'plugin', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('75ff2e39-0974-4e97-a468-c52255967eae', 'delete', 'vehicle_permit', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('7bb34180-6874-42a7-b2a5-57289c06f5cd', 'self', 'driver', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('7fb1b08f-08d9-430f-b01d-835ef0a04350', 'view', 'vehicle', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('837f2ac1-3052-4795-84d8-4ff5bd724225', 'others', 'vehicle_owner', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('86a54384-c25b-4f72-a330-d4ecb48b7a0b', 'others', 'service_provider', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('89b2892d-9f91-4b8b-a270-09c61072f28d', 'delete', 'service_provider_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('8b5dcce8-b4b1-4e6d-9e10-5014c9ad3da6', 'view', 'fleet_operator_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('9121f72e-e2b3-4f61-81f3-4df63ba217cf', 'others', 'fleet_operator', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('92abe80f-eb35-41f6-9300-e49cc73c2123', 'delete', 'fleet_operator_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('a4a6354a-86fa-4505-904b-8837e0d07dde', 'delete', 'agent_house', '2023-12-15 17:06:55.995977', '2023-12-15 17:06:55.995977');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('bc72479c-edd7-492d-b1e4-8d940baa125e', 'view', 'vehicle_permit', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('bd7a721f-5324-440a-8638-fe30fb257953', 'edit', 'agent_house', '2023-12-15 17:06:55.995977', '2023-12-15 17:06:55.995977');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('c1906ce2-5701-4471-a205-8697a652a8b2', 'self', 'fleet_operator', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('c4b456ad-b6a5-4da5-8886-4af4edfd22f8', 'approve', 'vehicle_owner_house', '2023-12-15 19:34:07.815510', '2023-12-15 19:34:07.815510');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('c9f3e1c4-9872-4b5b-851e-458572536694', 'kyb', 'company_verification', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('ce0af358-8ea5-46ad-bca1-1d7c4c395dfd', 'edit', 'vehicle', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('d6103393-00ea-483c-afa2-5d0c410592c3', 'self', 'service_provider', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('d69f170c-b017-49ec-901c-2d8903d73973', 'self', 'service_agent', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('d745cdc1-8422-4015-8ad1-01a2bcdf9814', 'profile', 'verification', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('d82c1d96-b30c-46f4-9ce6-c5399a4f5e5c', 'edit', 'vehicle_permit', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('daa633a5-243e-4d8e-a29f-c8d2afb60ad2', 'delete', 'plugin', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('db400083-aea0-4344-a17d-338aa88bd40d', 'edit', 'plugin', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('dbedc586-4f3c-4e50-9e11-1982ff968021', 'delete', 'vehicle', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('e0fdf2a6-0b46-431e-b8ce-deb2a38361bb', 'others', 'driver', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('e44d259b-5349-4bd2-87f2-36b6b6e2d785', 'create', 'vehicle_permit', '2023-12-15 16:00:24.319326', '2023-12-15 16:00:24.319326');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('e4f0abb8-6423-4e81-aeba-2ecb70f2b8fa', 'edit', 'vehicle_owner_house', '2023-12-15 19:34:07.815510', '2023-12-15 19:34:07.815510');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('e86d6e87-775a-45ce-aca8-e6ef1fe3ca72', 'approve', 'agent_house', '2023-12-15 17:06:55.995977', '2023-12-15 17:06:55.995977');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('ebd0e2c8-9d5f-4000-b1e0-bd7196ca163f', 'view', 'agent_house', '2023-12-15 17:06:55.995977', '2023-12-15 17:06:55.995977');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('f3d7ca9e-7a06-49ca-8a8f-459d64289c24', 'approve', 'fleet_operator_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('f4e762dc-b9d7-4a92-ad29-ff18be7d5f5c', 'view', 'vehicle_owner_house', '2023-12-15 19:34:07.815510', '2023-12-15 19:34:07.815510');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('f7da89d2-ac2e-45a4-bfc2-86c4568f568a', 'approve', 'service_provider_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('fc6a4fe2-679b-415d-bf17-06877873d0af', 'view', 'service_provider_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('fc93dd10-29fb-4515-9b11-f8b4211cea94', 'edit', 'service_provider_house', '2023-12-15 18:08:37.399370', '2023-12-15 18:08:37.399370');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('0d8211f0-4799-4dd1-9b9d-b9eba25243fd', 'list', 'vehicle_permit', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('10fd903f-22bf-4b86-add8-44044fb6d815', 'list', 'agent_house', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('31e11779-b09d-422a-b1e2-9afd75cc8e5b', 'list', 'plugin', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('4d9ac5e0-03f1-4234-8541-d1e6d3e766c7', 'list', 'service_provider_house', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('576465e7-36bb-4dd3-b21f-d177ceb05b6d', 'list', 'fleet_operator_house', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('65e111a0-2482-4cb3-a32f-d21e4b4c66b4', 'list', 'vehicle', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');
INSERT INTO digital_credentials.permissions
(id, permission, module, created_at, updated_at)
VALUES('99136362-5cc0-4c86-8b53-94f31183b32c', 'list', 'vehicle_owner_house', '2023-12-27 11:11:41.712274', '2023-12-27 11:11:41.712274');


-- Role query

INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'service_provider', '2023-12-20 14:29:58.571255', '2023-12-20 14:29:58.571255');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'driver', '2023-12-20 14:29:58.553408', '2023-12-20 14:29:58.553408');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('41d5724e-6d04-404d-bc35-6fa6a55f70c8', 'app', '2023-12-20 14:29:58.579227', '2023-12-20 14:29:58.579227');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('5bac58ce-48b5-475c-b57c-af40831a9fa8', 'admin', '2023-12-20 14:29:58.539896', '2023-12-20 14:29:58.539896');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('777eac94-36f7-40e1-8b4d-d2de1da79148', 'common', '2023-12-20 14:29:58.575247', '2023-12-20 14:29:58.575247');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'vehicle_owner', '2023-12-20 14:29:58.566943', '2023-12-20 14:29:58.566943');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'fleet_operator', '2023-12-20 14:29:58.562595', '2023-12-20 14:29:58.562595');
INSERT INTO digital_credentials.`role`
(id, name, created_at, updated_at)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'agent', '2023-12-20 14:29:58.559040', '2023-12-20 14:29:58.559040');


-- Role permission mapping query

INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '0d8211f0-4799-4dd1-9b9d-b9eba25243fd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '2825e93a-40f5-41a7-a33e-c19fc2d7a556');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '31e11779-b09d-422a-b1e2-9afd75cc8e5b');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '4865046c-0823-4092-824a-2084cbf9742a');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '4d9ac5e0-03f1-4234-8541-d1e6d3e766c7');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '65e111a0-2482-4cb3-a32f-d21e4b4c66b4');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '72905f66-0c17-4807-9f07-bd22598918ba');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '75ff2e39-0974-4e97-a468-c52255967eae');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '7fb1b08f-08d9-430f-b01d-835ef0a04350');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', '89b2892d-9f91-4b8b-a270-09c61072f28d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'bc72479c-edd7-492d-b1e4-8d940baa125e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'ce0af358-8ea5-46ad-bca1-1d7c4c395dfd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'd6103393-00ea-483c-afa2-5d0c410592c3');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'd82c1d96-b30c-46f4-9ce6-c5399a4f5e5c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'daa633a5-243e-4d8e-a29f-c8d2afb60ad2');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'db400083-aea0-4344-a17d-338aa88bd40d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'dbedc586-4f3c-4e50-9e11-1982ff968021');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'e44d259b-5349-4bd2-87f2-36b6b6e2d785');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'f7da89d2-ac2e-45a4-bfc2-86c4568f568a');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'fc6a4fe2-679b-415d-bf17-06877873d0af');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('0a5f2ac7-58a5-45bb-9ed8-2309a93d6a4a', 'fc93dd10-29fb-4515-9b11-f8b4211cea94');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '0d8211f0-4799-4dd1-9b9d-b9eba25243fd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '2825e93a-40f5-41a7-a33e-c19fc2d7a556');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '31e11779-b09d-422a-b1e2-9afd75cc8e5b');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '4865046c-0823-4092-824a-2084cbf9742a');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '65e111a0-2482-4cb3-a32f-d21e4b4c66b4');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '72905f66-0c17-4807-9f07-bd22598918ba');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '75ff2e39-0974-4e97-a468-c52255967eae');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '7bb34180-6874-42a7-b2a5-57289c06f5cd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', '7fb1b08f-08d9-430f-b01d-835ef0a04350');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'bc72479c-edd7-492d-b1e4-8d940baa125e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'ce0af358-8ea5-46ad-bca1-1d7c4c395dfd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'd82c1d96-b30c-46f4-9ce6-c5399a4f5e5c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'daa633a5-243e-4d8e-a29f-c8d2afb60ad2');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'db400083-aea0-4344-a17d-338aa88bd40d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'dbedc586-4f3c-4e50-9e11-1982ff968021');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('4154b6f3-f43d-49fa-b7f7-4d440860ba2f', 'e44d259b-5349-4bd2-87f2-36b6b6e2d785');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('777eac94-36f7-40e1-8b4d-d2de1da79148', '1c66c100-2309-4756-8c8d-55d9ea709ba5');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('777eac94-36f7-40e1-8b4d-d2de1da79148', '6542388e-819e-4350-9515-ccae7e3d2114');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('777eac94-36f7-40e1-8b4d-d2de1da79148', 'c9f3e1c4-9872-4b5b-851e-458572536694');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('777eac94-36f7-40e1-8b4d-d2de1da79148', 'd745cdc1-8422-4015-8ad1-01a2bcdf9814');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '0d8211f0-4799-4dd1-9b9d-b9eba25243fd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '2825e93a-40f5-41a7-a33e-c19fc2d7a556');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '31e11779-b09d-422a-b1e2-9afd75cc8e5b');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '4865046c-0823-4092-824a-2084cbf9742a');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '55545ba8-3510-4299-9bc5-36c656c71334');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '65e111a0-2482-4cb3-a32f-d21e4b4c66b4');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '6d50cf75-8616-4843-862e-e1eb5656f86e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '72905f66-0c17-4807-9f07-bd22598918ba');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '75ff2e39-0974-4e97-a468-c52255967eae');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '7fb1b08f-08d9-430f-b01d-835ef0a04350');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', '99136362-5cc0-4c86-8b53-94f31183b32c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'bc72479c-edd7-492d-b1e4-8d940baa125e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'c4b456ad-b6a5-4da5-8886-4af4edfd22f8');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'ce0af358-8ea5-46ad-bca1-1d7c4c395dfd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'd82c1d96-b30c-46f4-9ce6-c5399a4f5e5c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'daa633a5-243e-4d8e-a29f-c8d2afb60ad2');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'db400083-aea0-4344-a17d-338aa88bd40d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'dbedc586-4f3c-4e50-9e11-1982ff968021');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'e44d259b-5349-4bd2-87f2-36b6b6e2d785');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'e4f0abb8-6423-4e81-aeba-2ecb70f2b8fa');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('806424e4-52d3-4b33-a5e2-c889aa1c1209', 'f4e762dc-b9d7-4a92-ad29-ff18be7d5f5c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '07151cf9-f715-4f88-93ca-657369c34272');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '0d8211f0-4799-4dd1-9b9d-b9eba25243fd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '2825e93a-40f5-41a7-a33e-c19fc2d7a556');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '31e11779-b09d-422a-b1e2-9afd75cc8e5b');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '4865046c-0823-4092-824a-2084cbf9742a');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '576465e7-36bb-4dd3-b21f-d177ceb05b6d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '65e111a0-2482-4cb3-a32f-d21e4b4c66b4');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '72905f66-0c17-4807-9f07-bd22598918ba');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '75ff2e39-0974-4e97-a468-c52255967eae');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '7fb1b08f-08d9-430f-b01d-835ef0a04350');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '8b5dcce8-b4b1-4e6d-9e10-5014c9ad3da6');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', '92abe80f-eb35-41f6-9300-e49cc73c2123');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'bc72479c-edd7-492d-b1e4-8d940baa125e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'c1906ce2-5701-4471-a205-8697a652a8b2');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'ce0af358-8ea5-46ad-bca1-1d7c4c395dfd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'd82c1d96-b30c-46f4-9ce6-c5399a4f5e5c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'daa633a5-243e-4d8e-a29f-c8d2afb60ad2');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'db400083-aea0-4344-a17d-338aa88bd40d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'dbedc586-4f3c-4e50-9e11-1982ff968021');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'e44d259b-5349-4bd2-87f2-36b6b6e2d785');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('8542fc7b-2520-4318-97f5-efc13abc20eb', 'f3d7ca9e-7a06-49ca-8a8f-459d64289c24');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '0d8211f0-4799-4dd1-9b9d-b9eba25243fd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '10fd903f-22bf-4b86-add8-44044fb6d815');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '2825e93a-40f5-41a7-a33e-c19fc2d7a556');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '31e11779-b09d-422a-b1e2-9afd75cc8e5b');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '4865046c-0823-4092-824a-2084cbf9742a');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '65e111a0-2482-4cb3-a32f-d21e4b4c66b4');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '6d50cf75-8616-4843-862e-e1eb5656f86e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '72905f66-0c17-4807-9f07-bd22598918ba');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '7bb34180-6874-42a7-b2a5-57289c06f5cd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '7fb1b08f-08d9-430f-b01d-835ef0a04350');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '837f2ac1-3052-4795-84d8-4ff5bd724225');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '86a54384-c25b-4f72-a330-d4ecb48b7a0b');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', '9121f72e-e2b3-4f61-81f3-4df63ba217cf');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'a4a6354a-86fa-4505-904b-8837e0d07dde');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'bc72479c-edd7-492d-b1e4-8d940baa125e');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'bd7a721f-5324-440a-8638-fe30fb257953');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'c1906ce2-5701-4471-a205-8697a652a8b2');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'ce0af358-8ea5-46ad-bca1-1d7c4c395dfd');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'd6103393-00ea-483c-afa2-5d0c410592c3');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'd69f170c-b017-49ec-901c-2d8903d73973');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'd82c1d96-b30c-46f4-9ce6-c5399a4f5e5c');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'db400083-aea0-4344-a17d-338aa88bd40d');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'e0fdf2a6-0b46-431e-b8ce-deb2a38361bb');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'e44d259b-5349-4bd2-87f2-36b6b6e2d785');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'e86d6e87-775a-45ce-aca8-e6ef1fe3ca72');
INSERT INTO digital_credentials.role_permissions_permissions
(roleId, permissionsId)
VALUES('a7f4eb60-4461-4689-8f26-c1107db0c5ee', 'ebd0e2c8-9d5f-4000-b1e0-bd7196ca163f');


-- Services list

INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('1eaf1c12-8165-4027-9f7e-15b3fb3b5e3c', 'Dongle / OBD', 0, 0, 0, 0, 1, '2023-12-22 13:25:01.667721', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('8e63ccd0-77fd-46a9-883b-b2c4f9027a0a', 'Service Provider', 0, 1, 1, 1, 0, '2023-12-22 13:25:01.655245', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('9e2184c6-c8c1-4bd1-9c82-84fe8faca9b2', 'Driver', 0, 1, 1, 1, 0, '2023-12-22 13:25:01.652606', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('bda4366a-33d7-4fb3-adee-687f0c3167b6', 'Fleet Operator', 0, 1, 1, 1, 0, '2023-12-22 13:25:01.658496', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('c023a6e5-5d71-4fdc-abee-10f81c9b2986', 'Agent', 0, 1, 1, 1, 0, '2023-12-22 13:25:01.649713', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('e0a143dc-b531-4fa4-9416-3a5cbf22f4e4', 'Vehicle Owner', 0, 0, 0, 0, 0, '2023-12-22 13:25:01.660365', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('e4349887-3d0d-4181-8934-520efb6036bd', 'Vehicle Permit', 0, 0, 0, 0, 1, '2023-12-22 13:25:01.665514', NULL);
INSERT INTO digital_credentials.service
(id, name, has_child, has_self, has_others, is_self_required, is_object, updated_at, parentId)
VALUES('edb99097-1c50-470a-a7d9-7ed9a5af5499', 'Vehicle', 0, 0, 0, 0, 1, '2023-12-22 13:25:01.663160', NULL);