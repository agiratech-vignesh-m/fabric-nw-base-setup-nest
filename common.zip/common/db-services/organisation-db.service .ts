import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { Organisation } from '../entities/organisation.entity';

@Injectable()
export class OrganisationDbService {
  constructor(
    @InjectRepository(Organisation)
    private organisationRepository: Repository<Organisation>,
  ) {}

  async createOrganisationName(query: any):Promise<Organisation> {
    try {
      return this.organisationRepository.save(query);
    } catch (err) {
      throw new BadGatewayException(error.organisationCreateError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getOrganisationDetails(query:any):Promise<Organisation[]> {
    try {
      return this.organisationRepository.find(query);
    } catch (err) {
      throw new BadRequestException(error.getOrganisationError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getOrganisationData(query:any):Promise<Organisation> {
    try {
      return this.organisationRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.getOrganisationError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
