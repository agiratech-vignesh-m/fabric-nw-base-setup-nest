import { BadRequestException, Injectable } from '@nestjs/common';
import { ElasticsearchService } from '@nestjs/elasticsearch';
import { error,success } from '../config/db-yaml.config';
import { PaginationDto } from './dto/pagination.dto';
import { MessageResponse } from './dto/message-respons.dto';

@Injectable()
export class ElasticSearchDbService {
  constructor(
    private elasticsearchService: ElasticsearchService,
  ) {}

  async createIndex(index: string, body: any): Promise<any> {
    try {
      const payload = { index, body };
      const result = await this.elasticsearchService.index(payload);
      return result;
    } catch (err) {
      throw new BadRequestException(error.elasticSearchDataUploadError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async insertBulkData(index: string, data: any[]): Promise<any> {
    try {
      const body = data.flatMap((doc) => [{ index: { _index: index } }, doc]);
      return this.elasticsearchService.bulk({ index, body });
    } catch (err) {
      throw new BadRequestException(error.elasticSearchDataUploadError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async dataSearch(index: string, query: any): Promise<any> {
    try {
      const searchPayload = { index, body: query };
      const res: any = await this.elasticsearchService.search(searchPayload);
      const hits = res?.hits?.hits || [];
      const totalCount = res?.hits?.total?.value;

      const data = hits.map(({ _id, _source, highlight }) => {
        return { _id, ..._source, ...highlight };
      });

      const response: any = {
        data: [],
        totalCount: 0,
      };
      response.data = data;
      response.totalCount = totalCount;

      return response;
    } catch (err) {      
      let description: string;
      if (err?.meta?.body?.error?.reason === `no such index [${index}]`) {
        description = error.driverDataNotFoundInES;
      } else if (err?.message) {
        description = err?.message;
      } else {
        description = err;
      }

      throw new BadRequestException(description, {
        cause: new Error(),
        description: error.elasticSearchDataFetchError,
      });
    }
  }

  async count(): Promise<any> {
    try {
      return await this.elasticsearchService.count();
    } catch (err) {
      throw new BadRequestException(error.elasticSearchDataFetchError, {
        cause: new Error(),
        description: err?.message,
      });
    }
  }

  async deleteIndex(index: string): Promise<any> {
    try {
      const result = await this.elasticsearchService.deleteByQuery({
        index,
        body: {
          query: {
            match_all: {},
          },
        },
      });
      return result;
    } catch (err) {
      let description: string;
      if (err?.meta?.body?.error?.reason === `no such index [${index}]`) {
        description = error.driverDataNotFoundInES;
      } else if (err?.message) {
        description = err?.message;
      } else {
        description = err;
      }
      throw new BadRequestException(error.elasticSearchDeleteIndexError, {
        cause: new Error(),
        description: description,
      });
    }
  }

  async doesIndexExist(indexName: string): Promise<boolean> {
    try {
      const body = await this.elasticsearchService.indices.exists({
        index: indexName,
      });

      return body;
    } catch (err) {
      throw new BadRequestException(error.elasticSearchGetIsIndexExistError, {
        cause: new Error(),
        description: err?.message,
      });
    }
  }

/*
Fetch new york nyc open data from elastic search methods
*/

  changeWordToCamelCase(words: string) {
    const arr = words?.toLocaleLowerCase()?.split(' ');

    for (var i = 0; i < arr?.length; i++) {
      arr[i] = arr[i]?.charAt(0)?.toUpperCase() + arr[i]?.slice(1);
    }

    return arr?.join(' ');
  }

  //1. New York Drivers
  async fetchNewYorkDriversFromES(
    driver_index: string,
    params: PaginationDto,
  ): Promise<MessageResponse> {
    try {
      let { name, hack_license_number, sort, sort_by, page, limit } = params;
      sort = sort != undefined || sort != null ? sort : 'asc';
      page = page != undefined || page != null ? +page : 1;
      limit = limit != undefined || limit != null ? +limit : 20;

      let shouldQuery: any[] = [];
      const sortQuery: any[] = [];
      let query: any;

      if (name) {
        shouldQuery = [
          {
            wildcard: {
              'firstname.keyword': `*${name?.toUpperCase()}*`,
            },
          },
          {
            wildcard: {
              'middlename.keyword': `*${name?.toUpperCase()}*`,
            },
          },
          {
            wildcard: {
              'lastname.keyword': `*${name?.toUpperCase()}*`,
            },
          },
        ];
      }

      if (sort_by === 'firstname') {
        sortQuery.push({
          'firstname.keyword': {
            order: sort,
            unmapped_type: 'keyword',
            missing: '_last',
          },
        });
      } else if (sort_by === 'middlename') {
        sortQuery.push({
          'middlename.keyword': {
            order: sort,
            unmapped_type: 'keyword',
            missing: '_last',
          },
        });
      } else if (sort_by === 'lastname') {
        sortQuery.push({
          'lastname.keyword': {
            order: sort,
            unmapped_type: 'keyword',
            missing: '_last',
          },
        });
      }

      if (name && !hack_license_number) {
        query = {
          query: {
            bool: {
              should: shouldQuery,
            },
          },
          from: (page - 1) * limit,
          size: limit,
          sort: sortQuery,
        };
      } else if (!name && hack_license_number) {
        query = {
          query: {
            bool: {
              should: {
                wildcard: {
                  hack_license_number: `*${hack_license_number}*`,
                },
              },
            },
          },
          from: (page - 1) * limit,
          size: limit,
          sort: sortQuery,
        };
      } else if (name && hack_license_number) {
        query = {
          query: {
            bool: {
              must: {
                wildcard: {
                  hack_license_number: `*${hack_license_number}*`,
                },
              },
              should: shouldQuery,
              minimum_should_match: 1,
            },
          },
          from: (page - 1) * limit,
          size: limit,
          sort: sortQuery,
        };
      } else {
        query = {
          query: { match_all: {} },
          from: (page - 1) * limit,
          size: limit,
          sort: [
            {
              'firstname.keyword': {
                order: sort,
                unmapped_type: 'keyword',
                missing: '_last',
              },
            },
          ],
        };
      }

      const result = await this.dataSearch(
        driver_index,
        query,
      );

      const pagination = {
        totalCount: result?.totalCount,
        totalPages: Math.ceil(result?.data?.length / limit),
      };

      const driverData = result?.data?.map((data) => {
        data.firstname = this.changeWordToCamelCase(data?.firstname);
        data.middlename = this.changeWordToCamelCase(data?.middlename);
        data.lastname = this.changeWordToCamelCase(data?.lastname);
        return data;
      });

      return {
        message: success.getLeagcyDriversDataSuccess,
        data: { driverData, ...pagination },
      };
    } catch (error) {
      console.error(`${error.getLegacyDriversListError} :`, error);
    }
  }

  //2. New York Vehicles
  async fetchNewYorkVehiclesFromES(
    vehicleIndexName: string,
    params: PaginationDto,
  ): Promise<MessageResponse> {
    try {
      let {
        vehicle_identification_number,
        number_plate,
        sort,
        sort_by,
        page,
        limit,
      } = params;

      sort = sort != undefined || sort != null ? sort : 'asc';
      sort_by = sort_by != undefined || sort_by != null ? sort_by : '';
      page = page != undefined || page != null ? +page : 1;
      limit = limit != undefined || limit != null ? +limit : 20;

      let query: any;

      if (vehicle_identification_number && !number_plate) {
        query = {
          query: {
            bool: {
              must: {
                wildcard: {
                  'vehicle_identification_number.keyword': `*${vehicle_identification_number}*`,
                },
              },
            },
          },
          from: (page - 1) * limit,
          size: limit,
        };
      } else if (!vehicle_identification_number && number_plate) {
        query = {
          query: {
            bool: {
              must: {
                wildcard: {
                  'number_plate.keyword': `*${number_plate}*`,
                },
              },
            },
          },
          from: (page - 1) * limit,
          size: limit,
        };
      } else if (vehicle_identification_number && number_plate) {
        query = {
          query: {
            bool: {
              must: [
                {
                  wildcard: {
                    'vehicle_identification_number.keyword': `*${vehicle_identification_number}*`,
                  },
                },
                {
                  wildcard: {
                    'number_plate.keyword': `*${number_plate}*`,
                  },
                },
              ],
            },
          },
          from: (page - 1) * limit,
          size: limit,
        };
      } else {
        query = {
          query: { match_all: {} },
          from: (page - 1) * limit,
          size: limit,
        };
      }

      const result = await this.dataSearch(
        vehicleIndexName,
        query,
      );

      const vehicleData = result?.data;

      const pagination = {
        totalCount: result?.totalCount,
        totalPages: Math.ceil(result?.data?.length / limit),
      };

      return {
        message: success.getLeagcyVehiclesDataSuccess,
        data: { vehicleData, ...pagination },
      };
    } catch (error) {
      console.error(`${error.getLegacyVehiclesListError} :`, error);
    }
  }

  //3. New York Fleet Operators
  async fetchNewYorkFleetOperatorFromES(
    nykFleetOperatorIndexName: string,
    params: PaginationDto,
  ): Promise<MessageResponse> {
    try {
      let { sort, sort_by, page, limit } = params;
      sort = sort != undefined || sort != null ? sort : 'asc';
      page = page != undefined || page != null ? +page : 1;
      limit = limit != undefined || limit != null ? +limit : 20;

      const query: any = {
        query: { match_all: {} },
        from: (page - 1) * limit,
        size: limit,
        sort: [
          {
            'account_name.keyword': {
              order: sort,
              unmapped_type: 'keyword',
              missing: '_last',
            },
          },
        ],
      };

      const result = await this.dataSearch(
        nykFleetOperatorIndexName,
        query,
      );

      const pagination = {
        totalCount: result?.totalCount,
        totalPages: Math.ceil(result?.data?.length / limit),
      };

      const fleetOperatorsData = result?.data;

      return {
        message: success.getFleetOperatorDataSuccess,
        data: { fleetOperatorsData, ...pagination },
      };
    } catch (error) {
      console.error(`${error.getLegacyFleetOperatorsListError} :`, error);
    }
  }

  //4. New York Vehicle Owners
  async fetchNewYorkVehicleOwnersFromES(
    nykVehicleOwnersIndexName: string,
    params: PaginationDto,
  ): Promise<MessageResponse> {
    try {
      let { sort, sort_by, page, limit } = params;
      sort = sort ? sort : 'asc';
      page = page ? +page : 1;
      limit = limit ? +limit : 20;

      const query: any = {
        query: { match_all: {} },
        from: (page - 1) * limit,
        size: limit,
        sort: [
          {
            'first_name.keyword': {
              order: sort,
              unmapped_type: 'keyword',
              missing: '_last',
            },
          },
        ],
      };

      const result = await this.dataSearch(
        nykVehicleOwnersIndexName,
        query,
      );

      const pagination = {
        totalCount: result?.totalCount,
        totalPages: Math.ceil(result?.data?.length / limit),
      };

      const vehicleOwnersData = result?.data;

      return {
        message: success.getVehicleOwnersDataSuccess,
        data: { vehicleOwnersData, ...pagination },
      };
    } catch (error) {
      console.error(`${error.getLegacyVehicleOwnersListError} :`, error);
    }
  }

  //5. New York Service Provider Attorney
  async fetchNewYorkServiceProviderAttorneyFromES(
    serviceProviderAttorneyIndexName: string,
    params: PaginationDto,
  ): Promise<MessageResponse> {
    try {
      let { sort, sort_by, page, limit } = params;
      sort = sort ? sort : 'asc';
      page = page ? +page : 1;
      limit = limit ? +limit : 20;

      const query: any = {
        query: { match_all: {} },
        from: (page - 1) * limit,
        size: limit,
        sort: [
          {
            'first_name.keyword': {
              order: sort,
              unmapped_type: 'keyword',
              missing: '_last',
            },
          },
        ],
      };

      const result = await this.dataSearch(
        serviceProviderAttorneyIndexName,
        query,
      );

      const pagination = {
        totalCount: result?.totalCount,
        totalPages: Math.ceil(result?.data?.length / limit),
      };

      const serviceProviderAttorneyData = result?.data;

      return {
        message: success.getServiceProviderAttorneyDataSuccess,
        data: { serviceProviderAttorneyData, ...pagination },
      };
    } catch (error) {
      console.error(
        `${error.getLegacyServiceProviderAttorneyDataListError} :`,
        error,
      );
    }
  }

  //6. New York Vehicle Permit
  async fetchNewYorkVehiclePermitsFromES(
    vehiclePermitIndexName: string,
    params: PaginationDto,
  ): Promise<MessageResponse> {
    try {
      let { sort, sort_by, page, limit } = params;
      sort = sort ? sort : 'asc';
      page = page ? +page : 1;
      limit = limit ? +limit : 20;

      const query: any = {
        query: { match_all: {} },
        from: (page - 1) * limit,
        size: limit,
        sort: [
          {
            'name.keyword': {
              order: sort,
              unmapped_type: 'keyword',
              missing: '_last',
            },
          },
        ],
      };

      const result = await this.dataSearch(
        vehiclePermitIndexName,
        query,
      );

      const pagination = {
        totalCount: result?.totalCount,
        totalPages: Math.ceil(result?.data?.length / limit),
      };

      const vehiclePermitData = result?.data;

      return {
        message: success.getVehiclePermitDataSuccess,
        data: { vehiclePermitData, ...pagination },
      };
    } catch (error) {
      console.error(`${error.getLegacyVehiclePermitDataListError} :`, error);
    }
  }
}
