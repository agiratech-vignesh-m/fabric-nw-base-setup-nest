import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedFleet } from 'src/common/entities/deleted_fleet.entity';

@Injectable()
export class DeletedFleetDbService {
  constructor(
    @InjectRepository(DeletedFleet)
    private deletedFleetRepository: Repository<DeletedFleet>,
  ) {}

  async createDeletedFleet(payload: any): Promise<DeletedFleet> {
    try {
      return await this.deletedFleetRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedFleetError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }
}
