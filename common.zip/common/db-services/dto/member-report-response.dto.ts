import { IsNumber, IsOptional, IsString } from 'class-validator';

export class MemberRportResponseDto {
  @IsOptional()
  @IsString()
  message?:string

  @IsOptional()
  reports?:ReportResponseDto  
}

export class ReportResponseDto {
  @IsOptional()
  @IsNumber()
  toalUserDoucumentsCount?: number;

  @IsOptional()
  @IsNumber()
  userDoucumentsWeeklyCount?: number;
}
