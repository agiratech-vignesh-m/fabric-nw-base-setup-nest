import { IsOptional, IsString } from 'class-validator';
import { UsePipes, ValidationPipe } from '@nestjs/common';

@UsePipes(new ValidationPipe({ skipMissingProperties: true }))
export class MessageResponse {
  @IsOptional()
  @IsString()
  message?: string;

  @IsOptional()
  data? : any;
}
