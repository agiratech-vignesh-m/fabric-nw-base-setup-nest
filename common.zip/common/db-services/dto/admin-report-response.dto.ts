import { IsNumber, IsOptional, IsString } from 'class-validator';

export class AdminRportResponseDto {
  @IsOptional()
  @IsString()
  message?:string

  @IsOptional()
  reports?:ReportsResponseDto  
}
export class ReportsResponseDto {
  @IsOptional()
  @IsString()
  message?:string

  @IsOptional()
  @IsNumber()
  totalDriversCount?: number;

  @IsOptional()
  @IsNumber()
  totalBrokersCount?: number;

  @IsOptional()
  @IsNumber()
  totalFleetsCount?: number;
  
  @IsOptional()
  @IsNumber()
  totalVehiclesCount?: number;
  
  @IsOptional()
  @IsNumber()
  totalTemplatesCount?: number;

  @IsOptional()
  @IsNumber()
  totalSharedWithCount?: number;

  @IsOptional()
  @IsNumber()
  driversWeeklyCount?: number;

  @IsOptional()
  @IsNumber()
  brokersWeeklyCount?: number;

  @IsOptional()
  @IsNumber()
  fleetsWeeklyCount?: number;
  
  @IsOptional()
  @IsNumber()
  vehiclesWeeklyCount?: number;  
  
  @IsOptional()
  @IsNumber()
  templatesWeeklyCount?: number;

  @IsOptional()
  @IsNumber()
  sharedWithWeeklyCount?: number;
}
