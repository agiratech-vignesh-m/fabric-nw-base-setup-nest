import { IsNumber, IsOptional, IsString } from 'class-validator';

export class AgentRportResponseDto {
  @IsOptional()
  @IsString()
  message?:string

  @IsOptional()
  reports?:ReportResponseDto  
}

export class ReportResponseDto {

  @IsOptional()
  @IsNumber()
  totalMembersCount?: number;

  @IsOptional()
  @IsNumber()
  membersWeeklyCount?: number;
   
  @IsOptional()
  @IsNumber()
  totalFleetsCount?: number;

  @IsOptional()
  @IsNumber()
  fleetsWeeklyCount?: number;

  @IsOptional()
  @IsNumber()
  totalVehcilesCount?: number;

  @IsOptional()
  @IsNumber()
  vehiclesWeeklyCount?: number;

  @IsOptional()
  @IsNumber()
  toalUserDoucumentsCount?: number;

  @IsOptional()
  @IsNumber()
  userDoucumentsWeeklyCount?: number;

  @IsOptional()
  @IsNumber()
  totalSharedWithCount?: number;

  @IsOptional()
  @IsNumber()
  sharedWithWeeklyCount?: number;
}
