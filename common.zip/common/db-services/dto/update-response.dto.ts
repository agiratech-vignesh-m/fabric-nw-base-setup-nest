export class UpdateResponseDto {
  affected?: number;
  raw?: any;
  generatedMaps?: any[];
}
