import { IsInt, IsString, IsOptional, Min, IsBoolean } from "class-validator";

export class PaginationDto {
  @IsOptional()
  limit: number;

  @IsOptional()
  page: number;

  @IsOptional()
  @IsString()
  search: string;

  @IsOptional()
  @IsString()
  sort:string

  @IsOptional()
  @IsString()
  sort_by:string

  @IsOptional()
  @IsString()
  isMyDocument:string

  //driver fields
  @IsOptional()
  @IsString()
  name: string;

  @IsOptional()
  @IsString()
  hack_license_number: string;

  //vehicle fields
  @IsOptional()
  @IsString()
  vehicle_identification_number:string

  @IsOptional()
  @IsString()
  number_plate:string
}
