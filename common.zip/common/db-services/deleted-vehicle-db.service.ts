import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedVehicle } from 'src/common/entities/deleted_vehicle.entity';

@Injectable()
export class DeletedVehicleDbService {
  constructor(
    @InjectRepository(DeletedVehicle)
    private deletedVehicleRepository: Repository<DeletedVehicle>,
  ) {}

  async createDeletedVehicle(payload: any): Promise<DeletedVehicle> {
    try {
      return await this.deletedVehicleRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedVehicleError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }
}
