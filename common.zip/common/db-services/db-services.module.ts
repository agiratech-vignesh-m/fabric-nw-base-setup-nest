import { Module } from "@nestjs/common";
import { UserDbService } from "./user-db.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { JwtModule } from "@nestjs/jwt";
import { VehicleDbService } from "./vehicle-db.service";
import { UserDocumentDbService } from "./user-document-db.service";
import { DeletedUserDbService } from "./deleted-user-db.service";
import { DeletedVehicleDbService } from "./deleted-vehicle-db.service";
import { DeletedUserDocumentDbService } from "./deleted-user-document-db.service";
import { TemplateNameDbService } from "./template-name-db.service";
import { AdminTemplateDbService } from "./admin-template-db.service";
import { FleetDbService } from "./fleet-db.service";
import { DeletedAdminTemplateDbService } from "./deleted-admin-template-db.service";
import { AgentDbService } from "./agent-db.service";
import { DeletedAgentDbService } from "./deleted-agent-db.service";
import { Broker } from "src/common/entities/agent.entity";
import { DeletedBroker } from "src/common/entities/deleted_agent.entity";
import { UserDocument } from "src/common/entities/user-document.entity";
import { DeletedUser } from "src/common/entities/deleted-user.entity";
import { DeletedTemplateName } from "src/common/entities/deleted_template_name.entity";
import { DeletedAddress } from "src/common/entities/deleted-address.entity";
import { Address } from "src/common/entities/address.entity";
import { DeletedFleet } from "src/common/entities/deleted_fleet.entity";
import { DeletedVehicle } from "src/common/entities/deleted_vehicle.entity";
import { TemplateName } from "src/common/entities/template_name.entity";
import { DeletedUserDocument } from "src/common/entities/deleted-user-document.entity";
import { AdminTemplate } from "src/common/entities/admin-template.entity";
import { DeletedAdminTemplate } from "src/common/entities/deleted-admin-template.entity";
import { Fleet } from "src/common/entities/fleet.entity";
import { Vehicle } from "src/common/entities/vehicle.entity";
import { Role } from "src/common/entities/role.entity";
import { User } from "src/common/entities/user.entity";
import { Admin } from "../entities/admin.entity";
import { Driver } from "../entities/driver.entity";
import { DashboardService } from "./dashboard.service";
import { DriverDbService } from "./driver-db.service";
import { Message } from "../entities/message.entity";
import { MessageDbService } from "./message-db.service";
import { ElasticSearchDbService } from "./elastic-search-db.service";
import { ConfigModule, ConfigService } from "@nestjs/config";
import * as ES from "@nestjs/elasticsearch";
import { IElasticSearch } from "../utils/interface.utils";
import { HttpModule } from "@nestjs/axios";

@Module({
  imports: [
    ES.ElasticsearchModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        node: configService.get<IElasticSearch>("elastic_search").node,
        auth: {
          username: configService.get<IElasticSearch>("elastic_search").username,
          password: configService.get<IElasticSearch>("elastic_search").password,
        },
      }),
      inject: [ConfigService],
    }),
    TypeOrmModule.forFeature([
      User,
      Role,
      Vehicle,
      Fleet,
      DeletedUser,
      UserDocument,
      DeletedVehicle,
      DeletedUserDocument,
      TemplateName,
      Message,
      DeletedTemplateName,
      AdminTemplate,
      DeletedFleet,
      DeletedAdminTemplate,
      Address,
      DeletedAddress,
      Broker,
      DeletedBroker,
      Admin,
      Driver,
    ]),
    JwtModule,
    HttpModule
  ],
  providers: [
    VehicleDbService,
    UserDbService,
    DeletedUserDbService,
    UserDocumentDbService,
    DeletedVehicleDbService,
    DriverDbService,
    MessageDbService,
    DeletedUserDocumentDbService,
    TemplateNameDbService,
    AdminTemplateDbService,
    FleetDbService,
    DeletedAdminTemplateDbService,
    AgentDbService,
    DeletedAgentDbService,
    DashboardService,
    ElasticSearchDbService,
  ],
})
export class DbServicesModule {}
