import {
  BadGatewayException,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Connection, Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { Broker } from 'src/common/entities/agent.entity';

@Injectable()
export class AgentDbService {
  constructor(
    @InjectRepository(Broker)
    private agentRepository: Repository<Broker>,
    @InjectConnection() private readonly connection: Connection
  ) {}

  async createBroker(query: any):Promise<Broker> {
    try {
      return this.agentRepository.save(query);
    } catch (err) {
      throw new BadGatewayException(error.creatBrokerError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getBrokerDetailsByQuery(query: any):Promise<Broker[]> {
    try {
      return this.agentRepository.find(query);
    } catch (err) {
      throw new BadGatewayException(error.getBrokerDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }

  async getBrokerData(query: any):Promise<Broker> {
    try {
      return this.agentRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getBrokerDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }

  async getBrokersByQuryBuilder(select:any,where:any):Promise<Broker[]>{
    try{
      return this.agentRepository
      .createQueryBuilder('broker')
      .select(select)
      .addSelect("'broker'", 'role')
      .where(where)
      .orderBy()
      .getRawMany()
    } catch (err) {
      throw new BadGatewayException(error.getBrokerDetailsError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getBrokerDetailsWithSelectedFileds(query: any,):Promise<Broker[]> {
    try{
      const result = await this.connection.query(query);
      return result;
    } catch (err) {
      throw new BadGatewayException(error.getBrokerDetailsError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }


  async updateBroker(id: string,payload:any): Promise<UpdateResponseDto> {
    try {
      return this.agentRepository.update(id,payload);
    } catch (err) {
      throw new BadRequestException(error.brokerUpdationError, {
        cause: new Error(),
        description: err?.response?.error,
      });
    }
  }

  async hardDeleteBroker(id: string): Promise<UpdateResponseDto> {
    try {
      return this.agentRepository.delete(id);
    } catch (err) {
      console.log("hardDeleteBroker Error -----09:",err);

      throw new BadRequestException(error.brokerHardDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async getBrokersFindAndCount(query: any): Promise<[Broker[],number]> {
    try {
      return this.agentRepository.findAndCount(query);
    } catch (err) {
      throw new BadGatewayException(error.getAllBrokersError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getBrokersCount(query: any): Promise<number> {
    try {
      return this.agentRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getBrokerCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async isBrokerExist(query: any):Promise<boolean> {
    try {
      return this.agentRepository.exist(query);
    } catch (err) {
      throw new BadGatewayException(error.getIsBrokerExistError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }
}
