import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedUser } from 'src/common/entities/deleted-user.entity';

@Injectable()
export class DeletedUserDbService {
  constructor(
    @InjectRepository(DeletedUser)
    private deletedUsersRepository: Repository<DeletedUser>,
  ) {}

  async createDeletedUser(payload: any): Promise<DeletedUser> {
    try {
      return await this.deletedUsersRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedUserError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }
}
