import {
  BadGatewayException,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { Admin } from '../entities/admin.entity';

@Injectable()
export class AdminDbService {
  constructor(
    @InjectRepository(Admin)
    private adminRepository: Repository<Admin>,
  ) {}

  async getAdminDetailsByQuery(query: any): Promise<Admin[]> {
    try {
      return this.adminRepository.find(query);
    } catch (err) {
      throw new BadGatewayException(error.getAdminDetailsError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getAdminData(query: any): Promise<Admin> {
    try {
      const admin =await this.adminRepository.findOne(query);
      return admin;
    } catch (err) {
      throw new BadGatewayException(error.getAdminDetailsError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async hardDeleteAdmin(id: string): Promise<UpdateResponseDto> {
    try {
      return this.adminRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.adminHardDeleteionFailed, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getAdminTemplatesCount(query: any): Promise<number> {
    try {
      return this.adminRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getAdminCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
