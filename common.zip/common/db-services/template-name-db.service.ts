import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { TemplateName } from 'src/common/entities/template_name.entity';

@Injectable()
export class TemplateNameDbService {
  constructor(
    @InjectRepository(TemplateName)
    private templateNameRepository: Repository<TemplateName>,
  ) {}

  async createTemplateName(query: any):Promise<TemplateName> {
    try {
      return this.templateNameRepository.save(query);
    } catch (err) {
      throw new BadGatewayException(error.templateNameCreate, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getTemplateNameDetailsByQuery(query:any):Promise<TemplateName[]> {
    try {
      return this.templateNameRepository.find(query);
    } catch (err) {
      throw new BadRequestException(error.getTemplateNameError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getTemplateNameData(query:any):Promise<TemplateName> {
    try {
      return this.templateNameRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.getTemplateNameError, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async getTemplateNameFindAndCount(query: any): Promise<[TemplateName[],number]> {
    try {
      return this.templateNameRepository.findAndCount(query);
    } catch (err) {
      throw new BadGatewayException(error.getTemplateNameError, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async updateTemplateName(id: string,payload:any): Promise<UpdateResponseDto> {
    try {
      return this.templateNameRepository.update(id,payload);
    } catch (err) {
      throw new BadRequestException(error.templateNameUpdationError, {
        cause: new Error(),
        description: err?.response?.error,
      });
    }
  }

  async hardDeleteTemplateName(id: string): Promise<UpdateResponseDto> {
    try {
      return this.templateNameRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.templateNameDeleteionFailed, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
