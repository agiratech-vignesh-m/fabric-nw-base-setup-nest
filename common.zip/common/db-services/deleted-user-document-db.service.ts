import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedUserDocument } from 'src/common/entities/deleted-user-document.entity';

@Injectable()
export class DeletedUserDocumentDbService {
  constructor(
    @InjectRepository(DeletedUserDocument)
    private deletedUserDocumentRepository: Repository<DeletedUserDocument>,
  ) {}

  async createDeletedUserDocument(payload: any): Promise<DeletedUserDocument> {
    try {
      return await this.deletedUserDocumentRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedUserDocumentError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }
}
