import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedDriver } from '../entities/deleted_driver.entity';

@Injectable()
export class DeletedDrvierDbService {
  constructor(
    @InjectRepository(DeletedDriver)
    private deletedDriverRepository: Repository<DeletedDriver>,
  ) {}

  async createDeletedDriver(payload: any): Promise<DeletedDriver> {
    try {
      return await this.deletedDriverRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedDriverError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage
      });
    }
  }
}
