import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { Fleet } from 'src/common/entities/fleet.entity';

@Injectable()
export class FleetDbService {
  constructor(
    @InjectRepository(Fleet)
    private fleetRepository: Repository<Fleet>,
  ) {}
  
  async createFleet(query: any):Promise<Fleet> {
    try {
      return this.fleetRepository.save(query);
    } catch (err) {
      throw new BadGatewayException(error.fleetCreate, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getFleetData(query:any):Promise<Fleet> {
    try {
      return this.fleetRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.getFleetError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }


  async getFleetDetailsByQuery(query:any):Promise<Fleet[]> {
    try {
      return this.fleetRepository.find(query);
    } catch (err) {
      throw new BadRequestException(error.getFleetError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async hardDeleteFleet(id: string): Promise<UpdateResponseDto> {
    try {
      return this.fleetRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.fleetHardDeletionError, {
        cause: new Error(),
        description: err
      });
    }
  }

  async getFleetsCount(query: any): Promise<number> {
    try {
      return this.fleetRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getFleetCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getFleetsFindAndCount(query: any): Promise<[Fleet[],number]> {
    try {
      return this.fleetRepository.findAndCount(query);
    } catch (err) {
      throw new BadGatewayException(error.getFleetDataAndCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async updateFleet(id: string,payload:any): Promise<UpdateResponseDto> {
    try {
      return this.fleetRepository.update(id,payload);
    } catch (err) {
      throw new BadRequestException(error.fleetUpdate, {
        cause: new Error(),
        description: err?.response?.error,
      });
    }
  }
}
