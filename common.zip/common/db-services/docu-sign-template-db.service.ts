import {
  BadGatewayException,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Connection, Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DocusignTemplate } from '../entities/docusign-template.entity';

@Injectable()
export class DocusignTemplateDbService {
  constructor(
    @InjectRepository(DocusignTemplate)
    private docusignTemplateRepository: Repository<DocusignTemplate>,
    @InjectConnection() private readonly connection: Connection
  ) {}

  async getDocusignTemplateData(query: any):Promise<DocusignTemplate> {
    try {
      return this.docusignTemplateRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getDocusignTemplateDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }


  async updateDocusignTemplate(id: string,payload:any): Promise<UpdateResponseDto> {
    try {
      return this.docusignTemplateRepository.update(id,payload);
    } catch (err) {
      throw new BadRequestException(error.docusignTemplateUpdationError, {
        cause: new Error(),
        description: err?.response?.error,
      });
    }
  }

  async hardDeleteDocusignTemplate(id: string): Promise<UpdateResponseDto> {
    try {
      return this.docusignTemplateRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.brokerHardDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
