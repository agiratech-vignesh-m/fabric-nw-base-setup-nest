import {
  BadGatewayException,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Connection, Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { Driver } from '../entities/driver.entity';

@Injectable()
export class DriverDbService {
  constructor(
    @InjectRepository(Driver)
    private driverRepository: Repository<Driver>,
    @InjectConnection() private readonly connection: Connection
  ) {}

  async createDriver(query: any):Promise<Driver> {
    try {
      return this.driverRepository.save(query);
    } catch (err) {
      throw new BadGatewayException(error.creatDriverError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getDriverDetailsByQuery(query: any):Promise<Driver[]> {
    try {
      return this.driverRepository.find(query);
    } catch (err) {
      throw new BadGatewayException(error.getDriverDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }

  async getDriverData(query: any):Promise<Driver> {
    try {
      return this.driverRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getDriverDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }



  async updateDriver(id: string,payload:any): Promise<UpdateResponseDto> {
    try {
      return this.driverRepository.update(id,payload);
    } catch (err) {
      throw new BadRequestException(error.driverUpdationError, {
        cause: new Error(),
        description: err?.response?.error,
      });
    }
  }

  async hardDeleteDriver(id: string): Promise<UpdateResponseDto> {
    try {
      return this.driverRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.driverDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getDriverDetailsWithSelectedFileds(query: any,):Promise<Driver[]> {
    try{
      const result = await this.connection.query(query);
      return result;
    } catch (err) {
      throw new BadGatewayException(error.getDriverDetailsError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getDriverByQuryBuilder(select:any,where:any,userId:string):Promise<Driver[]>{
    try{
      return this.driverRepository
      .createQueryBuilder('driver')
      .select(select)
      .addSelect("'driver'", 'role')
      .where(where)
      .orderBy()
      .getRawMany()
    } catch (err) {
      throw new BadGatewayException(error.getDriverDetailsError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }


  async getDriversFindAndCount(query: any): Promise<[Driver[],number]> {
    try {
      return this.driverRepository.findAndCount(query);
    } catch (err) {
      throw new BadGatewayException(error.getAllDriversError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getDriversCount(query: any): Promise<number> {
    try {
      return this.driverRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getBrokerCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async isDriverExist(query: any):Promise<boolean> {
    try {
      return this.driverRepository.exist(query);
    } catch (err) {
      throw new BadGatewayException(error.getIsBrokerExistError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }
}
