import { BadRequestException, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { error } from "../config/db-yaml.config";
import { DocuSign } from "../entities/docusign.entity";
import { throwError } from "rxjs";

@Injectable()
export class DocusignDbService {
  constructor(
    @InjectRepository(DocuSign)
    private docusignRepository: Repository<DocuSign>
  ) { }

  async upsertDocuSign(payload: any): Promise<DocuSign> {
    try {
      let docusign: DocuSign;
      if (payload?.id) {
        docusign = await this.docusignRepository.findOne({
          where: { id: payload?.id },
        });
      }
      if (!docusign) {
        docusign = await this.docusignRepository.save(payload);
      } else {
        await this.docusignRepository.update(docusign.id, payload);
      }
      return await this.docusignRepository.findOne({
        where: { id: docusign?.id },
        relations: ["created_by"],
      });
    } catch (err) {
      throw new BadRequestException(error.createDocusign, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }

  async getDocuSignData(query:any): Promise<DocuSign> {
    try {
      return await this.docusignRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.getDocusignError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }

  async listDocuSignData(userId:string,searchText:string,sort_by:string,sort:any,skip:number,limit:number):Promise<[DocuSign[],number]>{
    try {
      const result = await this.docusignRepository
        .createQueryBuilder('docu_sign')
        .innerJoinAndSelect('docu_sign.created_by', 'user')
        .where(`(user.id = :id)`, { id: userId })
        .andWhere(
          `(
        (docu_sign.created_at LIKE :searchText) OR (docu_sign.accident_date LIKE :searchText) OR 
        (JSON_UNQUOTE(JSON_EXTRACT(docu_sign.driver, '$.driver_name')) LIKE :searchText) OR 
        (JSON_UNQUOTE(JSON_EXTRACT(docu_sign.accidents_location, '$.location_text')) LIKE :searchText) OR
        (docu_sign.accident_time LIKE :searchText)
        )`,
          {
            searchText: `%${searchText}%`,
          },
        )
        .orderBy(`docu_sign.${sort_by}`, sort)
        .skip(skip)
        .take(limit)
        .getManyAndCount();

    return result;
    } catch (err) {
      console.log("Get docusign list error:",err);
      throw new BadRequestException(error.getDocusignError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }
  async getDetails(id, createdBy) {
    try {
      let data = await this.docusignRepository.findOne({
        where: { id: id, created_by: { id: createdBy } },
        relations: ["created_by"],
      });
      return data;
    } catch (err) {
      console.log("errr-------->", err)
      throw new Error(err)
    }
  }

  async updateUrl(id, role, url) {
    try {
      if (role == "driver") {
        await this.docusignRepository.update(id, { pdf: url, is_driver_signed: true });
      }else{
        await this.docusignRepository.update(id, { pdf: url, is_broker_signed: true });
      }
    } catch (err) {
      console.log("errr-------->", err)
      throw new Error(err)
    }
  }

}
