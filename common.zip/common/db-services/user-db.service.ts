import {
  BadGatewayException,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Connection, Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { User } from 'src/common/entities/user.entity';
@Injectable()
export class UserDbService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectConnection() private readonly connection: Connection
  ) {}

  async createUser(payload:any):Promise<any>{
   try{
    const user = await this.userRepository.save(payload);
    return user;
   }
   catch(err){
    throw new BadRequestException("Create user error", {
      cause: new Error(),
      description: err?.sqlMessage,
    });
   }
  }

  async isEmailExists(email: string): Promise<User | false> {
    try {
      const user = await this.userRepository.findOne({
        where: { email },
        relations: { role: true },
      });
      if (user) {
        return user;
      }
      return false;
    } catch (err) {
      throw new Error(err);
    }
  }

  async getUserDetailsByQuery(query: any):Promise<User[]> {
    try {
      return await this.userRepository.find(query);
    } catch (err) {
      throw new BadGatewayException(error.getUserDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }

  async getUserDetails(query: any):Promise<User> {
    try {
      return await this.userRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getUserDetailsError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }

  async updateUser(id: string,data:any): Promise<UpdateResponseDto> {
    try {
      return this.userRepository.update(id,data);
    } catch (err) {
      throw new BadRequestException(error.userUpdationError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async hardDeleteUser(id: string): Promise<UpdateResponseDto> {
    try {
      return this.userRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.userHardDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getUsersCount(query: any): Promise<number> {
    try {
      return this.userRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getUserCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }
  
  async getUserDetailsWithSelectedFileds(query: any):Promise<User[]> {
    try{
      const result = await this.connection.query(query);
      return result;
    } catch (err) {
      throw new BadGatewayException(error.getUserDetailsError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }
}
