import { BadGatewayException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Role } from 'src/common/entities/role.entity';
import { error } from '../config/db-yaml.config';
import { Repository } from 'typeorm';

@Injectable()
export class RoleDbService {
  constructor(
    @InjectRepository(Role) private roleRepository: Repository<Role>,
  ) {}

  async getRoleDetailsByQuery(query: any): Promise<Role[]> {
    try {
      return this.roleRepository.find(query);
    } catch (err) {
      throw new BadGatewayException(error.getRoleDataError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getRoleData(query: any): Promise<Role> {
    try {
      return this.roleRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getRoleDataError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
