import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Request } from 'express';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { Vehicle } from 'src/common/entities/vehicle.entity';
import { Fleet } from 'src/common/entities/fleet.entity';


@Injectable()
export class VehicleDbService {
  constructor(
    @InjectRepository(Vehicle)
    private vehicleRepository: Repository<Vehicle>,
    @InjectRepository(Fleet) private fleetRepo: Repository<Fleet>,
  ) {}

  async createVehicle(
    payload:any
  ): Promise<Vehicle> {
    try {
      const vehicle = await this.vehicleRepository.save(payload);
      return vehicle;
    } catch (err) {
      throw new BadRequestException(error.vehicleCreationFailed, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }

  async getAllVehicle(filter: any): Promise<[Vehicle[],number]> {
    try {
      const vehicles = await this.vehicleRepository.findAndCount(filter);
      return vehicles;
    } catch (err) {
      throw new BadRequestException(error.getVehicleError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getVehiclebyId(vehicleId: string):Promise<Vehicle[]> {
    try {
      return await this.vehicleRepository.find({
        where: { id: vehicleId },
        relations: ["fleet","driver","created_by"],
      });
    } catch (err) {
      throw new BadRequestException(error.getVehicleError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getVehicleData(query:any):Promise<Vehicle> {
    try {
      return this.vehicleRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.getVehicleError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getVehiclebyQuery(query:any):Promise<Vehicle[]> {
    try {
      return await this.vehicleRepository.find(query);
    } catch (err) {
      throw new BadRequestException(error.getVehicleError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async updateVehicle(id: string, input: any): Promise<UpdateResponseDto> {
    try {
      const payload = new Vehicle().bind({ ...input });

      return this.vehicleRepository.update(id, payload);
    } catch (err) {
      throw new BadRequestException(error.updateVehicleError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async deleteVehicle(id: string): Promise<UpdateResponseDto> {
    try {
      const data = await this.vehicleRepository.update(id, {
        is_active: false,
      });
      return data;
    } catch (err) {
      throw new BadRequestException(error.vehicleDeleteionFailed, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getVehicleByQuery(query: any):Promise<Vehicle[]> {
    try {
      return await this.vehicleRepository.find(query);
    } catch (err) {
      throw new BadRequestException(error.getVehicleError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage,
      });
    }
  }

  async getVehiclesFindAndCount(query: any): Promise<[Vehicle[],number]> {
    try {
      return this.vehicleRepository.findAndCount(query);
    } catch (err) {
      throw new BadGatewayException(error.getVehicleDataAndCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async hardDeleteVehicle(id: string): Promise<UpdateResponseDto> {
    try {
      const data = await this.vehicleRepository.delete(id);
      return data;
    } catch (err) {
      throw new BadRequestException(error.vehicleDeleteionFailed, {
        cause: new Error(),
        description: err,
      });
    }
  }

  //fleet get details
  async getFleetbyId(fleet: string):Promise<any> {
    try {
      return await this.fleetRepo.find({
        where: { id: fleet },
        relations: ['created_by'],
      });
    } catch (err) {
      throw new Error(err);
    }
  }

  //fleet mapping
  // async fleetMapping(id: string, input: any): Promise<any> {
  //   let { fleet } = input;
  //   try {
  //     const data = await this.vehicleRepository.update(id, {
  //      // fleet: fleetId,
  //      //fleet:  { id: fleet } ,
  //       //fleet: (() => fleet)
  //     });
  //     return data;
  //   } catch (err) {
  //     throw new Error(err);
  //   }

    // try {
    //   const payload = new Vehicle().bind({ ...input });

    //   return this.vehicleRepository.update(id, payload);
    // } catch (err) {
    //   throw new Error(err);
    // }
 // }


  async getVehiclesCount(query: any): Promise<number> {
    try {
      return this.vehicleRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getVehiclesCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async fleetMapping(
    payload:any
  ): Promise<any> {
    try {
      const vehicle = await this.vehicleRepository.save(payload);
      return vehicle;
    } catch (err) {
      throw new BadRequestException(error.vehicleFleetMappedError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
