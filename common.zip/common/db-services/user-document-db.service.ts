import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { UserDocument } from 'src/common/entities/user-document.entity';

@Injectable()
export class UserDocumentDbService {
  constructor(
    @InjectRepository(UserDocument)
    private userDocumentRepository: Repository<UserDocument>,
  ) {}

  async createUserDocument(payload: any):Promise<UserDocument> {
    try {
      return await this.userDocumentRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createUserDocumentError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }

  async getUserDocumentsFindAndCount(filter: any):Promise<[UserDocument[],number]> {
    try {
      return this.userDocumentRepository.findAndCount(filter);
    } catch (err) {
      throw new BadRequestException(error.getUserDocumentsCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getUserDocumentsCount(filter: any):Promise<number> {
    try {
      return this.userDocumentRepository.count(filter);
    } catch (err) {
      throw new BadRequestException(error.getUserDocumentsCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getUserDocumentData(query: any): Promise<UserDocument> {
    try {
      return this.userDocumentRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.userDocumentNotFound, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async getUserDocumentsByQuery(query: any): Promise<UserDocument[]> {
    try {
      return this.userDocumentRepository.find(query);
    } catch (err) {
      throw new BadRequestException(error.userDocumentNotFound, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async updateUserDocument(
    id: string,
    input: any,
  ): Promise<UpdateResponseDto> {
    try {
      const payload = new UserDocument().bind({ ...input });
      return this.userDocumentRepository.update(id, payload);
    } catch (err) {
      throw new BadRequestException(error.updateUserDocumentError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async deActiveUserDocumentById(id: string): Promise<UpdateResponseDto> {
    try {
      return this.userDocumentRepository.update(id, {is_active: false});
    } catch (err) {
      throw new BadRequestException(error.userDocumentDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async hardDeleteUserDocument(id: string): Promise<UpdateResponseDto> {
    try {
      return this.userDocumentRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.userDocumentDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
