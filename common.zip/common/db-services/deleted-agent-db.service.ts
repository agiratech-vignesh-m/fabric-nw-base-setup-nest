import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedBroker } from 'src/common/entities/deleted_agent.entity';

@Injectable()
export class DeletedAgentDbService {
  constructor(
    @InjectRepository(DeletedBroker)
    private deletedAgentRepository: Repository<DeletedBroker>,
  ) {}

  async createDeletedBroker(payload: any): Promise<DeletedBroker> {
    try {
      return await this.deletedAgentRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedBrokerError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage
      });
    }
  }
}
