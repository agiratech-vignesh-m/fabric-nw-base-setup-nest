import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { DeletedAdminTemplate } from '../entities/deleted-admin-template.entity';

@Injectable()
export class DeletedAdminTemplateDbService {
  constructor(
    @InjectRepository(DeletedAdminTemplate)
    private deletedAdminTemplateRepository: Repository<DeletedAdminTemplate>,
  ) {}

  async getDeletedAdminTemplateData(query: any):Promise<DeletedAdminTemplate> {
    try {
      return this.deletedAdminTemplateRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getDeletedAdminTemplateError, {
        cause: new Error(),
        description: err.driverError?.sqlMessage,
      });
    }
  }

  async createDeletedAdminTemplate(payload: any): Promise<DeletedAdminTemplate> {
    try {
      return await this.deletedAdminTemplateRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createDeletedAdminTemplateError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }

  async hardDeletedAdminTemplate(id: string): Promise<UpdateResponseDto> {
    try {
      return this.deletedAdminTemplateRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.deletedAdminTemplateDeleteionFailed, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
