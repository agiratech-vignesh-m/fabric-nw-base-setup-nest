import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UpdateResponseDto } from './dto/update-response.dto';
import { error } from '../config/db-yaml.config';
import { Message } from '../entities/message.entity';

@Injectable()
export class MessageDbService {
  constructor(
    @InjectRepository(Message)
    private messageRepository: Repository<Message>,
  ) {}

  async getMessageData(query: any): Promise<Message> {
    try {
      return this.messageRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getMessageDataError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async hardDeleteMessage(id: string): Promise<UpdateResponseDto> {
    try {
      return this.messageRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.messageHardDeletionError, {
        cause: new Error(),
        description: err
      });
    }
  }
}
