import {
  BadGatewayException,
  BadRequestException,
  Injectable,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { AdminTemplate } from 'src/common/entities/admin-template.entity';

@Injectable()
export class AdminTemplateDbService {
  constructor(
    @InjectRepository(AdminTemplate)
    private adminTemplateRepository: Repository<AdminTemplate>,
  ) {}

  async createAdminTemplate(query: any):Promise<any> {
    try {
      return this.adminTemplateRepository.save(query);
    } catch (err) {
      throw new BadRequestException(error.adminTemplateCreateError, {
        cause: new Error(),
        description: err?.driverError?.sqlMessage
      });
    }
  }

  async getAdminTemplateDetailsByQuery(query: any): Promise<AdminTemplate[]> {
    try {
      return this.adminTemplateRepository.find(query);
    } catch (err) {
      throw new BadGatewayException(error.getAdminTemplateDetailsError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getAdminTemplateData(query: any): Promise<AdminTemplate> {
    try {
      return this.adminTemplateRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getAdminTemplateDetailsError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async hardDeleteAdminTemplate(id: string): Promise<UpdateResponseDto> {
    try {
      return this.adminTemplateRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.adminTemplateHardDeleteionFailed, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getAdminTemplatesCount(query: any): Promise<number> {
    try {
      return this.adminTemplateRepository.count(query);
    } catch (err) {
      throw new BadGatewayException(error.getAdminTemplateCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async getAdminTemplatesFindAndCount(query: any): Promise<[AdminTemplate[],number]> {
    try {
      return this.adminTemplateRepository.findAndCount(query);
    } catch (err) {
      throw new BadGatewayException(error.getAdminTemplateDetailsError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async updateAdminTemplates(id:string,query: any): Promise<UpdateResponseDto> {
    try {
      return this.adminTemplateRepository.update(id,query);
    } catch (err) {
      throw new BadGatewayException(error.adminTemplateUpdationError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}
