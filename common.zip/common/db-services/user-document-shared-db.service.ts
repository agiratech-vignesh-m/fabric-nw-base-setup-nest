import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { error } from '../config/db-yaml.config';
import { UpdateResponseDto } from './dto/update-response.dto';
import { UserDocumentShared } from '../entities/user-document-shared.entity';

@Injectable()
export class UserDocumentSharedDbService {
  constructor(
    @InjectRepository(UserDocumentShared)
    private userDocumentSharedRepository: Repository<UserDocumentShared>,
  ) {}

  async createUserDocumentShared(payload: any):Promise<UserDocumentShared> {
    try {
      return this.userDocumentSharedRepository.save(payload);
    } catch (err) {
      throw new BadRequestException(error.createUserDocumentSharedError, {
        cause: new Error(),
        description: err?.sqlMessage,
      });
    }
  }

  async getUserDocumentsSharedFindAndCount(filter: any):Promise<[UserDocumentShared[],number]> {
    try {
      return this.userDocumentSharedRepository.findAndCount(filter);
    } catch (err) {
      throw new BadRequestException(error.getUserDocumentsSharedCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getUserDocumentsSharedCount(filter: any):Promise<number> {
    try {
      return this.userDocumentSharedRepository.count(filter);
    } catch (err) {
      throw new BadRequestException(error.getUserDocumentsSharedCountError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async getUserDocumentSharedByQuery(query: any): Promise<UserDocumentShared> {
    try {
      return this.userDocumentSharedRepository.findOne(query);
    } catch (err) {
      throw new BadRequestException(error.checkUserDocumentSharedId, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async updateUserDocumentShared(
    id: string,
    input: any,
  ): Promise<UpdateResponseDto> {
    try {
      const payload = new UserDocumentShared().bind({ ...input });
      return this.userDocumentSharedRepository.update(id, payload);
    } catch (err) {
      throw new BadRequestException(error.updateUserDocumentSharedError, {
        cause: new Error(),
        description: err,
      });
    }
  }


  async hardDeleteUserDocumentShared(id: string): Promise<UpdateResponseDto> {
    try {
      return this.userDocumentSharedRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.userDocumentSharedDeletionError, {
        cause: new Error(),
        description: err,
      });
    }
  }
}