import { BadGatewayException, BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UpdateResponseDto } from './dto/update-response.dto';
import { SocketSession } from '../entities/socket-session.entity';
import { error } from '../config/db-yaml.config';

@Injectable()
export class SocketSessionDbService {
  constructor(
    @InjectRepository(SocketSession)
    private socketSessionRepository: Repository<SocketSession>,
  ) {}

  async getSocketSessionData(query: any): Promise<SocketSession> {
    try {
      return this.socketSessionRepository.findOne(query);
    } catch (err) {
      throw new BadGatewayException(error.getSocketSessionDataError, {
        cause: new Error(),
        description: err,
      });
    }
  }

  async hardDeleteSocketSession(id: string): Promise<UpdateResponseDto> {
    try {
      return this.socketSessionRepository.delete(id);
    } catch (err) {
      throw new BadRequestException(error.socketSessionHardDeletionError, {
        cause: new Error(),
        description: err
      });
    }
  }
}
