import { Injectable } from '@nestjs/common';
import { Between, Not } from 'typeorm';
import { AgentRportResponseDto } from './dto/agent-report-response.dto';
import { AdminRportResponseDto } from './dto/admin-report-response.dto';
import { AdminTemplateDbService } from './admin-template-db.service';
import { AgentDbService } from './agent-db.service';
import { DriverDbService } from './driver-db.service';
import { FleetDbService } from './fleet-db.service';
import { UserDocumentDbService } from './user-document-db.service';
import { VehicleDbService } from './vehicle-db.service';
import { MemberRportResponseDto } from './dto/member-report-response.dto';
import { success } from '../config/db-yaml.config';

@Injectable()
export class DashboardService {
  constructor(
    private fleetDbService: FleetDbService,
    private vehicleDbService: VehicleDbService,
    private adminTemplateDbService: AdminTemplateDbService,
    private userDocumentDbService: UserDocumentDbService,
    private brokerDbService: AgentDbService,
    private driverDbService: DriverDbService,
  ) {}

  getBeforeWeek = () => {
    // last week
    const yesterday = new Date();
    // yesterday.setDate(new Date().getDate() - 1);
    const last_week = new Date(yesterday);
    last_week.setDate(new Date(yesterday).getDate() - 6);

    // previous last week
    const last_week_before_day = new Date(last_week);
    last_week_before_day.setDate(new Date(last_week).getDate() - 1);
    const last_week_before = new Date(last_week_before_day);
    last_week_before.setDate(new Date(last_week_before_day).getDate() - 6);

    return {
      yesterday,
      last_week,
      last_week_before,
      last_week_before_day,
    };
  };

  async getAdminReport(userId: string): Promise<AdminRportResponseDto> {
    const date = this.getBeforeWeek();

    const reports = {
      totalDriversCount: 0,
      driversWeeklyCount: 0,
      totalBrokersCount: 0,
      brokersWeeklyCount: 0,
      totalFleetsCount: 0,
      fleetsWeeklyCount: 0,
      totalVehiclesCount: 0,
      vehiclesWeeklyCount: 0,
      totalTemplatesCount: 0,
      templatesWeeklyCount: 0,
      totalSharedWithCount: 0,
      sharedWithWeeklyCount: 0,
    };

    const tasks = [
      async () => {
        reports.totalDriversCount = await this.driverDbService.getDriversCount(
          {},
        );
      },
      async () => {
        const totalDriversWeeklyCountQuery = {
          where: { created_at: Between(date.last_week, date.yesterday) },
        };

        reports.driversWeeklyCount = await this.driverDbService.getDriversCount(
          totalDriversWeeklyCountQuery,
        );
      },
      async () => {
        reports.totalBrokersCount = await this.brokerDbService.getBrokersCount({
          where: { created_by: { id: userId } },
          relations: ['created_by'],
        });
      },
      async () => {
        const brokerWeeklyCountQuery = {
          where: {
            created_by: { id: userId },
            created_at: Between(date.last_week, date.yesterday),
          },
          relations: ['created_by'],
        };
        reports.brokersWeeklyCount = await this.brokerDbService.getBrokersCount(
          brokerWeeklyCountQuery,
        );
      },
      async () => {
        const brokerWeeklyCountQuery = {
          where: {
            created_by: { id: userId },
            created_at: Between(date.last_week, date.yesterday),
          },
          relations: ['created_by'],
        };
        reports.brokersWeeklyCount = await this.brokerDbService.getBrokersCount(
          brokerWeeklyCountQuery,
        );
      },
      async () => {
        reports.totalFleetsCount = await this.fleetDbService.getFleetsCount({});
      },
      async () => {
        const fleetWeeklyCountQuery = {
          where: { created_at: Between(date.last_week, date.yesterday) },
        };

        reports.fleetsWeeklyCount = await this.fleetDbService.getFleetsCount(
          fleetWeeklyCountQuery,
        );
      },
      async () => {
        reports.totalVehiclesCount =
          await this.vehicleDbService.getVehiclesCount({});
      },
      async () => {
        const vehiclesWeeklyCountQuery = {
          where: { created_at: Between(date.last_week, date.yesterday) },
        };
        reports.vehiclesWeeklyCount =
          await this.vehicleDbService.getVehiclesCount(
            vehiclesWeeklyCountQuery,
          );
      },
      async () => {
        reports.totalTemplatesCount =
          await this.adminTemplateDbService.getAdminTemplatesCount({});
      },
      async () => {
        const templatesWeeklyCountQuery = {
          where: { created_at: Between(date.last_week, date.yesterday) },
        };
        reports.templatesWeeklyCount =
          await this.adminTemplateDbService.getAdminTemplatesCount(
            templatesWeeklyCountQuery,
          );
      },
      async () => {
        const [data1, totalSharedWithCount] =
          await this.userDocumentDbService.getUserDocumentsFindAndCount({
            where: { shared_with: { user: { id: userId } } },
            relations: ['shared_with', 'shared_with.user'],
          });

        reports.totalSharedWithCount = totalSharedWithCount;
      },
      async () => {
        const [data2, sharedWithWeeklyCount] =
          await this.userDocumentDbService.getUserDocumentsFindAndCount({
            where: { shared_with: { user: { id: userId } } },
            relations: ['shared_with', 'shared_with.user'],
            created_at: Between(date.last_week, date.yesterday),
          });

        reports.sharedWithWeeklyCount = sharedWithWeeklyCount;
      },
    ];

    await Promise.all(tasks.map((p) => p()));
    const result = {
      message: success.adminReportGetSuccess,
      reports: reports,
    };

    return result;
  }

  async getAgentReport(userId: string): Promise<AgentRportResponseDto> {
    const date = this.getBeforeWeek();

    const reports = {
      totalMembersCount: 0,
      membersWeeklyCount: 0,
      totalFleetsCount: 0,
      fleetsWeeklyCount: 0,
      totalVehcilesCount: 0,
      vehiclesWeeklyCount: 0,
      toalUserDoucumentsCount: 0,
      userDoucumentsWeeklyCount: 0,
      totalSharedWithCount: 0,
      sharedWithWeeklyCount: 0,
    };

    const tasks = [
      async () =>
        // 1.Member report
        {
          reports.totalMembersCount =
            await this.driverDbService.getDriversCount({
              where: { created_by: { id: userId } },
              relations: ['created_by'],
            });
        },

      async () => {
        reports.membersWeeklyCount = await this.driverDbService.getDriversCount(
          {
            where: {
              created_at: Between(date.last_week, date.yesterday),
              created_by: { id: userId },
            },
            relations: ['created_by'],
          },
        );
      },
      //2.Fleet report
      async () => {
        reports.totalFleetsCount = await this.fleetDbService.getFleetsCount({
          where: { created_by: { id: userId } },
          relations: ['created_by'],
        });
      },
      async () => {
        reports.fleetsWeeklyCount = await this.fleetDbService.getFleetsCount({
          where: { created_by: { id: userId } },
          created_at: Between(date.last_week, date.yesterday),
          relations: ['created_by'],
        });
      },
      // 3.Vehicle report
      async () => {
        reports.totalVehcilesCount =
          await this.vehicleDbService.getVehiclesCount({
            where: { created_by: { id: userId } },
            relations: ['created_by'],
          });
      },
      async () => {
        reports.vehiclesWeeklyCount =
          await this.vehicleDbService.getVehiclesCount({
            where: {
              created_by: { id: userId },
              created_at: Between(date.last_week, date.yesterday),
            },
            relations: ['created_by'],
          });
      },
      //4.User document report
      async () => {
        reports.toalUserDoucumentsCount =
          await this.userDocumentDbService.getUserDocumentsCount({
            where: { created_by: { id: userId }, url: Not('null') },
            relations: ['created_by'],
          });
      },
      //agent or member created user documents weekly count
      async () => {
        reports.userDoucumentsWeeklyCount =
          await this.userDocumentDbService.getUserDocumentsCount({
            where: {
              created_by: { id: userId },
              url: Not('null'),
            },
            created_at: Between(date.last_week, date.yesterday),
            relations: ['created_by'],
          });
      },
      //member shared_with agent user documents count

      async () => {
        const [data1, totalSharedWithCount] =
          await this.userDocumentDbService.getUserDocumentsFindAndCount({
            where: {
              shared_with: { user: { id: userId } },
            },
            relations: ['shared_with', 'shared_with.user'],
          });

        reports.totalSharedWithCount = totalSharedWithCount;
      },
      //member shared_with agent user documents weekly count

      async () => {
        const [data2, sharedWithWeeklyCount] =
          await this.userDocumentDbService.getUserDocumentsFindAndCount({
            where: {
              shared_with: { user: { id: userId } },
            },
            created_at: Between(date.last_week, date.yesterday),
            relations: ['shared_with', 'shared_with.user'],
          });

        reports.sharedWithWeeklyCount = sharedWithWeeklyCount;
      },
    ];

    await Promise.all(tasks.map((p) => p()));

    const result = {
      message: success.brokerReportGetSuccess,
      reports: reports,
    };

    return result;
  }

  public async getMembersReport(
    userId: string,
  ): Promise<MemberRportResponseDto> {
    const date = this.getBeforeWeek();

    const reports = {
      toalUserDoucumentsCount: 0,
      userDoucumentsWeeklyCount: 0,
    };

    const tasks = [
      async () => {
        //member created user documents total count
        reports.toalUserDoucumentsCount =
          await this.userDocumentDbService.getUserDocumentsCount({
            where: { created_by: { id: userId }, url: Not('null') },
            relations: ['created_by'],
          });
      },
      async () => {
        //member created user documents weekly count
        reports.userDoucumentsWeeklyCount =
          await this.userDocumentDbService.getUserDocumentsCount({
            where: {
              created_by: { id: userId },
              url: Not('null'),
            },
            created_at: Between(date.last_week, date.yesterday),
            relations: ['created_by'],
          });
      },
    ];

    await Promise.all(tasks.map((p) => p()));

    return { message: success.memberReportGetSuccess, reports: reports };
  }
}
