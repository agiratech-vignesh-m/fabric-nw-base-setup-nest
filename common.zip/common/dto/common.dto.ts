import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from "class-validator";
import { QrType } from "src/utils/interface.utils";
import { IBadges } from "../utils/interface.utils";
import { ConsentDriverTypeEnum, QrCodeStatusEnum } from "src/utils/db.enum";

export class ListDto {
  @IsNotEmpty({ message: "Limit can't be blank" })
  @IsString({ message: "Limit must be a number" })
  limit: number;

  @IsNotEmpty({ message: "Page can't be blank" })
  @IsString({ message: "Page must be a number" })
  page: number;

  @IsOptional()
  @IsString({ message: "Search must be a string" })
  search: string;

  @IsOptional()
  @IsString()
  sort: string

  @IsOptional()
  @IsString()
  sort_by: string
}

export class GetDetailsDto {
  @IsOptional()
  @IsString({ message: "must be a string" })
  license_number: string;

  @IsOptional()
  @IsString({ message: "must be a string" })
  dob: Date;
}

export class DriverDetailsDto {
  @IsOptional()
  @IsString({ message: "must be a string" })
  license_number: string;
}

export class InitEntraDto {
  @IsNotEmpty()
  @IsString()
  user: string;

  @IsNotEmpty()
  @IsEnum(IBadges)
  type: IBadges;
}

export class VerifyQrCodeDto {
  @IsNotEmpty()
  @IsString()
  hash: string;

  @IsNotEmpty()
  @IsString()
  pin: string;
}

export class StatusUpdateQrCodeDto {
  @IsNotEmpty()
  @IsString()
  hash: string;

  @IsNotEmpty()
  @IsEnum(QrCodeStatusEnum)
  status: QrCodeStatusEnum;
}

export class StatusQrCodeDto {
  @IsNotEmpty()
  @IsString()
  hash: string;
}

export class underwritingCredentialsDto {
  @IsOptional()
  @IsString({ message: "must be a string" })
  license_number: string;

  @IsOptional()
  @IsString({ message: "must be a string" })
  mobile_number: string;

}

export class ListDtoWithStatus {
  @IsNotEmpty({ message: "Limit can't be blank" })
  @IsString({ message: "Limit must be a number" })
  limit: number;

  @IsNotEmpty({ message: "Page can't be blank" })
  @IsString({ message: "Page must be a number" })
  page: number;

  @IsOptional()
  @IsString({ message: "Search must be a string" })
  search: string;

  @IsOptional()
  @IsString({ message: "Status must be a string" })
  status: string;
}
export class QueryListDto extends ListDto {

  @IsOptional()
  @IsString({ message: "Status must be a string" })
  status: string;

  @IsOptional()
  @IsString({ message: "Status must be a string" })
  device_type: string;

  @IsOptional()
  @IsString({ message: "Status must be a string" })
  mapping: string;

}

export class DirectDriverListDto extends ListDto {

  @IsOptional()
  @IsString({ message: "dmv_license_number must be a string" })
  dmv_license_number: string;

  @IsOptional()
  @IsString({ message: "name must be a string" })
  name: string;
}

export class ConsentDto {
  @IsNotEmpty()
  @IsEnum(ConsentDriverTypeEnum)
  driver_type: ConsentDriverTypeEnum;

  @IsOptional()
  @IsString()
  owner: string;

  @IsNotEmpty()
  @IsArray()
  drivers: string[];

  @IsNotEmpty()
  @IsArray()
  vehicles: string[];

}