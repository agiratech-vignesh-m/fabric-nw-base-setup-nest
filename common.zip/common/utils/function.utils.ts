import { couponPrefix } from "./constants.utils";
import { IPaginationParams, IPaginationData } from "./interface.utils";

export const getPagination = (params: IPaginationParams) => {
  const { limit = 20, page = 1, search } = params;
  let skip = 0;
  if (page > 0) {
    skip = (page - 1) * limit;
  }
  let paging: IPaginationData = {
    take: limit,
    skip,
  };
  if (search && search.length > 0) {
    paging.search = search;
  }
  return paging;
};

export const getBeforeWeek = () => {
  // last week
  const yesterday = new Date();
  // yesterday.setDate(new Date().getDate() - 1);
  const last_week = new Date(yesterday);
  last_week.setDate(new Date(yesterday).getDate() - 6);

  // previous last week
  const last_week_before_day = new Date(last_week);
  last_week_before_day.setDate(new Date(last_week).getDate() - 1);
  const last_week_before = new Date(last_week_before_day);
  last_week_before.setDate(new Date(last_week_before_day).getDate() - 6);

  return {
    yesterday,
    last_week,
    last_week_before,
    last_week_before_day,
  };
};

export const generateRandomId = (): string => {
  let index = Math.floor(Math.random() * couponPrefix.length);
  let number = Math.floor(1000 + Math.random() * 9000).toString();

  return couponPrefix[index] + number;
};

export const makeFirstLetterCapitalize = (str: string): string => {
  const str2 = str.charAt(0).toUpperCase() + str.slice(1);
  return str2;
};
