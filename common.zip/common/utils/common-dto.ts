import { IsInt, IsString, IsOptional, Min, IsEnum, IsNotEmpty } from "class-validator";
import { OrderEnum } from "../utils/db.enum";

export class PaginationDto {
  // @IsInt()
  // @Min(1, {message: "limit must be a positive number"})
  @IsNotEmpty()
  limit: number;

  // @IsInt()
  // @Min(1, {message: "page must be a positive number"})
  @IsNotEmpty()
  page: number;

  @IsString()
  @IsOptional()
  search: string;

  @IsString()
  @IsOptional()
  order_by: string;

  @IsEnum(OrderEnum)
  @IsOptional()
  order: OrderEnum;

  @IsOptional()
  @IsString()
  name: string;

  @IsOptional()
  @IsString()
  hack_license_number: string;

  @IsOptional()
  @IsString()
  sort:string

  @IsOptional()
  @IsString()
  sort_by:string

  @IsOptional()
  @IsString()
  isMyDocument:string
}
