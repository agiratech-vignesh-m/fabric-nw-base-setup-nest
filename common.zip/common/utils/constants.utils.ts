export const roles = [
  {
    name: "admin",
  },
  {
    name: "employee",
  },
  {
    name: "driver",
  },
  {
    name: "agent",
  },
];

export const crypto_algorithm = "aes-256-cbc";

export const employeeVerifyMessage = (time) => {
  return `Simply click the "Verify Email" to verify your email address and get started. The "Verify Email" expires in ${time}.`;
};

export const driverVerifyMessage = (time) => {
  return `You're almost set to start enjoying your digital credentials. Please verify the details mentioned below and provide your consent by clicking on the "Verify Email" and get started. The "Verify Email" expires in ${time}.`;
};

export const couponListConvertion = [
  {
    key: "_tokenId",
    lable: "coupon_id",
    type: "int",
  },
  {
    key: "_tokenURL",
    lable: "image",
    type: "string",
  },
  {
    key: "_startDate",
    lable: "start_date",
    date: true,
    type: "int",
  },
  {
    key: "_endDate",
    lable: "end_date",
    date: true,
    type: "int",
  },
];

export const randomDigits = () => {
  return Math.floor(100_000 + Math.random() * 900_000).toString();
};

export const fireFlyEvents = {
  DRIVER_CREDENTIALIZED: "DataCredentialized",
  DRIVER_CREDENTIAL_EDITED: "DataCredentialEdited",
  COUPON_REDEEMED: "Redeemed",
  COUPON_CREATED: "CouponCreated",
  COUPON_UPDATE: "EndDateUpdate",
  DRIVER_REGISTED: "DriverRegistered",
};

export const couponPrefix = [
  "OFFER",
  "NEW",
  "FLASHDEAL",
  "SPECIALOFFER",
  "HOLIDAYSPECIAL",
  "SUPERSAVER",
  "BOGO",
];
