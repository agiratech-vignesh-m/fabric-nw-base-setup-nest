import * as moment from "moment";

export const getDetails = (data, Role, Name) => {

  let str = "\u2714";
  const whiteColour = "⬜⬜⬜⬜⬜";

  let involved_list_count;

  if (data?.all_involved?.length) {
    let involved_list_length = data?.all_involved?.length / 4;
    involved_list_count = Math?.ceil(involved_list_length)
  }
  let arrLength = data?.vehicle_involved_list?.length > 0 ? data?.vehicle_involved_list?.length : 1

  let input_length;
  if (typeof involved_list_count === 'number' && isFinite(involved_list_count)) {
    input_length = Math.max(involved_list_count, arrLength);
  }


  let rush = data?.rush_drive ? str : " "
  let am = (data?.accident_time?.split(' ')?.[1] == 'AM') ? str : " ";
  let pm = (data?.accident_time?.split(' ')?.[1] == 'PM') ? str : " ";
  let police_investigated_yes = data?.police_investigated ? str : " ";
  let police_investigated_no = data?.police_investigated ? " " : str;

  let public_property_damaged = data?.driver?.public_property_damaged ? str : " ";
  let acccident_location_check_1 = (data?.accidents_location?.intersecting_street?.length > 0) ? str : " ";

  let accidents_location_city = (data?.accidents_location?.location_type == "city") ? str : " ";
  let accidents_location_village = (data?.accidents_location?.location_type == "village") ? str : " ";
  let accidents_location_town = (data?.accidents_location?.location_type == "town") ? str : " ";

  let direction_north = (data?.accidents_location?.direction == 'north') ? str : " ";
  let direction_south = (data?.accidents_location?.direction == 'south') ? str : " ";
  let direction_east = (data?.accidents_location?.direction == 'east') ? str : " ";
  let direction_west = (data?.accidents_location?.direction == 'west') ? str : " ";
  let injury = data?.injury ? str : " ";
  let death = data?.death ? str : " ";

  let injuryA1 = data?.all_involved?.[0]?.injury_level?.includes('A') ? str : " "
  let injuryB1 = data?.all_involved?.[0]?.injury_level?.includes('B') ? str : " "
  let injuryC1 = data?.all_involved?.[0]?.injury_level?.includes('C') ? str : " "

  let injuryA2 = data?.all_involved?.[1]?.injury_level?.includes('A') ? str : " "
  let injuryB2 = data?.all_involved?.[1]?.injury_level?.includes('B') ? str : " "
  let injuryC2 = data?.all_involved?.[1]?.injury_level?.includes('C') ? str : " "

  let injuryA3 = data?.all_involved?.[2]?.injury_level?.includes('A') ? str : " "
  let injuryB3 = data?.all_involved?.[2]?.injury_level?.includes('B') ? str : " "
  let injuryC3 = data?.all_involved?.[2]?.injury_level?.includes('C') ? str : " "

  let injuryA4 = data?.all_involved?.[3]?.injury_level?.includes('A') ? str : " "
  let injuryB4 = data?.all_involved?.[3]?.injury_level?.includes('B') ? str : " "
  let injuryC4 = data?.all_involved?.[3]?.injury_level?.includes('C') ? str : " "

  let time = data?.accident_time.split(' ')?.[0]


  //vehicle1_estimation_g 
  let vehicle1_estimation_a = (data?.vehicle_damage?.vehicle_estimation == "$1,001-$1,500") ? str : " ";
  let vehicle1_estimation_b = (data?.vehicle_damage?.vehicle_estimation == "$1,501-$2,500") ? str : " ";
  let vehicle1_estimation_c = (data?.vehicle_damage?.vehicle_estimation == "Over $2,500") ? str : " ";

  //to_do _no need
  let vehicle1_estimation_d = (data?.vehicle_damage?.vehicle2_estimation == "$1,001-$1,500") ? str : " ";
  let vehicle1_estimation_e = (data?.vehicle_damage?.vehicle2_estimation == "$1,501-$2,500") ? str : " ";
  let vehicle1_estimation_f = (data?.vehicle_damage?.vehicle2_estimation == "Over $2,500") ? str : " ";


  let value_d = [];
  let value_e = [];
  let value_f = [];

  let vehicle_involved_type_vehicle = [];
  let vehicle_involved_type_pedestrian = [];
  let vehicle_involved_type_bycyclist = [];
  let vehicle_involved_type_oher = []

  let vehicle_involved_public_property_damaged = [];


  let injury_A1 = [];
  let injury_B1 = [];
  let injury_C1 = [];

  let injury_A2 = [];
  let injury_B2 = [];
  let injury_C2 = [];

  let injury_A3 = [];
  let injury_B3 = [];
  let injury_C3 = [];

  let injury_A4 = [];
  let injury_B4 = [];
  let injury_C4 = [];

  let all_involved_name_of_person = [];
  let all_involved_vehicle_occupied = [];
  let all_involved_position_vehicle = [];
  let all_involved_safety_equip_used = [];
  let all_involved_person_age = [];
  let all_involved_person_gender = [];
  let all_involved_description = [];
  let all_involved_date_of_death = [];


  let result = []
  let result1 = []
  if (data?.vehicle_involved_list?.length && data?.vehicle_involved_list?.length > 0) {

    console.log("length greater thaan 0 in prefill")
    for (let i = 0; i <= data?.all_involved?.length; i++) {

      all_involved_name_of_person[i + 1] = data?.all_involved?.[i]?.name_of_person;
      all_involved_vehicle_occupied[i + 1] = data?.all_involved?.[i]?.vehicle_occupied;
      all_involved_position_vehicle[i + 1] = data?.all_involved?.[i]?.position_vehicle;
      all_involved_safety_equip_used[i + 1] = data?.all_involved?.[i]?.safety_equip_used;
      all_involved_person_age[i + 1] = data?.all_involved?.[i]?.person_age;
      all_involved_person_gender[i + 1] = data?.all_involved?.[i]?.person_gender;
      all_involved_description[i + 1] = data?.all_involved?.[i]?.description;
      all_involved_date_of_death[i + 1] = data?.all_involved?.[i]?.date_of_death

    }



    for (let i = 0; i < data?.all_involved?.length; i++) {
      injury_A1[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('A') ? str : " "
      injury_B1[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('B') ? str : " "
      injury_C1[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('C') ? str : " "

      injury_A2[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('A') ? str : " "
      injury_B2[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('B') ? str : " "
      injury_C2[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('C') ? str : " "

      injury_A3[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('A') ? str : " "
      injury_B3[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('B') ? str : " "
      injury_C3[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('C') ? str : " "

      injury_A4[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('A') ? str : " "
      injury_B4[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('B') ? str : " "
      injury_C4[i + 1] = data?.all_involved?.[i]?.injury_level?.includes('C') ? str : " "
    }


    //date & name
    for (let i = 0; i <= input_length; i++) {
      result.push(...[
        {
          tabLabel: `submitted_date_p${i}`,
          value: moment(data?.insurance?.submitted_date)?.format("MM-DD-YYYY") || ""
        },
        {
          tabLabel: `vehicle1_driver_p${i}`,
          value: data?.insurance?.vehicle1_driver || ""
        },
      ])
    }

    const chunkSize = 4;
    const pages = [];

    for (let i = 0; i < data?.all_involved?.length; i += chunkSize) {
      const pageData = data?.all_involved?.slice(i, i + chunkSize);
      pages.push(pageData);
    }


    for (let i = 0; i < pages?.length; i++) {
      if (pages?.[i]?.length == 4) {

        for (let j = 1; j <= pages?.[i]?.length; j++) {
          result.push(...[
            {
              tabLabel: `1[${j - 1}]_p${i + 1}`,
              value: injury_A1?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `2[${j - 1}]_p${i + 1}`,
              value: injury_B1?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `3[${j - 1}]_p${i + 1}`,
              value: injury_C1?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `4[${j - 1}]_p${i + 1}`,
              value: injury_A2?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `5[${j - 1}]_p${i + 1}`,
              value: injury_B2?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `6[${j - 1}]_p${i + 1}`,
              value: injury_C2?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `7[${j - 1}]_p${i + 1}`,
              value: injury_A3?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `8[${j - 1}]_p${i + 1}`,
              value: injury_B3?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `9[${j - 1}]_p${i + 1}`,
              value: injury_C3?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `10[${j - 1}]_p${i + 1}`,
              value: injury_A4?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `11[${j - 1}]_p${i + 1}`,
              value: injury_B4?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `12[${j - 1}]_p${i + 1}`,
              value: injury_C4?.[(i * pages?.[i]?.length) + j] || ""
            },
          ])
        }
      } else {
        for (let j = 1; j <= pages?.[i]?.length; j++) {
          result.push(...[
            {
              tabLabel: `1[${j - 1}]_p${i + 1}`,
              value: injury_A1?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `2[${j - 1}]_p${i + 1}`,
              value: injury_B1?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `3[${j - 1}]_p${i + 1}`,
              value: injury_C1?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `4[${j - 1}]_p${i + 1}`,
              value: injury_A2?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `5[${j - 1}]_p${i + 1}`,
              value: injury_B2?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `6[${j - 1}]_p${i + 1}`,
              value: injury_C2?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `7[${j - 1}]_p${i + 1}`,
              value: injury_A3?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `8[${j - 1}]_p${i + 1}`,
              value: injury_B3?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `9[${j - 1}]_p${i + 1}`,
              value: injury_C3?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `10[${j - 1}]_p${i + 1}`,
              value: injury_A4?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `11[${j - 1}]_p${i + 1}`,
              value: injury_B4?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `12[${j - 1}]_p${i + 1}`,
              value: injury_C4?.[((pages?.length - 1) * 4) + j] || ""
            },
          ])
        }
      }
    }




    let total_involved = [...pages];
    for (let i = 0; i < pages?.length; i++) {

      if (pages?.[i]?.length == 4) {
        for (let j = 1; j <= pages?.[i]?.length; j++) {
          result.push(...[

            {
              tabLabel: `all_involved[${j - 1}].name_of_person_p${i + 1}`,
              value: all_involved_name_of_person?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].vehicle_occupied_p${i + 1}`,
              value: all_involved_vehicle_occupied?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].position_vehicle_p${i + 1}`,
              value: all_involved_position_vehicle?.[(i * pages?.[i]?.length) + j] || ""
            },

            {
              tabLabel: `all_involved[${j - 1}].safety_equip_used_p${i + 1}`,
              value: all_involved_safety_equip_used?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].person_age_p${i + 1}`,
              value: all_involved_person_age?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].person_gender_p${i + 1}`,
              value: all_involved_person_gender?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].description_p${i + 1}`,
              value: all_involved_description?.[(i * pages?.[i]?.length) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].date_of_death_p${i + 1}`,
              value: all_involved_date_of_death?.[(i * pages?.[i]?.length) + j] || ""
            },
          ])
        }
      } else {
        for (let j = 1; j <= pages?.[i]?.length; j++) {
          result.push(...[
            {
              tabLabel: `all_involved[${j - 1}].name_of_person_p${i + 1}`,
              value: all_involved_name_of_person?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].vehicle_occupied_p${i + 1}`,
              value: all_involved_vehicle_occupied?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].position_vehicle_p${i + 1}`,
              value: all_involved_position_vehicle?.[((pages?.length - 1) * 4) + j] || ""
            },

            {
              tabLabel: `all_involved[${j - 1}].safety_equip_used_p${i + 1}`,
              value: all_involved_safety_equip_used?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].person_age_p${i + 1}`,
              value: all_involved_person_age?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].person_gender_p${i + 1}`,
              value: all_involved_person_gender?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].description_p${i + 1}`,
              value: all_involved_description?.[((pages?.length - 1) * 4) + j] || ""
            },
            {
              tabLabel: `all_involved[${j - 1}].date_of_death_p${i + 1}`,
              value: all_involved_date_of_death?.[((pages?.length - 1) * 4) + j] || ""
            },
          ])
        }
      }
    }



    for (let i = 0; i <= data?.vehicle_involved_list?.length; i++) {

      vehicle_involved_type_vehicle[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_type == "VEHICLE_2") ? str : " ";
      vehicle_involved_type_pedestrian[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_type == "PEDESTRIAN") ? str : " ";
      vehicle_involved_type_bycyclist[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_type == "BICYCLIST") ? str : " ";
      vehicle_involved_type_oher[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_type == "OTHER_PEDESTRIAN") ? str : " ";

      value_d[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_damage?.vehicle2_estimation == "$1,001-$1,500") ? str : " ";
      value_e[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_damage?.vehicle2_estimation == "$1,501-$2,500") ? str : " ";
      value_f[i + 1] = (data?.vehicle_involved_list?.[i]?.vehicle_damage?.vehicle2_estimation == "Over $2,500") ? str : " ";

      vehicle_involved_public_property_damaged[i + 1] = data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_public_property_damaged ? str : " ";

      result.push(...[
        // {
        //   tabLabel: "page",
        //   value: "1"
        // },
        // {
        //   tabLabel: "page_of",
        //   value: "2"
        // },
        {
          "tabLabel": "hide_page_no",
          fontColor: "white", // White text
          backgroundColor: "white", // White background
          value: "▆▆▆▆▆▆▆▆▆▆" ,
          "bold": true,
        },
        // {
        //   tabLabel: "hide_page_no",
        //   value: whiteColour
        // },
        {
          tabLabel: "rush_drive",
          value: rush || ""
        },
        {
          tabLabel: "accident_date",
          value: data?.accident_date || ""
        },
        {
          tabLabel: "accident_month",
          value: data?.accident_month || ""
        },
        {
          tabLabel: "accident_day",
          value: data?.accident_day || ""
        },
        {
          tabLabel: "accident_year",
          value: data?.accident_year || ""
        },
        {
          tabLabel: "day_of_week",
          value: data?.day_of_week?.substr(0, 3) || ""
        },
        {
          tabLabel: "accident_time",
          value: time || ""
        },
        {
          tabLabel: "am",
          value: am || ""
        },
        {
          tabLabel: "pm",
          value: pm || ""
        },
        {
          tabLabel: "number_of_vehicles",
          value: data?.number_of_vehicles || ""
        },
        {
          tabLabel: "number_of_injured",
          value: data?.number_of_injured || ""
        },
        {
          tabLabel: "number_of_killed",
          value: data?.number_of_killed || ""
        },
        {
          tabLabel: "police_investigated",
          value: data?.police_investigated || ""
        },
        {
          tabLabel: "police_investigated_yes",
          value: police_investigated_yes || ""
        },
        {
          tabLabel: "police_investigated_no",
          value: police_investigated_no || ""
        },
        {
          tabLabel: "police_agency",
          value: data?.police_agency || ""
        },
        //Driver
        {
          tabLabel: "license_number",
          value: data?.driver?.license_number || ""
        },
        {
          tabLabel: "license_state",
          value: data?.driver?.license_state || ""
        },
        {
          tabLabel: "driver_name",
          value: data?.driver?.driver_name || ""
        },
        {
          tabLabel: "driver_address",
          value: data?.driver?.driver_address || ""
        },
        {
          tabLabel: "driver_apt",
          value: data?.driver?.driver_apt || ""
        },
        {
          tabLabel: "driver_city",
          value: data?.driver?.driver_city || ""
        },
        {
          tabLabel: "driver_state",
          value: data?.driver?.driver_state || ""
        },
        {
          tabLabel: "driver_zipcode",
          value: data?.driver?.driver_zipcode || ""
        },
        {
          tabLabel: "driver_refid",
          value: data?.driver?.driver_refid || ""
        },
        {
          tabLabel: "driver_dob",
          value: data?.driver?.driver_dob || ""
        },
        {
          tabLabel: "driver_dob_month",
          value: data?.driver?.driver_dob_month || ""
        },
        {
          tabLabel: "driver_dob_day",
          value: data?.driver?.driver_dob_day || ""
        },
        {
          tabLabel: "driver_dob_year",
          value: data?.driver?.driver_dob_year || ""
        },
        {
          tabLabel: "driver_gender",
          value: data?.driver?.driver_gender || ""
        },
        {
          tabLabel: "number_of_people_in_vehicle",
          value: data?.driver?.number_of_people_in_vehicle || ""
        },
        {
          tabLabel: "public_property_damaged",
          value: public_property_damaged || ""
        },

        // {"vehicle_involved": null,},

        //Vehicle Involved
        {
          tabLabel: "vehicle_involved_type_vehicle",
          value: vehicle_involved_type_vehicle?.[1] || ""
        },
        {
          tabLabel: "vehicle_involved_type_pedestrian",
          value: vehicle_involved_type_pedestrian?.[1] || ""
        },
        {
          tabLabel: "vehicle_involved_type_bycyclist",
          value: vehicle_involved_type_bycyclist?.[1] || ""
        },
        {
          tabLabel: "vehicle_involved_type_oher",
          value: vehicle_involved_type_oher?.[1] || ""
        },
        {
          tabLabel: "vehicle_involved_license_number",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_license_number || ""
        },
        {
          tabLabel: "vehicle_involved_license_state",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_license_state || ""
        },
        {
          tabLabel: "vehicle_involved_driver_name",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_name || ""
        },
        {
          tabLabel: "vehicle_involved_driver_address",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_address || ""
        },
        {
          tabLabel: "vehicle_involved_driver_apt",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_apt || ""
        },
        {
          tabLabel: "vehicle_involved_driver_city",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_city || ""
        },
        {
          tabLabel: "vehicle_involved_driver_state",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_state || ""
        },
        {
          tabLabel: "vehicle_involved_driver_zipcode",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_zipcode || ""
        },
        {
          tabLabel: "vehicle_involved_driver_dob_month",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_dob_month || ""
        },
        {
          tabLabel: "vehicle_involved_driver_dob_day",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_dob_day || ""
        },
        {
          tabLabel: "vehicle_involved_driver_dob_year",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_dob_year || ""
        },
        {
          tabLabel: "vehicle_involved_driver_dob",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_dob || ""
        },
        {
          tabLabel: "vehicle_involved_driver_gender",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_driver_gender || ""
        },
        {
          tabLabel: "vehicle_involved_number_of_people_in_vehicle",
          value: data?.vehicle_involved_list?.[0]?.vehicle_involved?.vehicle_involved_number_of_people_in_vehicle || ""
        },
        {
          tabLabel: "vehicle_involved_public_property_damaged",
          value: vehicle_involved_public_property_damaged?.[1] || ""
        },


        // "accident_action": "2",  //to_do
        // "vehicle2_action": "",

        // Registrant

        {
          tabLabel: "registrant_name",
          value: data?.registrant?.registrant_name || ""
        },
        {
          tabLabel: "registrant_dob",
          value: data?.registrant?.registrant_dob || ""
        },
        {
          tabLabel: "registrant_dob_date",
          value: data?.registrant?.registrant_dob_date || ""
        },
        {
          tabLabel: "registrant_dob_month",
          value: data?.registrant?.registrant_dob_month || ""
        },
        {
          tabLabel: "registrant_dob_year",
          value: data?.registrant?.registrant_dob_year || ""
        },
        {
          tabLabel: "registrant_gender",
          value: data?.registrant?.registrant_gender || ""
        },
        {
          tabLabel: "registrant_address",
          value: data?.registrant?.registrant_address || ""
        },
        {
          tabLabel: "registrant_apt_number",
          value: data?.registrant?.registrant_apt_number || ""
        },
        {
          tabLabel: "registrant_city",
          value: data?.registrant?.registrant_city || ""
        },
        {
          tabLabel: "registrant_state",
          value: data?.registrant?.registrant_state || ""
        },
        {
          tabLabel: "registrant_zip_code",
          value: data?.registrant?.registrant_zip_code || ""
        },
        {
          tabLabel: "registrant_plate_number",
          value: data?.registrant?.registrant_plate_number || ""
        },
        {
          tabLabel: "registrant_state_of_reg",
          value: data?.registrant?.registrant_state_of_reg || ""
        },
        {
          tabLabel: "registrant_vehicle_year_make",
          value: data?.registrant?.registrant_vehicle_year_make || ""
        },
        {
          tabLabel: "registrant_vehicle_type",
          value: data?.registrant?.registrant_vehicle_type || ""
        },
        {
          tabLabel: "registrant_ins_code",
          value: data?.registrant?.registrant_ins_code || ""
        },

        // Vehicle Registrant

        {
          tabLabel: "vehicle2_name",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_name || ""
        },
        {
          tabLabel: "vehicle2_dob",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_dob || ""
        },
        {
          tabLabel: "vehicle2_dob_date",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_dob_date || ""
        },
        {
          tabLabel: "vehicle2_dob_month",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_dob_month || ""
        },
        {
          tabLabel: "vehicle2_dob_year",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_dob_year || ""
        },
        {
          tabLabel: "vehicle2_gender",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_gender || ""
        },
        {
          tabLabel: "vehicle2_address",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_address || ""
        },
        {
          tabLabel: "vehicle2_apt_number",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_apt_number || ""
        },
        {
          tabLabel: "vehicle2_city",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_city || ""
        },
        {
          tabLabel: "vehicle2_zip_code",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_zip_code || ""
        },
        {
          tabLabel: "vehicle2_plate_number",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_plate_number || ""
        },
        {
          tabLabel: "vehicle2_state_of_reg",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_state_of_reg || ""
        },
        {
          tabLabel: "vehicle2_vehicle_year_make",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_vehicle_year_make || ""
        },
        {
          tabLabel: "vehicle2_vehicle_type",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_vehicle_type || ""
        },
        {
          tabLabel: "vehicle2_ins_code",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_ins_code || ""
        },
        {
          tabLabel: "vehicle2_state",
          value: data?.vehicle_involved_list?.[0]?.vehicle_registrant?.vehicle2_state || ""
        },

        //Vehicle_Damage

        {
          tabLabel: "vehicle_estimation",
          value: data?.vehicle_damage?.vehicle_estimation || ""
        },
        {
          tabLabel: "vehicle2_estimation",
          value: data?.vehicle_involved_list?.[0]?.vehicle_damage?.vehicle2_estimation || ""
        },
        {
          tabLabel: "vehicle_damage_description",
          value: data?.vehicle_damage?.vehicle_damage_description || ""
        },
        {
          tabLabel: "vehicle2_damage_description",
          value: data?.vehicle_involved_list?.[0]?.vehicle_damage?.vehicle2_damage_description || ""
        },
        {
          tabLabel: "accident_diagram",
          value: data?.vehicle_damage?.accident_diagram || ""
        },
        {
          tabLabel: "accident_image",
          value: data?.vehicle_damage?.accident_image || ""
        },
        {
          tabLabel: "vehicle1_estimation_a",
          value: vehicle1_estimation_a || ""
        },
        {
          tabLabel: "vehicle1_estimation_b",
          value: vehicle1_estimation_b || ""
        },
        {
          tabLabel: "vehicle1_estimation_c",
          value: vehicle1_estimation_c || ""
        },
        {
          tabLabel: "vehicle2_estimation_a",
          value: value_d?.[1] || ""
        },
        {
          tabLabel: "vehicle2_estimation_b",
          value: value_e?.[1] || ""
        },
        {
          tabLabel: "vehicle2_estimation_c",
          value: value_f?.[1] || ""
        },

        //accident_location

        {
          tabLabel: "county",
          value: data?.accidents_location?.county || ""
        },
        {
          tabLabel: "location_type",
          value: data?.accidents_location?.location_type || ""
        },
        {
          tabLabel: "accidents_location_city",
          value: accidents_location_city || ""
        },
        {
          tabLabel: "accidents_location_village",
          value: accidents_location_village || ""
        },
        {
          tabLabel: "accidents_location_town",
          value: accidents_location_town || ""
        },
        {
          tabLabel: "location_text",
          value: data?.accidents_location?.location_text || ""
        },
        {
          tabLabel: "landmark",
          value: data?.accidents_location?.landmark || ""
        },
        {
          tabLabel: "road",
          value: data?.accidents_location?.road || ""
        },
        {
          tabLabel: "intersecting_street",
          value: data?.accidents_location?.intersecting_street || ""
        },
        {
          tabLabel: "feet",
          value: data?.accidents_location?.feet || ""
        },
        {
          tabLabel: "miles",
          value: data?.accidents_location?.miles || ""
        },
        {
          tabLabel: "nearest_route",
          value: data?.accidents_location?.nearest_route || ""
        },
        {
          tabLabel: "how_happend",
          value: "                                            " + data?.accidents_location?.how_happend || ""
        },
        {
          tabLabel: "acccident_location_check_1",
          value: acccident_location_check_1 || ""
        },
        {
          tabLabel: "direction_north",
          value: direction_north
        },
        {
          tabLabel: "direction_south",
          value: direction_south
        },
        {
          tabLabel: "direction_east",
          value: direction_east
        },
        {
          tabLabel: "direction_west",
          value: direction_west
        },


        //All_involved
        //all_involved[0].name_of_person
        {
          tabLabel: "all_involved[0].name_of_person",
          value: data?.all_involved?.[0]?.name_of_person || ""
        },
        {
          // tabLabel: "All_involved_injury_A1",
          tabLabel: "1",

          value: injuryA1 || ""
        },
        {
          tabLabel: "2",
          value: injuryB1 || ""
        },
        {
          tabLabel: "3",
          value: injuryC1 || ""
        },
        {
          tabLabel: "all_involved[0].vehicle_occupied",
          value: data?.all_involved?.[0]?.vehicle_occupied || ""
        },
        {
          tabLabel: "all_involved[0].position_vehicle",
          value: data?.all_involved?.[0]?.position_vehicle || ""
        },
        {
          tabLabel: "all_involved[0].safety_equip_used",
          value: data?.all_involved?.[0]?.safety_equip_used || ""
        },
        {
          tabLabel: "all_involved[0].person_age",
          value: data?.all_involved?.[0]?.person_age || ""
        },
        {
          tabLabel: "all_involved[0].person_gender",
          value: data?.all_involved?.[0]?.person_gender || ""
        },
        {
          tabLabel: "all_involved[0].description",
          value: data?.all_involved?.[0]?.description || ""
        },
        {
          tabLabel: "all_involved[0].date_of_death",
          value: data?.all_involved?.[0]?.date_of_death || ""
        },


        {
          tabLabel: "all_involved[1].name_of_person",
          value: data?.all_involved?.[1]?.name_of_person || ""
        },
        {
          tabLabel: "4",
          value: injuryA2 || ""
        },
        {
          tabLabel: "5",
          value: injuryB2 || ""
        },
        {
          tabLabel: "6",
          value: injuryC2 || ""
        },
        {
          tabLabel: "all_involved[1].vehicle_occupied",
          value: data?.all_involved?.[1]?.vehicle_occupied || ""
        },
        {
          tabLabel: "all_involved[1].position_vehicle",
          value: data?.all_involved?.[1]?.position_vehicle || ""
        },
        {
          tabLabel: "all_involved[1].safety_equip_used",
          value: data?.all_involved?.[1]?.safety_equip_used || ""
        },
        {
          tabLabel: "all_involved[1].person_age",
          value: data?.all_involved?.[1]?.person_age || ""
        },
        {
          tabLabel: "all_involved[1].person_gender",
          value: data?.all_involved?.[1]?.person_gender || ""
        },
        {
          tabLabel: "all_involved[1].description",
          value: data?.all_involved?.[1]?.description || ""
        },
        {
          tabLabel: "all_involved[1].date_of_death",
          value: data?.all_involved?.[1]?.date_of_death || ""
        },


        {
          tabLabel: "all_involved[2].name_of_person",
          value: data?.all_involved?.[2]?.name_of_person || ""
        },
        {
          tabLabel: "7",
          value: injuryA3 || ""
        },
        {
          tabLabel: "8",
          value: injuryB3 || ""
        },
        {
          tabLabel: "9",
          value: injuryC3 || ""
        },
        {
          tabLabel: "all_involved[2].vehicle_occupied",
          value: data?.all_involved?.[2]?.vehicle_occupied || ""
        },
        {
          tabLabel: "all_involved[2].position_vehicle",
          value: data?.all_involved?.[2]?.position_vehicle || ""
        },
        {
          tabLabel: "all_involved[2].safety_equip_used",
          value: data?.all_involved?.[2]?.safety_equip_used || ""
        },
        {
          tabLabel: "all_involved[2].person_age",
          value: data?.all_involved?.[2]?.person_age || ""
        },
        {
          tabLabel: "all_involved[2].person_gender",
          value: data?.all_involved?.[2]?.person_gender || ""
        },
        {
          tabLabel: "all_involved[2].description",
          value: data?.all_involved?.[2]?.description || ""
        },
        {
          tabLabel: "all_involved[2].date_of_death",
          value: data?.all_involved?.[2]?.date_of_death || ""
        },


        {
          tabLabel: "all_involved[3].name_of_person",
          value: data?.all_involved?.[3]?.name_of_person || ""
        },
        {
          tabLabel: "10",
          value: injuryA4 || ""
        },
        {
          tabLabel: "11",
          value: injuryB4 || ""
        },
        {
          tabLabel: "12",
          value: injuryC4 || ""
        },
        {
          tabLabel: "all_involved[2].vehicle_occupied",
          value: data?.all_involved?.[2]?.vehicle_occupied || ""
        },
        {
          tabLabel: "all_involved[2].position_vehicle",
          value: data?.all_involved?.[2]?.position_vehicle || ""
        },

        {
          tabLabel: "all_involved[3].vehicle_occupied",
          value: data?.all_involved?.[3]?.vehicle_occupied || ""
        },
        {
          tabLabel: "all_involved[3].position_vehicle",
          value: data?.all_involved?.[3]?.position_vehicle || ""
        },
        {
          tabLabel: "all_involved[3].safety_equip_used",
          value: data?.all_involved?.[3]?.safety_equip_used || ""
        },
        {
          tabLabel: "all_involved[3].person_age",
          value: data?.all_involved?.[3]?.person_age || ""
        },
        {
          tabLabel: "all_involved[3].person_gender",
          value: data?.all_involved?.[3]?.person_gender || ""
        },
        {
          tabLabel: "all_involved[3].description",
          value: data?.all_involved?.[3]?.description || ""
        },
        {
          tabLabel: "all_involved[3].date_of_death",
          value: data?.all_involved?.[3]?.date_of_death || ""
        },


        //Insurance

        {
          tabLabel: "damaged_property",
          value: data?.insurance?.damaged_property || ""
        },
        {
          tabLabel: "vin",
          value: data?.insurance?.vin || ""
        },
        {
          tabLabel: "insurance_company",
          value: data?.insurance?.insurance_company || ""
        },
        {
          tabLabel: "policy_number",
          value: data?.insurance?.policy_number || ""
        },
        {
          tabLabel: "address_of_policy_holder",
          value: data?.insurance?.address_of_policy_holder || ""
        },
        {
          tabLabel: "policy_valid_from",
          value: moment(data?.insurance?.policy_valid_from)?.format("MM-DD-YYYY") || ""
        },
        {
          tabLabel: "policy_valid_to",
          value: data?.insurance?.policy_valid_to || ""
        },
        {
          tabLabel: "policy_expiry",
          value: moment(data?.insurance?.policy_expiry)?.format("MM-DD-YYYY") || ""
        },
        {
          tabLabel: "vehicle_permit_number",
          value: data?.insurance?.vehicle_permit_number || ""
        },
        {
          tabLabel: "address_of_permit_holder",
          value: data?.insurance?.address_of_permit_holder || ""
        },
        {
          tabLabel: "certificate_no",
          value: data?.insurance?.certificate_no || ""
        },
        {
          tabLabel: "insurance_state",
          value: data?.insurance?.insurance_state || ""
        },
        {
          tabLabel: "submitted_date",
          value: moment(data?.insurance?.submitted_date)?.format("MM-DD-YYYY") || ""
        },
        {
          tabLabel: "vehicle1_driver",
          value: data?.insurance?.vehicle1_driver || Name || ""
        },
        {
          tabLabel: "policy_number",
          value: data?.insurance?.policy_number || ""
        },
        {
          tabLabel: "injury",
          value: injury || ""
        },
        {
          tabLabel: "death",
          value: death || ""
        },

        // SideBar

        {
          tabLabel: "accident_location",
          value: data?.vehicle_involved_list?.[i]?.accident_location || ""
        },
        {
          tabLabel: "accident_action",
          value: data?.accident_action || ""
        },
        {
          tabLabel: "traffic_control",
          value: data?.traffic_control || ""
        },
        {
          tabLabel: "light_conditions",
          value: data?.light_conditions || ""
        },
        {
          tabLabel: "roadway_character",
          value: data?.roadway_character || ""
        },
        {
          tabLabel: "roadway_surface_condtion",
          value: data?.roadway_surface_condtion || ""
        },
        {
          tabLabel: "weather",
          value: data?.weather || ""
        },
        {
          tabLabel: "vehicle1_travel_direction",
          value: data?.vehicle1_travel_direction || ""
        },
        {
          tabLabel: "vehicle2_travel_direction",
          value: data?.vehicle2_travel_direction || ""
        },
        {
          tabLabel: "vehicle1_action",
          value: data?.vehicle1_action || ""
        },
        {
          tabLabel: "vehicle2_action",
          value: data?.vehicle2_action || ""
        },
        {
          tabLabel: "location_of_first_event",
          value: data?.location_of_first_event || ""
        },
        {
          tabLabel: "accident_type",
          value: data?.accident_type || ""
        },
        {
          tabLabel: "vehicle1_second_event",
          value: data?.vehicle1_second_event || ""
        },
        {
          tabLabel: "vehicle2_second_event",
          value: data?.vehicle2_second_event || ""
        },


        // ## page_2 data



        //Vehicle Involved
        // {
        //   tabLabel: `vehicle_involved_type_vehicle_p${i + 1}`,
        //   value: vehicle_involved_type_vehicle || ""
        // },
        // {
        //   tabLabel: `vehicle_involved_type_pedestrian_p${i + 1}`,
        //   value: vehicle_involved_type_pedestrian || ""
        // },
        // {
        //   tabLabel: `vehicle_involved_type_bycyclist_p${i + 1}`,
        //   value: vehicle_involved_type_bycyclist || ""
        // },
        // {
        //   tabLabel: `vehicle_involved_type_oher_p${i + 1}`,
        //   value: vehicle_involved_type_oher || ""
        // },
        {
          tabLabel: `vehicle_involved_license_number_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_license_number || ""
        },
        {
          tabLabel: `vehicle_involved_license_state_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_license_state || ""
        },
        {
          tabLabel: `vehicle_involved_driver_name_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_name || ""
        },
        {
          tabLabel: `vehicle_involved_driver_address_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_address || ""
        },
        {
          tabLabel: `vehicle_involved_driver_apt_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_apt || ""
        },
        {
          tabLabel: `vehicle_involved_driver_city_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_city || ""
        },
        {
          tabLabel: `vehicle_involved_driver_state_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_state || ""
        },
        {
          tabLabel: `vehicle_involved_driver_zipcode_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_zipcode || ""
        },
        {
          tabLabel: `vehicle_involved_driver_dob_month_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_dob_month || ""
        },
        {
          tabLabel: `vehicle_involved_driver_dob_day_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_dob_day || ""
        },
        {
          tabLabel: `vehicle_involved_driver_dob_year_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_dob_year || ""
        },
        {
          tabLabel: `vehicle_involved_driver_dob_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_dob || ""
        },
        {
          tabLabel: `vehicle_involved_driver_gender_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_driver_gender || ""
        },
        {
          tabLabel: `vehicle_involved_number_of_people_in_vehicle_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_involved?.vehicle_involved_number_of_people_in_vehicle || ""
        },



        // Vehicle Registrant

        {
          tabLabel: `vehicle2_name_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_name || ""
        },
        {
          tabLabel: `vehicle2_dob_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_dob || ""
        },
        {
          tabLabel: `vehicle2_dob_date_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_dob_date || ""
        },
        {
          tabLabel: `vehicle2_dob_month_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_dob_month || ""
        },
        {
          tabLabel: `vehicle2_dob_year_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_dob_year || ""
        },
        {
          tabLabel: `vehicle2_gender_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_gender || ""
        },
        {
          tabLabel: `vehicle2_address_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_address || ""
        },
        {
          tabLabel: `vehicle2_apt_number_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_apt_number || ""
        },
        {
          tabLabel: `vehicle2_city_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_city || ""
        },
        {
          tabLabel: `vehicle2_zip_code_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_zip_code || ""
        },
        {
          tabLabel: `vehicle2_plate_number_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_plate_number || ""
        },
        {
          tabLabel: `vehicle2_state_of_reg_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_state_of_reg || ""
        },
        {
          tabLabel: `vehicle2_vehicle_year_make_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_vehicle_year_make || ""
        },
        {
          tabLabel: `vehicle2_vehicle_type_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_vehicle_type || ""
        },
        {
          tabLabel: `vehicle2_ins_code_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_ins_code || ""
        },
        {
          tabLabel: `vehicle2_state_p${i + 1}`,
          value: data?.vehicle_involved_list?.[i]?.vehicle_registrant?.vehicle2_state || ""
        },


        // //haha

        {
          tabLabel: "accident_location_p2",
          value: data?.vehicle_involved_list?.[i]?.accident_location || ""
        },
        {
          tabLabel: "vehicle2_estimation_p2",
          value: data?.vehicle_involved_list?.[i]?.vehicle_damage?.vehicle2_estimation || ""
        },
        {
          tabLabel: "vehicle2_damage_description_p2",
          value: data?.vehicle_involved_list?.[i]?.vehicle_damage?.vehicle2_damage_description || ""
        },
        {
          tabLabel: `vehicle2_estimation_a_p${i}`,
          value: value_d?.[i] || ""
        },
        {
          tabLabel: `vehicle2_estimation_b_p${i}`,
          value: value_e?.[i] || ""
        },
        {
          tabLabel: `vehicle2_estimation_c_p${i}`,
          value: value_f?.[i] || ""
        },


        //checkbox

        {
          tabLabel: `vehicle_involved_type_vehicle_p${i}`,
          value: vehicle_involved_type_vehicle?.[i] || ""
        },
        {
          tabLabel: `vehicle_involved_type_pedestrian_p${i}`,
          value: vehicle_involved_type_pedestrian?.[i] || ""
        },
        {
          tabLabel: `vehicle_involved_type_bycyclist_p${i}`,
          value: vehicle_involved_type_bycyclist?.[i] || ""
        },
        {
          tabLabel: `vehicle_involved_type_oher_p${i}`,
          value: vehicle_involved_type_oher?.[i] || ""
        },

        {
          tabLabel: `vehicle_involved_public_property_damaged_p${i}`,
          value: vehicle_involved_public_property_damaged?.[i] || ""
        },

      ])
    }

    return result;
  } else {
    console.log("NO length in prefill")
    result.push(...[
      {
        "tabLabel": "hide_page_no",
        fontColor: "white", // White text
        backgroundColor: "white", // White background
        value: "▆▆▆▆▆▆▆▆▆▆▆▆▆" ,
        "bold": true,
      },
      // {
      //   tabLabel: "hide_page_no",
      //   value: whiteColour
      // },
      {
        tabLabel: "rush_drive",
        value: rush || ""
      },
      {
        tabLabel: "accident_date",
        value: data?.accident_date || ""
      },
      {
        tabLabel: "accident_month",
        value: data?.accident_month || ""
      },
      {
        tabLabel: "accident_day",
        value: data?.accident_day || ""
      },
      {
        tabLabel: "accident_year",
        value: data?.accident_year || ""
      },
      {
        tabLabel: "day_of_week",
        value: data?.day_of_week.substr(0, 3) || ""
      },
      {
        tabLabel: "accident_time",
        value: time || ""
      },
      {
        tabLabel: "am",
        value: am || ""
      },
      {
        tabLabel: "pm",
        value: pm || ""
      },
      {
        tabLabel: "number_of_vehicles",
        value: data?.number_of_vehicles || ""
      },
      {
        tabLabel: "number_of_injured",
        value: data?.number_of_injured || ""
      },
      {
        tabLabel: "number_of_killed",
        value: data?.number_of_killed || ""
      },
      {
        tabLabel: "police_investigated",
        value: data?.police_investigated || ""
      },
      {
        tabLabel: "police_investigated_yes",
        value: police_investigated_yes || ""
      },
      {
        tabLabel: "police_investigated_no",
        value: police_investigated_no || ""
      },
      {
        tabLabel: "police_agency",
        value: data?.police_agency || ""
      },
      //Driver
      {
        tabLabel: "license_number",
        value: data?.driver?.license_number || ""
      },
      {
        tabLabel: "license_state",
        value: data?.driver?.license_state || ""
      },
      {
        tabLabel: "driver_name",
        value: data?.driver?.driver_name || ""
      },
      {
        tabLabel: "driver_address",
        value: data?.driver?.driver_address || ""
      },
      {
        tabLabel: "driver_apt",
        value: data?.driver?.driver_apt || ""
      },
      {
        tabLabel: "driver_city",
        value: data?.driver?.driver_city || ""
      },
      {
        tabLabel: "driver_state",
        value: data?.driver?.driver_state || ""
      },
      {
        tabLabel: "driver_zipcode",
        value: data?.driver?.driver_zipcode || ""
      },
      {
        tabLabel: "driver_refid",
        value: data?.driver?.driver_refid || ""
      },
      {
        tabLabel: "driver_dob",
        value: data?.driver?.driver_dob || ""
      },
      {
        tabLabel: "driver_dob_month",
        value: data?.driver?.driver_dob_month || ""
      },
      {
        tabLabel: "driver_dob_day",
        value: data?.driver?.driver_dob_day || ""
      },
      {
        tabLabel: "driver_dob_year",
        value: data?.driver?.driver_dob_year || ""
      },
      {
        tabLabel: "driver_gender",
        value: data?.driver?.driver_gender || ""
      },
      {
        tabLabel: "number_of_people_in_vehicle",
        value: data?.driver?.number_of_people_in_vehicle || ""
      },
      {
        tabLabel: "public_property_damaged",
        value: public_property_damaged || ""
      },

      // {"vehicle_involved": null,},

      //Vehicle Involved
      {
        tabLabel: "vehicle_involved_type_vehicle",
        value: vehicle_involved_type_vehicle?.[0] || ""
      },
      {
        tabLabel: "vehicle_involved_type_pedestrian",
        value: vehicle_involved_type_pedestrian?.[0] || ""
      },
      {
        tabLabel: "vehicle_involved_type_bycyclist",
        value: vehicle_involved_type_bycyclist?.[0] || ""
      },
      {
        tabLabel: "vehicle_involved_type_oher",
        value: vehicle_involved_type_oher?.[0] || ""
      },

      {
        tabLabel: "vehicle_involved_public_property_damaged",
        value: vehicle_involved_public_property_damaged || ""
      },


      // "accident_action": "2",  //to_do
      // "vehicle2_action": "",

      // Registrant

      {
        tabLabel: "registrant_name",
        value: data?.registrant?.registrant_name || ""
      },
      {
        tabLabel: "registrant_dob",
        value: data?.registrant?.registrant_dob || ""
      },
      {
        tabLabel: "registrant_dob_date",
        value: data?.registrant?.registrant_dob_date || ""
      },
      {
        tabLabel: "registrant_dob_month",
        value: data?.registrant?.registrant_dob_month || ""
      },
      {
        tabLabel: "registrant_dob_year",
        value: data?.registrant?.registrant_dob_year || ""
      },
      {
        tabLabel: "registrant_gender",
        value: data?.registrant?.registrant_gender || ""
      },
      {
        tabLabel: "registrant_address",
        value: data?.registrant?.registrant_address || ""
      },
      {
        tabLabel: "registrant_apt_number",
        value: data?.registrant?.registrant_apt_number || ""
      },
      {
        tabLabel: "registrant_city",
        value: data?.registrant?.registrant_city || ""
      },
      {
        tabLabel: "registrant_state",
        value: data?.registrant?.registrant_state || ""
      },
      {
        tabLabel: "registrant_zip_code",
        value: data?.registrant?.registrant_zip_code || ""
      },
      {
        tabLabel: "registrant_plate_number",
        value: data?.registrant?.registrant_plate_number || ""
      },
      {
        tabLabel: "registrant_state_of_reg",
        value: data?.registrant?.registrant_state_of_reg || ""
      },
      {
        tabLabel: "registrant_vehicle_year_make",
        value: data?.registrant?.registrant_vehicle_year_make || ""
      },
      {
        tabLabel: "registrant_vehicle_type",
        value: data?.registrant?.registrant_vehicle_type || ""
      },
      {
        tabLabel: "registrant_ins_code",
        value: data?.registrant?.registrant_ins_code || ""
      },

      // Vehicle Registrant



      //Vehicle_Damage

      {
        tabLabel: "vehicle_estimation",
        value: data?.vehicle_damage?.vehicle_estimation || ""
      },

      {
        tabLabel: "vehicle_damage_description",
        value: data?.vehicle_damage?.vehicle_damage_description || ""
      },
      {
        tabLabel: "accident_diagram",
        value: data?.vehicle_damage?.accident_diagram || ""
      },
      {
        tabLabel: "accident_image",
        value: data?.vehicle_damage?.accident_image || ""
      },
      {
        tabLabel: "vehicle1_estimation_a",
        value: vehicle1_estimation_a
      },
      {
        tabLabel: "vehicle1_estimation_b",
        value: vehicle1_estimation_b
      },
      {
        tabLabel: "vehicle1_estimation_c",
        value: vehicle1_estimation_c
      },
      {
        tabLabel: "vehicle2_estimation_a",
        value: vehicle1_estimation_d
      },
      {
        tabLabel: "vehicle2_estimation_b",
        value: vehicle1_estimation_e
      },
      {
        tabLabel: "vehicle2_estimation_c",
        value: vehicle1_estimation_f
      },

      //accident_location

      {
        tabLabel: "county",
        value: data?.accidents_location?.county || ""
      },
      {
        tabLabel: "location_type",
        value: data?.accidents_location?.location_type || ""
      },
      {
        tabLabel: "accidents_location_city",
        value: accidents_location_city || ""
      },
      {
        tabLabel: "accidents_location_village",
        value: accidents_location_village || ""
      },
      {
        tabLabel: "accidents_location_town",
        value: accidents_location_town || ""
      },
      {
        tabLabel: "location_text",
        value: data?.accidents_location?.location_text || ""
      },
      {
        tabLabel: "landmark",
        value: data?.accidents_location?.landmark || ""
      },
      {
        tabLabel: "road",
        value: data?.accidents_location?.road || ""
      },
      {
        tabLabel: "intersecting_street",
        value: data?.accidents_location?.intersecting_street || ""
      },
      {
        tabLabel: "feet",
        value: data?.accidents_location?.feet || ""
      },
      {
        tabLabel: "miles",
        value: data?.accidents_location?.miles || ""
      },
      {
        tabLabel: "nearest_route",
        value: data?.accidents_location?.nearest_route || ""
      },
      {
        tabLabel: "how_happend",
        value: "                                            " + data?.accidents_location?.how_happend || ""
      },
      {
        tabLabel: "acccident_location_check_1",
        value: acccident_location_check_1 || ""
      },
      {
        tabLabel: "direction_north",
        value: direction_north
      },
      {
        tabLabel: "direction_south",
        value: direction_south
      },
      {
        tabLabel: "direction_east",
        value: direction_east
      },
      {
        tabLabel: "direction_west",
        value: direction_west
      },



      //All_involved
      //all_involved[0].name_of_person
      {
        tabLabel: "all_involved[0].name_of_person",
        value: data?.all_involved?.[0]?.name_of_person || ""
      },
      {
        // tabLabel: "All_involved_injury_A1",
        tabLabel: "1",

        value: injuryA1 || ""
      },
      {
        tabLabel: "2",
        value: injuryB1 || ""
      },
      {
        tabLabel: "3",
        value: injuryC1 || ""
      },
      {
        tabLabel: "all_involved[0].vehicle_occupied",
        value: data?.all_involved?.[0]?.vehicle_occupied || ""
      },
      {
        tabLabel: "all_involved[0].position_vehicle",
        value: data?.all_involved?.[0]?.position_vehicle || ""
      },
      {
        tabLabel: "all_involved[0].safety_equip_used",
        value: data?.all_involved?.[0]?.safety_equip_used || ""
      },
      {
        tabLabel: "all_involved[0].person_age",
        value: data?.all_involved?.[0]?.person_age || ""
      },
      {
        tabLabel: "all_involved[0].person_gender",
        value: data?.all_involved?.[0]?.person_gender || ""
      },
      {
        tabLabel: "all_involved[0].description",
        value: data?.all_involved?.[0]?.description || ""
      },
      {
        tabLabel: "all_involved[0].date_of_death",
        value: data?.all_involved?.[0]?.date_of_death || ""
      },


      {
        tabLabel: "all_involved[1].name_of_person",
        value: data?.all_involved?.[1]?.name_of_person || ""
      },
      {
        tabLabel: "4",
        value: injuryA2 || ""
      },
      {
        tabLabel: "5",
        value: injuryB2 || ""
      },
      {
        tabLabel: "6",
        value: injuryC2 || ""
      },
      {
        tabLabel: "all_involved[1].vehicle_occupied",
        value: data?.all_involved?.[1]?.vehicle_occupied || ""
      },
      {
        tabLabel: "all_involved[1].position_vehicle",
        value: data?.all_involved?.[1]?.position_vehicle || ""
      },
      {
        tabLabel: "all_involved[1].safety_equip_used",
        value: data?.all_involved?.[1]?.safety_equip_used || ""
      },
      {
        tabLabel: "all_involved[1].person_age",
        value: data?.all_involved?.[1]?.person_age || ""
      },
      {
        tabLabel: "all_involved[1].person_gender",
        value: data?.all_involved?.[1]?.person_gender || ""
      },
      {
        tabLabel: "all_involved[1].description",
        value: data?.all_involved?.[1]?.description || ""
      },
      {
        tabLabel: "all_involved[1].date_of_death",
        value: data?.all_involved?.[1]?.date_of_death || ""
      },


      {
        tabLabel: "all_involved[2].name_of_person",
        value: data?.all_involved?.[2]?.name_of_person || ""
      },
      {
        tabLabel: "7",
        value: injuryA3 || ""
      },
      {
        tabLabel: "8",
        value: injuryB3 || ""
      },
      {
        tabLabel: "9",
        value: injuryC3 || ""
      },
      {
        tabLabel: "all_involved[2].vehicle_occupied",
        value: data?.all_involved?.[2]?.vehicle_occupied || ""
      },
      {
        tabLabel: "all_involved[2].position_vehicle",
        value: data?.all_involved?.[2]?.position_vehicle || ""
      },
      {
        tabLabel: "all_involved[2].safety_equip_used",
        value: data?.all_involved?.[2]?.safety_equip_used || ""
      },
      {
        tabLabel: "all_involved[2].person_age",
        value: data?.all_involved?.[2]?.person_age || ""
      },
      {
        tabLabel: "all_involved[2].person_gender",
        value: data?.all_involved?.[2]?.person_gender || ""
      },
      {
        tabLabel: "all_involved[2].description",
        value: data?.all_involved?.[2]?.description || ""
      },
      {
        tabLabel: "all_involved[2].date_of_death",
        value: data?.all_involved?.[2]?.date_of_death || ""
      },


      {
        tabLabel: "all_involved[3].name_of_person",
        value: data?.all_involved?.[3]?.name_of_person || ""
      },
      {
        tabLabel: "10",
        value: injuryA4 || ""
      },
      {
        tabLabel: "11",
        value: injuryB4 || ""
      },
      {
        tabLabel: "12",
        value: injuryC4 || ""
      },
      {
        tabLabel: "all_involved[2].vehicle_occupied",
        value: data?.all_involved?.[2]?.vehicle_occupied || ""
      },
      {
        tabLabel: "all_involved[2].position_vehicle",
        value: data?.all_involved?.[2]?.position_vehicle || ""
      },

      {
        tabLabel: "all_involved[3].vehicle_occupied",
        value: data?.all_involved?.[3]?.vehicle_occupied || ""
      },
      {
        tabLabel: "all_involved[3].position_vehicle",
        value: data?.all_involved?.[3]?.position_vehicle || ""
      },
      {
        tabLabel: "all_involved[3].safety_equip_used",
        value: data?.all_involved?.[3]?.safety_equip_used || ""
      },
      {
        tabLabel: "all_involved[3].person_age",
        value: data?.all_involved?.[3]?.person_age || ""
      },
      {
        tabLabel: "all_involved[3].person_gender",
        value: data?.all_involved?.[3]?.person_gender || ""
      },
      {
        tabLabel: "all_involved[3].description",
        value: data?.all_involved?.[3]?.description || ""
      },
      {
        tabLabel: "all_involved[3].date_of_death",
        value: data?.all_involved?.[3]?.date_of_death || ""
      },


      //Insurance

      {
        tabLabel: "damaged_property",
        value: data?.insurance?.damaged_property || ""
      },
      {
        tabLabel: "vin",
        value: data?.insurance?.vin || ""
      },
      {
        tabLabel: "insurance_company",
        value: data?.insurance?.insurance_company || ""
      },
      {
        tabLabel: "policy_number",
        value: data?.insurance?.policy_number || ""
      },
      {
        tabLabel: "address_of_policy_holder",
        value: data?.insurance?.address_of_policy_holder || ""
      },
      {
        tabLabel: "policy_valid_from",
        value: moment(data?.insurance?.policy_valid_from)?.format("MM-DD-YYYY") || ""
      },
      {
        tabLabel: "policy_valid_to",
        value: data?.insurance?.policy_valid_to || ""
      },
      {
        tabLabel: "policy_expiry",
        value: moment(data?.insurance?.policy_expiry)?.format("MM-DD-YYYY") || ""
      },
      {
        tabLabel: "vehicle_permit_number",
        value: data?.insurance?.vehicle_permit_number || ""
      },
      {
        tabLabel: "address_of_permit_holder",
        value: data?.insurance?.address_of_permit_holder || ""
      },
      {
        tabLabel: "certificate_no",
        value: data?.insurance?.certificate_no || ""
      },
      {
        tabLabel: "insurance_state",
        value: data?.insurance?.insurance_state || ""
      },
      {
        tabLabel: "submitted_date",
        value: moment(data?.insurance?.submitted_date)?.format("MM-DD-YYYY") || ""
      },
      {
        tabLabel: "vehicle1_driver",
        value: data?.insurance?.vehicle1_driver || Name || ""
      },
      {
        tabLabel: "policy_number",
        value: data?.insurance?.policy_number || ""
      },
      {
        tabLabel: "injury",
        value: injury || ""
      },
      {
        tabLabel: "death",
        value: death || ""
      },

      // SideBar

      {
        tabLabel: "accident_action",
        value: data?.accident_action || ""
      },
      {
        tabLabel: "traffic_control",
        value: data?.traffic_control || ""
      },
      {
        tabLabel: "light_conditions",
        value: data?.light_conditions || ""
      },
      {
        tabLabel: "roadway_character",
        value: data?.roadway_character || ""
      },
      {
        tabLabel: "roadway_surface_condtion",
        value: data?.roadway_surface_condtion || ""
      },
      {
        tabLabel: "weather",
        value: data?.weather || ""
      },
      {
        tabLabel: "vehicle1_travel_direction",
        value: data?.vehicle1_travel_direction || ""
      },
      {
        tabLabel: "vehicle2_travel_direction",
        value: data?.vehicle2_travel_direction || ""
      },
      {
        tabLabel: "vehicle1_action",
        value: data?.vehicle1_action || ""
      },
      {
        tabLabel: "vehicle2_action",
        value: data?.vehicle2_action || ""
      },
      {
        tabLabel: "location_of_first_event",
        value: data?.location_of_first_event || ""
      },
      {
        tabLabel: "accident_type",
        value: data?.accident_type || ""
      },
      {
        tabLabel: "vehicle1_second_event",
        value: data?.vehicle1_second_event || ""
      },
      {
        tabLabel: "vehicle2_second_event",
        value: data?.vehicle2_second_event || ""
      },



    ])

    return result;

  }

}






//#################################################
export const prefillDetails = (data, Role) => {

  if (Role == 'driver') {
    return [
      //Section-1 Driver Data
      {
        tabLabel: "driverName",
        value: data?.driver?.firstname + " " + data?.driver?.lastname
      },
      {
        tabLabel: "driverLicense",
        value: data?.driver?.driver_license_number
      },
      {
        tabLabel: "driverGender",
        value: data?.driver?.gender
      },
      {
        tabLabel: "driverCity",
        value: data?.driver?.city
      },
      {
        tabLabel: "driverZipcode",
        value: data?.driver?.zip_code
      },
      {
        tabLabel: "driverAddress",
        value: data?.driver?.address_line_1 + " , " + data?.driver?.address_line_2
      },
      {
        tabLabel: "driverYearOfBirth",
        value: data?.driver?.dob?.split('-')[0]
      },
      {
        tabLabel: "driverMonthOfBirth",
        value: data?.driver?.dob?.split('-')[1]
      },
      {
        tabLabel: "driverDayOfBirth",
        value: data?.driver?.dob?.split('-')[2]
      },
      // {
      //   tabLabel: "state",
      //   value: data?.address[0]?.state
      // },
      {
        tabLabel: `submitted_date`,
        value: moment().format("MM-DD-YYYY") || ""
      }
    ]
  } else {
    return [
      //Section-1 Driver Data
      {
        tabLabel: "driverName",
        value: " "
      },
      {
        tabLabel: "driverLicense",
        value: " "
      },
      {
        tabLabel: "driverGender",
        value: " "
      },
      {
        tabLabel: "driverCity",
        value: " "
      },
      {
        tabLabel: "driverZipcode",
        value: " "
      },
      {
        tabLabel: "driverAddress",
        value: " "
      },
      {
        tabLabel: "driverYearOfBirth",
        value: " "
      },
      {
        tabLabel: "driverMonthOfBirth",
        value: " "
      },
      {
        tabLabel: "driverDayOfBirth",
        value: " "
      },
      // {
      //   tabLabel: "state",
      //   value: data?.address[0]?.state
      // },
      {
        tabLabel: `submitted_date`,
        value: moment().format("MM-DD-YYYY") || ""
      }
    ]
  }
}

