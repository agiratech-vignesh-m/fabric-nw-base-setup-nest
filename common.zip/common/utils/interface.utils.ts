import { Coupon } from "../entities/coupon.entity";
import { HistoryType } from "./db.enum";

export interface IAdminCredentials {
  email: string;
  password: string;
  firstname: string;
  lastname: string;
  role: { id: string };
}

export interface ITwilloCredentials {
  accountSid: string;
  authToken: string;
  verifySId: string;
  templateSid: string;
}

export interface IJwtConfig {
  secret: string;
  expiresIn: string;
  setPasswordExpiryTime: string;
  expiresInMinutes: number;
}

export interface ITokenRole {
  id: string;
  name: string;
}
export interface ITokenGen {
  email: string;
  id: string;
  role?: ITokenRole;
  type?: JwtTypeEnum;
}

// Enum
export enum JwtTypeEnum {
  LOGIN,
  VERIFY_EMAIL,
}

export interface IWallet {
  privateKey?: string;
  publicKey: string;
  walletId?: string;
  active?: boolean;
}

export interface IWeb3 {
  provider: string;
  mnemonic: string;
  privateKey: string;
  publicKey: string;
}

export interface IPaginationParams {
  page: number;
  limit: number;
  search?: string;
}

export interface IPaginationData {
  take: number;
  skip: number;
  search?: string;
  where?: any;
  order?: any;
  query?: any;
  select?: any;
  relations?: any;
}

export interface IPaginationResult {
  totalCount: number;
  totalPages: number;
}

export interface IListQuery {
  pagination: IPaginationResult;
}

export interface IResponse {
  statusCode?: number;
  message?: string;
}

export interface ICouponList extends IListQuery {
  data: Coupon[];
}

export enum UserType {
  EMPLOYEE,
  DRIVER,
  ADMIN,
  AGENT,
}

export interface IComparePassword {
  hash: string;
  password: string;
}

export enum IRoles {
  EMPLOYEE = "employee",
  ADMIN = "admin",
  DRIVER = "driver",
  AGENT = "agent",
}

export interface IContracts {
  registrationContract: string;
  couponContract: string;
  credentialingContract: string;
}

export interface IWeb3CouponCreate {
  id: string;
  ipfsUrl: string;
  start: string;
  end: string;
}

export interface ILagacy {
  username: string;
  password: string;
  grant_type: string;
  legacyServer: string;
}

export interface IWeb3UpdateEndDate {
  id: string;
  end?: string;
  ipfs?: string;
}

export interface ISwagger {
  register: string;
  coupon: string;
  credential: string;
}

export interface ICredentials {
  contract: string;
  authorityId: string;
}

export interface IServiceCredentials {
  port: number;
  host: string;
}

export interface IFireFlyDetails {
  host: string;
}

export enum IBadges {
  ADMIN = "admin",
  DRIVER = "driver",
  AGENT = "agent",
  FLEET_OPERATOR = "fleet_operator",
  VEHICLE_OWNER = "vehicle_owner",
  SERVICE_PROVIDER = "service_provider",
}
export interface IElasticSearch {
  node: string;
  username: string;
  password: string;
  index: string;
  nyk_driver_index: string;
  nyk_vehicle_index: string;
  nyk_fleet_operators_index: string;
  nyk_vehicle_owners_index: string;
  nyk_service_provider_attorney_index: string;
  nyk_vehicle_permit_index: string;
  nyc_app_token: string;
}

export interface INYCNewYorkDb {
  nycAppToken: string;
}

export enum ISocketEvent {
  CREATE = "create_entity",
  APPROVE = "approve_entity",
}

export interface ISteppers {
  name: string;
  status: boolean;
}

export const rolesObject = {
  ...IBadges,
  COMMON: "common",
  APP: "app",
};
export interface IKeyCloak {
  auth_url: string;
  relam: boolean;
  secret: string;
  admin_username: string;
  admin_password: string;
  admin_client_id: string;
}

export interface ICreateHistory {
  userId: string;
  data?: string;
  type: HistoryType;
  action: string;
}
