export enum StatusEnum {
  PENDING = "Pending",
  COMPLETED = "Completed",
  FAILED = "Failed",
}

export enum ProfileStatusEnum {
  PENDING = "Pending",
  APPROVED = "Approved",
  REJECTED = "Rejected",
}

export enum OrderEnum {
  DESC = "desc",
  ASC = "asc",
}

export enum entityEnums {
  userRepository = "userRepository",
  driverRepository = "driverRepository",
  adminRepository = "adminRepository",
}

export enum ICredit {
  YES = "Yes",
  NO = "No",
}

export enum ServiceProviderTypes {
  MEDICAL_PROVIDER = "Medical Provider",
  LEGAL_ATTORNEY = "Legal Attorney Provider",
}

export enum PreferredLanguageEnum {
  GERMAN = "German",
  SPANISH = "Spanish",
  FRENCH = "French",
  ITALIAN = "Italian",
  OTHER = "Other",
}

export enum HistoryType {
  CREDENTIALING = "CREDENTIALING",
  BADGE = "BADGE",
  OTHERS_CREATE = "OTHERS_CREATE",
  OTHERS_UPDATE = "OTHERS_UPDATE"
}
