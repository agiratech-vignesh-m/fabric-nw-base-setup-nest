import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { Badge } from "./badge.entity";
import { ProgressStatus } from "src/utils/db.enum";
import { QrCode } from "./qr.entity";

@Entity()
export class UserBadge {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @ManyToOne(() => User, (user) => user.user_badges)
  user: User;

  @ManyToOne(() => Badge, (badge) => badge.user_badges)
  badge: Badge;

  @Column({ nullable: true })
  credential_id: string;

  @Column({ type: "boolean", default: false })
  entra_verified: boolean;

  @Column({
    type: "enum",
    default: ProgressStatus.PENDING,
    enum: ProgressStatus,
  })
  status: ProgressStatus;

  @OneToOne(() => QrCode, (qrCode) => qrCode.id)
  @JoinColumn()
  credential: QrCode;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
