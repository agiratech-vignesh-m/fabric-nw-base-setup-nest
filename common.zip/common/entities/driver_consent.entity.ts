import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { ConsentOtpTypeEnum } from "src/utils/db.enum";
import { Consent } from "./consent.entity";

@Entity()
export class DriverConsent {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  license_number: string;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true })
  mobile_number: string;

  @Column({ nullable: true })
  otp: string;

  @Column({ nullable: true })
  otp_expiry: string;

  @Column({ type: "enum", enum: ConsentOtpTypeEnum, nullable: true })
  otp_status: ConsentOtpTypeEnum;

  @Column({ nullable: true })
  consent_role: string;

  @ManyToOne(() => Consent, (consent) => consent.driver_consent) // Use the correct property name
  consent: Consent;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;


  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.license_number !== undefined) this.license_number = data.license_number;
      if (data.country_code !== undefined) this.country_code = data.country_code;
      if (data.mobile_number !== undefined) this.mobile_number = data.mobile_number;
      if (data.otp !== undefined) this.otp = data.otp;
      if (data.otp_expiry !== undefined) this.otp_expiry = data.otp_expiry;
      if (data.otp_status !== undefined) this.otp_status = data.otp_status;
      if (data.consent_role !== undefined) this.consent_role = data.consent_role;
      if (data.consent !== undefined) this.consent = data.consent;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      return this;
    }
  }
}
