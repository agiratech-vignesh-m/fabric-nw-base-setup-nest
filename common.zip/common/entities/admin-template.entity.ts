import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { TemplateName } from "./template_name.entity";
import { User } from "./user.entity";
import { UserDocument } from "./user-document.entity";


interface TemplateIdList {
  id: string;
  template_id: string;
}
@Entity()
export class AdminTemplate {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "varchar", nullable: false, length: 255 })
  url: string;

  @Column({ type: "varchar", nullable: false, length: 255 })
  template_name: string;

  @Column({ type: "boolean", default: true })
  sign_only: boolean;

  @Column({ type: "boolean", default: true })
  is_active: boolean;

  @OneToMany(() => UserDocument, (document) => document.template)
  user_document: UserDocument;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, (user) => user.id, { nullable: true })
  @JoinColumn()
  created_by: User;

  //we are not using this filed
  @OneToOne(() => TemplateName, (name) => name.id)
  @JoinColumn()
  template_type: TemplateName;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.url !== undefined) this.url = data.url;
      if (data.template_name !== undefined) this.template_name = data.template_name;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.template_type !== undefined) this.template_type = data.template_type;
      if (data.user_document !== undefined) this.user_document = data.user_document;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.sign_only !== undefined) this.sign_only = data.sign_only;
      return this;
    }
  }
}
