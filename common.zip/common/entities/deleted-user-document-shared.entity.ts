import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { User } from './user.entity';
import { DeletedUserDocument } from './deleted-user-document.entity';

@Entity()
export class DeletedUserDocumentShared {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(type => User, user => user.user_document_shared)
  user: User;

  @ManyToOne(type => DeletedUserDocument, doc => doc.shared_with)
  user_document: DeletedUserDocument;

  @Column({type:'json'})
  created_by: any;

  @CreateDateColumn()
  created_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.user !== undefined) this.user = data.user;
      if (data.user_document !== undefined) this.user_document = data.user_document;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;

      return this;
    }
  }
}