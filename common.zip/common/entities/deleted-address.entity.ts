import { Entity, PrimaryGeneratedColumn } from 'typeorm';
import { Address } from './address.entity';

@Entity()
export class DeletedAddress extends Address {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  public bind(data: any) {
    if (data) {
      if (data.id !==undefined) this.id = data.id;
      return this;
    }
  }
}
