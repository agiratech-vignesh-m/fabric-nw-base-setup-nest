import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, ManyToMany, CreateDateColumn, UpdateDateColumn, OneToMany, OneToOne, JoinColumn, AfterLoad } from 'typeorm';
import { Vehicle } from './vehicle.entity';
import { User } from './user.entity';
import { FleetUsers } from './fleet-user.entity';
import { decryptChiper } from 'src/utils/helper.utils';
import { ProfileDocument } from "./profile_document.entity";


@Entity()
export class Fleet {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true, unique: true })
  company_name: string;

  @Column({ nullable: true, unique: true })
  phone: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column({ nullable: true, unique: true })
  federal_id: string; // UI TAX_ID

  @ManyToMany(() => Vehicle, (vehicle) => vehicle.fleet, { nullable: true })
  vehicles: Vehicle[];

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  address_line2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @Column({ type: "boolean", default: true })
  is_active: boolean;

  @Column({ type: "boolean", default: false })
  is_delete: boolean;

  /* TODO */
  @ManyToOne(() => User, (broker) => broker.id)
  created_by: User;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ nullable: true })
  contact_person: string;

  @Column({ nullable: true })
  tax_id: string;

  @Column({ nullable: true })
  office_number: string;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true })
  tele_country_code: string;

  @OneToMany(() => FleetUsers, (fleetUser) => fleetUser.fleet)
  fleet_users: FleetUsers[];

  @OneToOne(() => User, (user) => user.fleet, { nullable: true, cascade: true })
  @JoinColumn()
  user: User;

  @Column({ nullable: true })
  bic: string;

  @Column({ nullable: true })
  country: string;

  @Column({ type: "boolean", default: false })
  kyb_verified: boolean;

  @Column({ type: "boolean", default: false })
  is_individual: boolean;

  @OneToMany(() => ProfileDocument, (object) => object.fleet_operator)
  fleet_operator_docs: ProfileDocument[];

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.company_name !== undefined)
        this.company_name = data.company_name;
      if (data.phone !== undefined) this.phone = data.phone;
      if (data.email !== undefined) this.email = data.email;
      if (data.federal_id !== undefined) this.federal_id = data.federal_id;
      if (data.address !== undefined) this.address = data.address;
      if (data.address_line2 !== undefined)
        this.address_line2 = data.address_line2;
      if (data.city !== undefined) this.city = data.city;
      if (data.state !== undefined) this.state = data.state;
      if (data.zip_code !== undefined) this.zip_code = data.zip_code;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.is_delete !== undefined) this.is_delete = data.is_delete;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.contact_person !== undefined)
        this.contact_person = data.contact_person;
      if (data.tax_id !== undefined) this.tax_id = data.tax_id;
      if (data.office_number !== undefined)
        this.office_number = data.office_number;
      if (data.country_code !== undefined)
        this.country_code = data.country_code;
      if (data.tele_country_code !== undefined)
        this.tele_country_code = data.tele_country_code;
      if (data.fleet_users !== undefined) this.fleet_users = data.fleet_users;
      if (data.user !== undefined) this.user = data.user;
      if (data.bic !== undefined) this.bic = data.bic;
      if (data.country !== undefined) this.country = data.country;
      if (data.kyb_verified !== undefined)
        this.kyb_verified = data.kyb_verified;
      if (data.is_individual !== undefined)
        this.is_individual = data.is_individual;
      if (data.fleet_operator_docs !== undefined)
        this.fleet_operator_docs = data.fleet_operator_docs;

      return this;
    }
  }
}
