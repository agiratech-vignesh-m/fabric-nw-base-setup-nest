// user-log.entity.ts
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  OneToMany,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { HistoryType } from "../utils/db.enum";

@Entity()
export class History {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  timestamp: Date;

  @OneToMany(() => User, (user) => user.id, { nullable: true })
  @JoinColumn()
  user: User;

  @Column()
  action: string;

  @Column({ enum: HistoryType, type: "enum", nullable: true })
  type: HistoryType;

  @Column({ nullable: true })
  data: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
