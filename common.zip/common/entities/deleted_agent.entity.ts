import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
} from "typeorm";
import { Organisation } from "./organisation.entity";
import { DeletedUser } from "./deleted-user.entity";

@Entity()
export class DeletedBroker {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  firstname: string;

  @Column({ nullable: true })
  lastname: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  password: string;

  @Column({ nullable: false, default: false, type: "boolean" })
  email_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  mobile_verified: boolean;

  @Column({ nullable: true, default: false })
  is_password_confirmed: boolean;

  @Column({ nullable: true })
  primary_language: string;

  @Column({ nullable: true })
  company_name: string;

  @Column({ nullable: true })
  telephone: string;

  @Column({ nullable: true })
  contact_person: string;

  @Column({ nullable: true})
  mobile_number: string;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true })
  tele_country_code: string;

  @Column({ nullable: true })
  federal_id: string; //tax_id

  @Column({ nullable: true })
  driver_license_number: string;

  @Column({ nullable: true })
  dfs_insurence_license: string;

  @ManyToOne(() => Organisation, (org) => org.id)
  organisation_id: Organisation;

  @Column({ default: true, type: "boolean" })
  is_active: boolean;

  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @Column({ nullable: true })
  otp: string;

  @Column({ nullable: true, type: "timestamp" })
  otp_expiry_time: Date;

  @OneToMany(() => DeletedUser, (user) => user.agent, { nullable: true })
  user: DeletedUser;

  // @ManyToOne(() => User, (user) => user.id)
  // created_by: User;

  @Column({type:'json'})
  created_by: any;

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ type: "longtext", nullable: true })
  verification_token: string;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.email !== undefined) this.email = data.email;
      if (data.firstname !== undefined) this.firstname = data.firstname;
      if (data.lastname !== undefined) this.lastname = data.lastname;
      if (data.password !== undefined) this.password = data.password;
      if (data.email_verified !== undefined)
        this.email_verified = data.email_verified;
      if (data.mobile_verified !== undefined)
        this.mobile_verified = data.mobile_verified;
      if (data.is_password_confirmed !== undefined)
        this.is_password_confirmed = data.is_password_confirmed;
      if (data.primary_language !== undefined)
        this.primary_language = data.primary_language;
      if (data.company_name !== undefined)
        this.company_name = data.company_name;
      if (data.telephone !== undefined) this.telephone = data.telephone;
      if (data.contact_person !== undefined)
        this.contact_person = data.contact_person;
      if (data.mobile_number !== undefined)
        this.mobile_number = data.mobile_number;
      if (data.country_code !== undefined)
        this.country_code = data.country_code;
      if (data.tele_country_code !== undefined)
        this.tele_country_code = data.tele_country_code;
      if (data.federal_id !== undefined) this.federal_id = data.federal_id;
      if (data.driver_license_number !== undefined)
        this.driver_license_number = data.driver_license_number;
      if (data.dfs_insurence_license !== undefined)
        this.dfs_insurence_license = data.dfs_insurence_license;
      if (data.address_line_1 !== undefined)
        this.address_line_1 = data.address_line_1;
      if (data.address_line_2 !== undefined)
        this.address_line_2 = data.address_line_2;
      if (data.city !== undefined) this.city = data.city;
      if (data.state !== undefined) this.state = data.state;
      if (data.zip_code !== undefined) this.zip_code = data.zip_code;
      if (data.organisation_id !== undefined)
        this.organisation_id = data.organisation_id;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.user !== undefined) this.user = data.user;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.verification_token !== undefined)
        this.verification_token = data.verification_token;
      return this;
    }
  }
}
