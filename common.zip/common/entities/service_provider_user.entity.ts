import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { ProgressStatus } from "src/utils/db.enum";
import { VehicleOwner } from "./vehicle-owner.entity";
import { ServiceProvider } from "./service_provider.entity";

@Entity()
export class ServiceProviderUsers {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @OneToOne(() => User, (user) => user.service_provider_user)
  @JoinColumn()
  user: User;

  @ManyToOne(
    () => ServiceProvider,
    (serviceProvider) => serviceProvider.service_provider_users
  )
  service_provider: ServiceProvider;

  @Column({
    type: "enum",
    enum: ProgressStatus,
    default: ProgressStatus.PENDING,
  })
  status: ProgressStatus;

  @ManyToOne(() => User, (user) => user.id)
  approved_by: User;

  @Column({ type: "boolean", default: false })
  is_admin: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.status !== undefined) this.status = data.status;
      if (data.user !== undefined) this.user = new User().bind({ id: data.id });
      if (data.vehicle_owner !== undefined)
        this.service_provider = new ServiceProvider().bind({
          id: data.service_provider,
        });
      if (data.approved_by !== undefined)
        this.approved_by = new User().bind({ id: data.approved_by });
    }
  }
}
