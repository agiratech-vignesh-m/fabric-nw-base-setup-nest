import { ICredit } from "../utils/db.enum";
import { Address } from "./address.entity";
import { AdminTemplate } from "./admin-template.entity";
import { Organisation } from "./organisation.entity";
import { User } from "./user.entity";
import { UsersCoupons } from "./usersCoupons.entity";
import { Vehicle } from "./vehicle.entity";
import { Wallet } from "./wallet.entity";
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
} from "typeorm";

@Entity()
export class DirectTlcData {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  hack_license_number: string;

  @Column({ nullable: true })
  hack_license_expiration_date: string;

  @Column({ nullable: true })
  dmv_license_number: string;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.hack_license_number !== undefined) this.hack_license_number = data.hack_license_number;
      if (data.hack_license_expiration_date !== undefined) this.hack_license_expiration_date = data.hack_license_expiration_date;
      if (data.dmv_license_number !== undefined) this.dmv_license_number = data.dmv_license_number;
      return this;
    }
  }
}
