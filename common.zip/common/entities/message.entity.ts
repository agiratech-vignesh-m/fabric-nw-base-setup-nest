import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, CreateDateColumn, UpdateDateColumn, OneToMany, ManyToMany, JoinTable } from 'typeorm';
import { User } from './user.entity';
import { Conversation } from './conversation.entity';


@Entity()
export class Message {

  @PrimaryGeneratedColumn("uuid")
  id: string;

  @ManyToOne(() => Conversation, (conversation) => conversation.id)
  conversation: Conversation;

  @Column({ nullable: false })
  message: string;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToMany(() => User, (user) => user.id)
  @JoinTable()
  read: User[];

  @Column({ type: "boolean", default: false })
  message_read: boolean;

  @Column({ type: 'boolean', default: false })
  is_deleted: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.conversation !== undefined) this.conversation = data.conversation;
      if (data.message !== undefined) this.message = data.message;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.read !== undefined) this.read = data.read;
      if (data.is_deleted !== undefined) this.is_deleted = data.is_deleted;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.message_read !== undefined) this.message_read = data.message_read;

      return this;
    }
  }
}