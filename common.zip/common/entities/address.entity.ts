import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, CreateDateColumn, UpdateDateColumn} from 'typeorm';
import { User } from './user.entity';


export enum AddressType {
  mailing_address = "mailing_address",
  residence_address = "residence_address",
  same_address = "same_address",
  broker_address = "broker_address"
}


@Entity()
export class Address {

  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: false })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @CreateDateColumn({ select: false })
  created_at: Date;
  
  @UpdateDateColumn()
  updated_at: Date;

  //broker id (broker creates member/driver)
  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @Column({ type: "enum", enum: AddressType })
  address_type: AddressType;

  public bind(data: any) {
    if (data) {
      if (data.id !==undefined) this.id = data.id;
      if (data.address_line_1 !==undefined) this.address_line_1 = data.address_line_1;  
      if (data.address_line_2 !==undefined) this.address_line_2 = data.address_line_2;
      if (data.city !==undefined) this.city = data.city;
      if (data.state !==undefined) this.state = data.state;
      if (data.zip_code !==undefined) this.zip_code = data.zip_code;
      if (data.created_at !==undefined) this.created_at = data.created_at;
      if (data.updated_at !==undefined) this.updated_at = data.updated_at;
      if (data.created_by !==undefined) this.created_by = data.created_by;
      if (data.address_type !==undefined) this.address_type = data.address_type;

      return this;
    }
  }
}