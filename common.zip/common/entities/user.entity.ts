import { Admin } from "./admin.entity";
import { Broker } from "./agent.entity";
import { Conversation } from "./conversation.entity";
import { Driver } from "./driver.entity";
import { Employee } from "./employee.entity";
import { Role } from "./role.entity";
import { SocketSession } from "./socket-session.entity";
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  JoinTable,
  ManyToMany,
  AfterLoad,
  VersionColumn,
} from "typeorm";
import { UserDocumentShared } from "./user-document-shared.entity";
import { Profile } from "./profile.entity";
import { UserBadge } from "./user_badge.entity";
import { AgentUsers } from "./agent_user.entity";
import { FleetUsers } from "./fleet-user.entity";
import { Fleet } from "./fleet.entity";
import { VehicleOwner } from "./vehicle-owner.entity";
import { VehicleOwnerUsers } from "./vehicle_owner_users.entity";
import { ServiceProviderUsers } from "./service_provider_user.entity";
import { decryptChiper } from "src/utils/helper.utils";
import { ProfileDocument } from "./profile_document.entity";
@Entity()
export class User {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true })
  mobile_number: string;

  @Column({ nullable: true })
  password: string;

  @Column({ nullable: true })
  password_reset_hash: string;

  @ManyToOne(() => Role, (role) => role.users)
  role: Role;

  @OneToMany(() => SocketSession, (socket) => socket.user)
  socket_session: SocketSession[];

  @OneToMany(() => UserBadge, (userBadge) => userBadge.user)
  user_badges: UserBadge[];

  @OneToOne(() => Driver, (driver) => driver.user, { nullable: true })
  driver: Driver;

  @OneToOne(() => Employee, (employee) => employee.user, { nullable: true })
  employee: Employee;

  @OneToOne(() => Admin, (admin) => admin.user, { nullable: true })
  admin: Admin;

  @OneToOne(() => Broker, (admin) => admin.user, { nullable: true })
  agent: Broker;

  @OneToOne(() => AgentUsers, (agent) => agent.user, { nullable: true })
  agent_user: AgentUsers;

  @OneToOne(() => VehicleOwner, (vehicleOwner) => vehicleOwner.user, {
    nullable: true,
  })
  vehicle_owner: VehicleOwner;

  @OneToOne(() => VehicleOwnerUsers, (vehicleOwner) => vehicleOwner.user, {
    nullable: true,
  })
  user_vehicle_owner: VehicleOwnerUsers;

  @OneToOne(
    () => ServiceProviderUsers,
    (serviceProviderUsers) => serviceProviderUsers.user,
    {
      nullable: true,
    }
  )
  service_provider_user: ServiceProviderUsers;

  @OneToOne(() => Profile, (profile) => profile.user, { nullable: true })
  profile: Profile;

  @ManyToMany(() => Conversation, (conversation) => conversation.members)
  @JoinTable()
  conversations: Conversation[];

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @OneToMany((type) => UserDocumentShared, (data) => data.user)
  user_document_shared: UserDocumentShared[];

  @Column({ nullable: false, default: false })
  is_google: boolean;

  @Column({ nullable: false, default: false })
  is_facebook: boolean;

  @Column({ nullable: true })
  google_id: string;

  @Column({ nullable: true })
  facebook_id: string;

  @OneToOne(() => Fleet, (fleet) => fleet.created_by, { nullable: true })
  fleet: Fleet;

  @OneToOne(() => FleetUsers, (fleet) => fleet.user, { nullable: true })
  fleet_user: FleetUsers;

  @Column({ nullable: false, default: false })
  is_mobile_registered: boolean;

  @Column({ nullable: false, default: false })
  is_driver_credentialed: boolean;

  @Column({ nullable: true })
  sso_user_id: string;

  @ManyToMany(() => Driver, (driver) => driver.agents)
  @JoinTable()
  mapped_drivers: Driver[];

  @AfterLoad()
  async decryptData() {
    this.email = this.email ? await decryptChiper(this.email) : null;
    this.mobile_number = this.mobile_number
      ? await decryptChiper(this.mobile_number)
      : null;
  }

  @OneToMany(() => ProfileDocument, (object) => object.user)
  profile_docs: ProfileDocument[];

  @Column({ nullable: false, default: false })
  is_admin: boolean;

  @VersionColumn({ type: "number" })
  version: number;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.email !== undefined) this.email = data.email;
      if (data.mobile_number !== undefined)
        this.mobile_number = data.mobile_number;
      if (data.password !== undefined) this.password = data.password;
      if (data.role !== undefined) this.role = data.role;
      if (data.socket_session !== undefined)
        this.socket_session = data.socket_session;
      if (data.driver !== undefined) this.driver = data.driver;
      if (data.employee !== undefined) this.employee = data.employee;
      if (data.admin !== undefined) this.admin = data.admin;
      if (data.agent !== undefined) this.agent = data.agent;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.user_document_shared !== undefined)
        this.user_document_shared = data.user_document_shared;
      if (data.conversations !== undefined)
        this.conversations = data.conversations;
      if (data.is_google !== undefined) this.is_google = data.is_google;
      if (data.is_facebook !== undefined) this.is_facebook = data.is_facebook;
      if (data.google_id !== undefined) this.google_id = data.google_id;
      if (data.facebook_id !== undefined) this.facebook_id = data.facebook_id;
      if (data.password_reset_hash !== undefined)
        this.password_reset_hash = data.password_reset_hash;
      if (data.fleet_user !== undefined) this.fleet_user = data.fleet_user;
      if (data.fleet !== undefined) this.fleet = data.fleet;
      if (data.is_mobile_registered !== undefined)
        this.is_mobile_registered = data.is_mobile_registered;
      if (data.is_driver_credentialed !== undefined)
        this.is_driver_credentialed = data.is_driver_credentialed;
      if (data.sso_user_id !== undefined) this.sso_user_id = data.sso_user_id;
      if (data.mapped_drivers !== undefined)
        this.mapped_drivers = data.mapped_drivers;
      if (data.is_admin !== undefined) this.is_admin = data.is_admin;
      if (data.profile_docs !== undefined)
        this.profile_docs = data.profile_docs;
      if (data.version !== undefined) this.version = data.version;
      return this;
    }
  }
}
