import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    ManyToOne,
    OneToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
  } from "typeorm";
  import { User } from "./user.entity";
import { DocumentTypeEnum, FileTypeEnum, ImagePositionEnum, ProgressStatus, VerificationTypeEnum } from "src/utils/db.enum";
import { Profile } from "./profile.entity";
import { Broker } from "./agent.entity";
import { VehicleOwner } from "./vehicle-owner.entity";
import { ServiceProvider } from "./service_provider.entity";
import { Fleet } from "./fleet.entity";
  
  @Entity()
  export class ProfileDocument {
    @PrimaryGeneratedColumn("uuid")
    id: string;

    @ManyToOne(() => User, obj => obj.profile_docs)
    user: User;

    @ManyToOne(() => Broker, obj => obj.agent_docs)
    agent: Broker;

    @ManyToOne(() => VehicleOwner, obj => obj.vehicle_owner_docs)
    vehicle_owner: VehicleOwner;

    @ManyToOne(() => ServiceProvider, obj => obj.service_provider_docs)
    service_provider: ServiceProvider;

    @ManyToOne(() => Fleet, obj => obj.fleet_operator_docs)
    fleet_operator: Fleet;

    @Column({
      type: "enum",
      enum: VerificationTypeEnum,
    })
    verification_type: VerificationTypeEnum;
  
    @Column({
      type: "enum",
      enum: DocumentTypeEnum,
    })
    document_type: DocumentTypeEnum;

    @Column({
      type: "enum",
      enum: ImagePositionEnum
    })
    position: ImagePositionEnum;
  
    @Column({
      type: "enum",
      enum: ProgressStatus,
      default: ProgressStatus.PENDING,
    })
    status: ProgressStatus;

    @Column({ nullable: false })
    path: string;

    @Column({
      type: "enum",
      enum: FileTypeEnum
    })
    file_type: FileTypeEnum;

  
    @CreateDateColumn()
    created_at: Date;
  
    @UpdateDateColumn()
    updated_at: Date;

    @ManyToOne(() => User, { nullable: true })
    @JoinColumn()
    created_by: User;

    @ManyToOne(() => User, { nullable: true })
    @JoinColumn()
    updated_by: User;
  
    public bind(data: any) {
      if (data) {
        if (data.id !== undefined) this.id = data.id;
        if (data.status !== undefined) this.status = data.status;
        if (data.user !== undefined) this.user = data.user;
        if (data.document_type !== undefined) this.document_type = data.document_type;
        if (data.position !== undefined) this.position = data.position;
        if (data.path !== undefined) this.path = data.path;
        if (data.file_type !== undefined) this.file_type = data.file_type;
        if (data.created_by !== undefined) this.created_by = data.created_by;
        if (data.updated_by !== undefined) this.updated_by = data.updated_by;
        if (data.agent !== undefined) this.agent = data.agent;
        if (data.vehicle_owner !== undefined) this.vehicle_owner = data.vehicle_owner;
        if (data.service_provider !== undefined) this.service_provider = data.service_provider;
        if (data.fleet_operator !== undefined) this.fleet_operator = data.fleet_operator;
        return data
      }
    }
  }
  