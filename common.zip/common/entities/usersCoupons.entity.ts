import { Coupon } from "./coupon.entity";
import { User } from "./user.entity";
import { StatusEnum } from "../utils/db.enum";
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { Driver } from "./driver.entity";

@Entity()
export class UsersCoupons {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "boolean", default: true })
  is_active: boolean;

  @ManyToOne(() => Driver, (driver) => driver.usersCoupons)
  driver: Driver;

  @ManyToOne(() => Coupon, (coupon) => coupon.usersCoupons)
  coupon: Coupon;

  @Column({ type: "enum", enum: StatusEnum, default: StatusEnum.PENDING })
  status: StatusEnum;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}