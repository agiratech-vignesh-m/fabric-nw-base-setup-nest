import { Organisation } from "./organisation.entity";
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToOne,
  JoinColumn,
  OneToMany,
} from "typeorm";
import { User } from "./user.entity";

@Entity()
export class Admin {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  firstname: string;

  @Column({ nullable: true })
  lastname: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column({ nullable: true })
  password: string;

  @Column({ default: true, type: "boolean" })
  is_active: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  mobile_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  email_verified: boolean;

  @Column({ nullable: true })
  otp: string;

  @Column({ nullable: true, type: "timestamp" })
  otp_expiry_time: Date;

  @Column({ nullable: true, default: false })
  is_password_confirmed: boolean;

  @ManyToOne(() => Organisation, (organisation) => organisation.admin)
  @JoinColumn()
  tenant: Organisation;

  @Column({ type: "longtext", nullable: true })
  verification_token: string;

  @OneToOne(() => User, (user) => user.admin, { nullable: true })
  @JoinColumn()
  user: User;

  @CreateDateColumn({ select: false })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn()
  created_by: User;

  public bind(data: any) {
    if (data) {
      if (data.id !==undefined) this.id = data.id;
      if (data.firstname !==undefined) this.firstname = data.firstname;
      if (data.lastname !==undefined) this.lastname = data.lastname;
      if (data.email !==undefined) this.email = data.email;
      if (data.password !==undefined) this.password = data.password;
      if (data.mobile_verified !==undefined) this.mobile_verified = data.mobile_verified;
      if (data.email_verified !==undefined) this.email_verified = data.email_verified;
      if (data.otp !==undefined) this.otp = data.otp;
      if (data.otp_expiry_time !==undefined) this.otp_expiry_time = data.otp_expiry_time;
      if (data.is_password_confirmed !==undefined) this.is_password_confirmed = data.is_password_confirmed;
      if (data.tenant !==undefined) this.tenant = data.tenant;
      if (data.verification_token !==undefined) this.verification_token = data.verification_token;
      if (data.user !==undefined) this.user = data.user;
      if (data.created_at !==undefined) this.created_at = data.created_at;
      if (data.updated_at !==undefined) this.updated_at = data.updated_at;
      if (data.created_by !==undefined) this.created_by = data.created_by;

      return this;
    }
  }
}
