import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { DeletedTemplateName } from './deleted_template_name.entity';
import { DeletedUserDocument } from './deleted-user-document.entity';


interface TemplateIdList {
  id: string;
  template_id: string;
}

@Entity()
export class DeletedAdminTemplate {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "varchar", nullable: true, length: 255 })
  url: string;

  @Column({ type: "varchar", nullable: true, length: 255 })
  template_name: string;

  @Column({ nullable: true })
  file_type: string;

  @Column({nullable: true})
  number_of_files: string;

  @Column('json', { nullable: true })
  template_id_list: TemplateIdList;

  @Column({ type: "boolean", default: true })
  is_active: boolean;
    
  @OneToMany(() => DeletedUserDocument, (document) => document.template)
  user_document: DeletedUserDocument;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({type:'json'})
  // @ManyToOne(() => User, (user) => user.id,{ nullable: true })
  created_by: any;

  //we are not using this field
  @ManyToOne(() => DeletedTemplateName, (name) => name.id)
  @JoinColumn()
  template_type: DeletedTemplateName;

  public bind(data: any) {
    if (data) {
      if (data.id !==undefined) this.id = data.id;
      if (data.url !==undefined) this.url = data.url;
      if (data.is_active !==undefined) this.is_active = data.is_active;
      if (data.file_type !==undefined) this.file_type = data.file_type;
      if (data.number_of_files !==undefined) this.number_of_files = data.number_of_files;
      if (data.template_id_list !==undefined) this.template_id_list = data.template_id_list;
      if (data.template_type !==undefined) this.template_type = data.template_type;
      if (data.user_document !==undefined) this.user_document = data.user_document;
      if (data.created_at !==undefined) this.created_at = data.created_at;
      if (data.updated_at !==undefined) this.updated_at = data.updated_at;
      if (data.created_by !==undefined) this.created_by = data.created_by;

      return this;
    }
  }
}
