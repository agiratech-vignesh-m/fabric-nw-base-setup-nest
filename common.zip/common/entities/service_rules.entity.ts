import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { ISteppers } from "../utils/interface.utils";

@Entity()
export class ServiceRules {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  role: string;

  @Column({ type: "json" })
  steps: ISteppers[];
  
  @Column({ type: "json" })
  role_access: any;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
