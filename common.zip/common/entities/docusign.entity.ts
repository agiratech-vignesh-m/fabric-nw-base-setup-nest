import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { User } from './user.entity';

export enum LocationType {
  city = "city",
  village = "village",
  town = "town"
}

export enum Direction {
  north = "north",
  south = "south",
  east = "east",
  west = "west"
}

export enum VehicleInvolvemetType {
  VEHICLE = "VEHICLE_2",
  PEDESTRIAN = "PEDESTRIAN",
  BICYCLIST = "BICYCLIST",
  OTHER_PEDESTRIAN = "OTHER_PEDESTRIAN"
}


interface Driver {
  license_number: string;
  license_state: string;
  driver_name: string;
  driver_address: string;
  driver_apt: string;
  driver_city: string;
  driver_state: string;
  driver_zipcode: string;
  driver_dob: Date;
  driver_dob_month: string;
  driver_dob_day: string;
  driver_dob_year: string;
  driver_gender: string;
  number_of_people_in_vehicle: string;
  public_property_damaged: boolean;
}

interface VehicleInvolved {
  vehicle_involved_type: VehicleInvolvemetType;
  vehicle_involved_license_number: string;
  vehicle_involved_license_state: string;
  vehicle_involved_driver_name: string;
  vehicle_involved_driver_apt: string;
  vehicle_involved_driver_address: string;
  vehicle_involved_driver_city: string;
  vehicle_involved_driver_state: string;
  vehicle_involved_driver_zipcode: string;
  vehicle_involved_driver_dob_month: string;
  vehicle_involved_driver_dob_day: string;
  vehicle_involved_driver_dob_year: string;
  vehicle_involved_driver_dob: Date;
  vehicle_involved_driver_gender: string;
  vehicle_involved_number_of_people_in_vehicle: string;
  vehicle_involved_public_property_damaged: boolean;
}

interface VehicleInvolvedList {
  vehicle_involved:VehicleInvolved;
  vehicle_registrant:VehicleRegistrant;
  vehicle_damage:VehicleDamage;
  vehicle2_second_event: string;
  vehicle2_travel_direction:string;
  vehicle2_action: string;
  accident_location:string;
  accident_action:string;
  id:number;
}

interface Registrant {
  registrant_name: string;
  registrant_dob: Date;
  registrant_dob_date: string;
  registrant_dob_month: string;
  registrant_dob_year: string;
  registrant_gender: string;
  registrant_address: string;
  registrant_apt_number: string;
  registrant_city: string;
  registrant_state: string;
  registrant_zip_code: string;
  registrant_plate_number: string;
  registrant_state_of_reg: string;
  registrant_vehicle_year_make: string;
  registrant_vehicle_type: string;
  registrant_ins_code: string;
}

interface VehicleRegistrant {
  vehicle2_name: string;
  vehicle2_dob: Date;
  vehicle2_dob_date: string;
  vehicle2_dob_month: string;
  vehicle2_dob_year: string;
  vehicle2_gender: string;
  vehicle2_address: string;
  vehicle2_apt_number: string;
  vehicle2_state: string;
  vehicle2_city: string;
  vehicle2_zip_code: string;
  vehicle2_plate_number: string;
  vehicle2_state_of_reg: string;
  vehicle2_vehicle_year_make: string;
  vehicle2_vehicle_type: string;
  vehicle2_ins_code: string;
}

interface VehicleDamage {
  vehicle_estimation: string;
  vehicle2_estimation: string;
  vehicle_damage_description: string;
  vehicle2_damage_description: string;
  accident_diagram: string;
  accident_image: string;
}

interface AccidentLocation {
  county: string;
  location_type: LocationType;
  location_text: string;
  landmark: string;
  road: string;
  intersecting_street: string;
  feet: string;
  or_address: boolean;
  miles: string;
  direction: string;
  nearest_route: string;
  how_happend: string;
  accident_location_check: boolean;
}

interface AllInvolved {
  name_of_person: string;
  vehicle_occupied: string;
  position_vehicle: string;
  safety_equip_used: string;
  person_age: string;
  person_gender: string;
  injury_level: string[];       //to_do
  description: string;
  date_of_death: Date;
}
interface Insurance {
  damaged_property: string;
  vin: string;
  insurance_company: string;
  policy_number: string;
  address_of_policy_holder: string;
  policy_valid_from: Date;
  policy_expiry: Date;
  vehicle_permit_number: string;
  address_of_permit_holder: string;
  certificate_no: string;
  insurance_state: string;
  submitted_date: Date;
  vehicle1_driver: string;
}




@Entity()
export class DocuSign {

  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ default: false, type: "boolean" })
  rush_drive: boolean;

  @Column({ nullable: true, type: "timestamp" })
  accident_date: Date;

  @Column({ nullable: true })
  accident_month: string;

  @Column({ nullable: true })
  accident_day: string;

  @Column({ nullable: true })
  accident_year: string;

  @Column({ nullable: true })
  day_of_week: string;

  @Column({ nullable: true })
  accident_time: string;

  @Column({ nullable: true })
  number_of_vehicles: string;

  @Column({ nullable: true })
  number_of_injured: string;

  @Column({ nullable: true })
  number_of_killed: string;

  @Column({ default: false, type: "boolean" })
  police_investigated: boolean;
  //#todo
  @Column({ nullable: true })
  police_agency: string;


  //Driver
  @Column('json', { nullable: true })
  driver: Driver;


  //Vehicle Involved
  @Column('json', { nullable: true })
  vehicle_involved: VehicleInvolved[];


  //Vehicle Involved List
  @Column('json', { nullable: true })
  vehicle_involved_list: VehicleInvolvedList[];


  //Registrant
  @Column('json', { nullable: true })
  registrant: Registrant;


  //vehicle2 Registrant
  @Column('json', { nullable: true })
  vehicle_registrant: VehicleRegistrant;


  //Vehicle Damage
  @Column('json', { nullable: true })
  vehicle_damage: VehicleDamage;

  //Accident Location
  @Column('json', { nullable: true })
  accidents_location: AccidentLocation;

  //All Involved
  @Column('json', { nullable: true })
  all_involved: AllInvolved[];

  //Insurance
  @Column('json', { nullable: true })
  insurance: Insurance;

  @Column({ type: "boolean", default: false })
  injury: boolean;

  @Column({ type: "boolean", default: false })
  death: boolean;

  //Section B
  @Column({ nullable: true })
  accident_location: string;

  @Column({ nullable: true })
  accident_action: string;

  @Column({ nullable: true })
  traffic_control: string;

  @Column({ nullable: true })
  light_conditions: string;

  @Column({ nullable: true })
  roadway_character: string;

  @Column({ nullable: true })
  roadway_surface_condtion: string;

  @Column({ nullable: true })
  weather: string;

  @Column({ nullable: true })
  vehicle1_travel_direction: string;

  @Column({ nullable: true })
  vehicle2_travel_direction: string;

  @Column({ nullable: true })
  vehicle1_action: string;

  @Column({ nullable: true })
  vehicle2_action: string;

  @Column({ nullable: true })
  location_of_first_event: string;

  @Column({ nullable: true })
  accident_type: string;

  @Column({ nullable: true })
  vehicle1_second_event: string;

  @Column({ nullable: true })
  vehicle2_second_event: string;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToOne(() => User, (user) => user.id)
  broker: User;

  @ManyToOne(() => User, (user) => user.id)
  admin: User;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ default: false, type: "boolean" })
  is_driver_signed: boolean;

  @Column({ default: false, type: "boolean" })
  is_broker_signed: boolean;

  @Column({ default: false, type: "boolean" })
  is_admin_signed: boolean;

  @Column({ nullable: true })
  pdf: string;



  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.rush_drive !== undefined) this.rush_drive = data.rush_drive;
      if (data.accident_date !== undefined) this.accident_date = data.accident_date;
      if (data.accident_month !== undefined) this.accident_month = data.accident_month;
      if (data.accident_day !== undefined) this.accident_day = data.accident_day;
      if (data.accident_year !== undefined) this.accident_year = data.accident_year;
      if (data.day_of_week !== undefined) this.day_of_week = data.day_of_week;
      if (data.accident_time !== undefined) this.accident_time = data.accident_time;
      if (data.number_of_vehicles !== undefined) this.number_of_vehicles = data.number_of_vehicles;
      if (data.number_of_injured !== undefined) this.number_of_injured = data.number_of_injured;
      if (data.number_of_killed !== undefined) this.number_of_killed = data.number_of_killed;
      if (data.police_investigated !== undefined) this.police_investigated = data.police_investigated;
      if (data.police_agency !== undefined) this.police_agency = data.police_agency;

      if (data.driver !== undefined) this.driver = data.driver;
      if (data.vehicle_involved !== undefined) this.vehicle_involved = data.vehicle_involved;
      if (data.registrant !== undefined) this.registrant = data.registrant;
      if (data.vehicle_registrant !== undefined) this.vehicle_registrant = data.vehicle_registrant;
      if (data.vehicle_damage !== undefined) this.vehicle_damage = data.vehicle_damage;
      if (data.accidents_location !== undefined) this.accidents_location = data.accidents_location;
      if (data.all_involved !== undefined) this.all_involved = data.all_involved;
      if (data.vehicle_involved_list !== undefined) this.vehicle_involved_list = data.vehicle_involved_list;
      if (data.insurance !== undefined) this.insurance = data.insurance;

      if (data.accident_location !== undefined) this.accident_location = data.accident_location;
      if (data.accident_action !== undefined) this.accident_action = data.accident_action;
      if (data.traffic_control !== undefined) this.traffic_control = data.traffic_control;
      if (data.light_conditions !== undefined) this.light_conditions = data.light_conditions;
      if (data.roadway_character !== undefined) this.roadway_character = data.roadway_character;
      if (data.roadway_surface_condtion !== undefined) this.roadway_surface_condtion = data.roadway_surface_condtion;
      if (data.weather !== undefined) this.weather = data.weather;
      if (data.vehicle1_travel_direction !== undefined) this.vehicle1_travel_direction = data.vehicle1_travel_direction;
      if (data.vehicle2_travel_direction !== undefined) this.vehicle2_travel_direction = data.vehicle2_travel_direction;
      if (data.vehicle1_action !== undefined) this.vehicle1_action = data.vehicle1_action;
      if (data.vehicle2_action !== undefined) this.vehicle2_action = data.vehicle2_action;
      if (data.location_of_first_event !== undefined) this.location_of_first_event = data.location_of_first_event;
      if (data.accident_type !== undefined) this.accident_type = data.accident_type;
      if (data.vehicle1_second_event !== undefined) this.vehicle1_second_event = data.vehicle1_second_event;
      if (data.vehicle2_second_event !== undefined) this.vehicle2_second_event = data.vehicle2_second_event;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.is_driver_signed !== undefined) this.is_driver_signed = data.is_driver_signed;
      if (data.is_broker_signed !== undefined) this.is_broker_signed = data.is_broker_signed;
      if (data.is_admin_signed !== undefined) this.is_admin_signed = data.is_admin_signed;
      if (data.broker !== undefined) this.broker = data.broker;
      if (data.admin !== undefined) this.admin = data.admin;
      if (data.injury !== undefined) this.injury = data.injury;
      if (data.death !== undefined) this.death = data.death;


      return this;
    }
  }
}