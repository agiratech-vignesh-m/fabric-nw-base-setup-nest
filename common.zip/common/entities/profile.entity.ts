import { decryptChiper } from "src/utils/helper.utils";
import { ICredit, PreferredLanguageEnum, ProfileStatusEnum, StatusEnum } from "../utils/db.enum";
import { Address } from "./address.entity";
import { Organisation } from "./organisation.entity";
import { ProfileDocument } from "./profile_document.entity";
import { User } from "./user.entity";
import { Wallet } from "./wallet.entity";
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
  AfterLoad,
} from "typeorm";

@Entity()
export class Profile {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  firstname: string;

  @Column({ nullable: true })
  lastname: string;

  @Column({ nullable: true, default: "en" })
  language: string;

  @Column({ nullable: true })
  password: string;

  @Column({ default: true, type: "boolean" })
  is_active: boolean;

  @Column({ type: "date", nullable: true })
  dob: Date;

  @Column({ nullable: true })
  gender: string;

  @Column({ nullable: true })
  otp: string;

  @Column({ nullable: false, default: false, type: "boolean" })
  mobile_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  email_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  entra_verified: boolean;

  @Column({ nullable: true, type: "timestamp" })
  otp_expiry_time: Date;

  @Column({ nullable: true })
  ddc: string;

  @Column({ nullable: true, default: false })
  is_password_confirmed: boolean;

  @OneToOne(() => Wallet, (wallet) => wallet.driver)
  @JoinColumn()
  wallet: Wallet;

  @OneToOne(() => User, (user) => user.driver, {
    nullable: true,
    cascade: true,
  })
  @JoinColumn()
  user: User;

  @ManyToOne(() => Organisation, (organisation) => organisation.driver)
  @JoinColumn()
  tenant: Organisation;

  @Column({ nullable: true })
  ssn: string;

  @Column({ nullable: true })
  secondary_phone: string;

  @Column({ nullable: true })
  secondary_code: string;

  @Column({ nullable: true })
  ddc_file_name: string;

  @Column({ nullable: true })
  credential_url: string;

  @Column({ type: "longtext", nullable: true })
  verification_token: string;

  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn()
  created_by: User;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn()
  updated_by: User;

  @Column({ nullable: true })
  middlename: string;

  @Column({ nullable: true })
  country_of_birth: string;

  @Column({ nullable: false, default: false })
  kyc_verified: boolean;

  @Column({ nullable: false, default: false })
  kyb_verified: boolean;

  @Column({ type: "enum", enum: ProfileStatusEnum })
  status: ProfileStatusEnum;

  @Column({ nullable: true })
  tnc_affiliation: string;

  @Column({ type: "boolean", nullable: true })
  english_fluency: boolean;

  @Column({ nullable: true })
  profile_pic: string;

  @Column({ nullable: false, default: false })
  profile_verified: boolean;

  // @Column({ type: "enum", enum: PreferredLanguageEnum, nullable: true })
  // preferred_language: PreferredLanguageEnum;
  @Column({ nullable: true })
  preferred_language: string;

  @Column({ nullable: true })
  other_language: string;

  @AfterLoad()
  async decryptData() {
    this.secondary_phone = this.secondary_phone ? await decryptChiper(this.secondary_phone):null;
  }

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.firstname !== undefined) this.firstname = data.firstname;
      if (data.lastname !== undefined) this.lastname = data.lastname;
      if (data.password !== undefined) this.password = data.password;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.dob !== undefined) this.dob = data.dob;
      if (data.gender !== undefined) this.gender = data.gender;
      if (data.otp !== undefined) this.otp = data.otp;
      if (data.mobile_verified !== undefined)
        this.mobile_verified = data.mobile_verified;
      if (data.email_verified !== undefined)
        this.email_verified = data.email_verified;
      if (data.entra_verified !== undefined)
        this.entra_verified = data.entra_verified;
      if (data.otp_expiry_time !== undefined)
        this.otp_expiry_time = data.otp_expiry_time;
      if (data.ddc !== undefined) this.ddc = data.ddc;
      if (data.is_password_confirmed !== undefined)
        this.is_password_confirmed = data.is_password_confirmed;
      if (data.wallet !== undefined) this.wallet = data.wallet;
      if (data.user !== undefined) this.user = data.user;
      if (data.tenant !== undefined) this.tenant = data.tenant;
      if (data.ddc_file_name !== undefined)
        this.ddc_file_name = data.ddc_file_name;
      if (data.credential_url !== undefined)
        this.credential_url = data.credential_url;
      if (data.verification_token !== undefined)
        this.verification_token = data.verification_token;
      if (data.address_line_1 !== undefined)
        this.address_line_1 = data.address_line_1;
      if (data.address_line_2 !== undefined)
        this.address_line_2 = data.address_line_2;
      if (data.city !== undefined) this.city = data.city;
      if (data.state !== undefined) this.state = data.state;
      if (data.zip_code !== undefined) this.zip_code = data.zip_code;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.middlename !== undefined) this.middlename = data.middlename;
      if (data.kyc_verified !== undefined) this.kyc_verified = data.kyc_verified;
      if (data.kyb_verified !== undefined) this.kyb_verified = data.kyb_verified;
      if (data.country_of_birth !== undefined) this.country_of_birth = data.country_of_birth;
      if (data.status !== undefined) this.status = data.status;
      if (data.ssn !== undefined) this.ssn = data.ssn;
      if (data.tnc_affiliation !== undefined) this.tnc_affiliation = data.tnc_affiliation;
      if (data.english_fluency !== undefined) this.english_fluency = data.english_fluency;
      if (data.secondary_phone !== undefined) this.secondary_phone = data.secondary_phone;
      if (data.secondary_code !== undefined) this.secondary_code = data.secondary_code;
      if (data.profile_pic !== undefined) this.profile_pic = data.profile_pic;
      if (data.profile_verified !== undefined) this.profile_verified = data.profile_verified;
      if (data.preferred_language !== undefined) this.preferred_language = data.preferred_language;
      if (data.other_language !== undefined) this.other_language = data.other_language;
      return this;
    }
  }
}
