import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { VehicleOwnerUsers } from "./vehicle_owner_users.entity";
import { ServiceProviderUsers } from "./service_provider_user.entity";
import { ServiceProviderTypes } from "../utils/db.enum";
import { ProfileDocument } from "./profile_document.entity";

@Entity()
export class ServiceProvider {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  business_name: string;

  @Column({ nullable: true })
  office_number: string;

  @Column({ nullable: true })
  office_code: string;

  @Column({ nullable: true })
  tax_id: string;

  @Column({ nullable: true })
  npi_number: string;

  @Column({ nullable: true })
  medical_provider_type: string;

  @Column({ nullable: true, type: "enum", enum: ServiceProviderTypes })
  service_provider_type: ServiceProviderTypes;

  @Column({ nullable: true })
  attorney_license_number: string;

  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: false })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @Column({ nullable: false })
  country: string;

  @OneToMany(
    () => ServiceProviderUsers,
    (serviceProvider) => serviceProvider.service_provider
  )
  service_provider_users: ServiceProviderUsers[];

  @ManyToOne(() => User, (user) => user.vehicle_owner)
  user: User;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToOne(() => User, (user) => user.id)
  updated_by: User;

  @Column({ type: "boolean", default: false })
  kyb_verified: boolean;

  @Column({ type: "boolean", default: false })
  is_individual: boolean;

  @OneToMany(() => ProfileDocument, (object) => object.service_provider)
  service_provider_docs: ProfileDocument[];

  public bind(data: any) {
    if (data) {
      if (data.tax_id !== undefined) this.tax_id = data.tax_id;
      if (data.country !== undefined) this.country = data.country;
      if (data.address_line_1 !== undefined)
        this.address_line_1 = data.address_line_1;
      if (data.address_line_2 !== undefined)
        this.address_line_2 = data.address_line_2;
      if (data.city !== undefined) this.city = data.city;
      if (data.state !== undefined) this.state = data.state;
      if (data.zip_code !== undefined) this.zip_code = data.zip_code;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.updated_by !== undefined) this.updated_by = data.updated_by;
      if (data.kyb_verified !== undefined)
        this.kyb_verified = data.kyb_verified;
      if (data.is_individual !== undefined)
        this.is_individual = data.is_individual;
      if (data.service_provider_docs !== undefined)
        this.service_provider_docs = data.service_provider_docs;
      return this;
    }
  }
}
