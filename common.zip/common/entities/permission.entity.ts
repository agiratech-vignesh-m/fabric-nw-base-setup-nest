import { Role } from "./role.entity";
import { User } from "./user.entity";
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from "typeorm";

@Entity()
@Unique("permission_type", ["permission", "module"])
export class Permissions {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: false })
  permission: string;

  @Column({ nullable: false })
  module: string;

  @ManyToMany(() => Role, role => role.permissions)
  roles: Role[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
