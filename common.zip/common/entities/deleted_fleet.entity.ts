import { Entity, Column, PrimaryGeneratedColumn, ManyToMany, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { Vehicle } from './vehicle.entity';
@Entity()
export class DeletedFleet {

        @PrimaryGeneratedColumn("uuid")
        id: string;

        @Column({ nullable: true })
        company_name: string;

        @Column({ nullable: true })
        phone: string;

        @Column({ nullable: true })
        email: string;

        @Column({ nullable: true })
        federal_id: string;

        @ManyToMany(() => Vehicle, (vehicle) => vehicle.fleet, { nullable: true })
        vehicles: Vehicle[];

        @Column({ nullable: true })
        address: string;

        @Column({ nullable: true })
        address_line2: string;

        @Column({ nullable: true })
        city: string;

        @Column({ nullable: true })
        state: string;

        @Column({ nullable: true })
        zip_code: string;

        @Column({ type: "boolean", default: true })
        is_active: boolean;

        @Column({ type: "boolean", default: false })
        is_delete: boolean;

        /* TODO */
        @Column({type:'json'})
        created_by: any;

        @CreateDateColumn()
        created_at: Date;

        @UpdateDateColumn()
        updated_at: Date;

        @Column({ nullable: true })
        contact_person: string; 

        @Column({ nullable: true })
        tax_id: string; 

        @Column({ nullable: true })
        office_number: string;

        @Column({ nullable: true })
        country_code: string;

        @Column({ nullable: true })
        tele_country_code: string;


        public bind(data: any) {
                if (data) {
                        if (data.id !==undefined) this.id = data.id;
                        if (data.company_name !==undefined) this.company_name = data.company_name;
                        if (data.phone !==undefined) this.phone = data.phone;
                        if (data.email !==undefined) this.email = data.email;
                        if (data.federal_id !==undefined) this.federal_id = data.federal_id;
                        if (data.address !==undefined) this.address = data.address;
                        if (data.address_line2 !==undefined) this.address_line2 = data.address_line2;
                        if (data.city !==undefined) this.city = data.city;
                        if (data.state !==undefined) this.state = data.state;
                        if (data.zip_code !==undefined) this.zip_code = data.zip_code;
                        if (data.is_active !==undefined) this.is_active = data.is_active;
                        if (data.is_delete !==undefined) this.is_delete = data.is_delete;
                        if (data.created_at !==undefined) this.created_at = data.created_at;
                        if (data.updated_at !==undefined) this.updated_at = data.updated_at;
                        if (data.created_by !==undefined) this.created_by = data.created_by;
                        if (data.contact_person !==undefined) this.contact_person = data.contact_person;
                        if (data.tax_id !==undefined) this.tax_id = data.tax_id;
                        if (data.office_number !==undefined) this.office_number = data.office_number;
                        if (data.country_code !==undefined) this.country_code = data.country_code;
                        if (data.tele_country_code !==undefined) this.tele_country_code = data.tele_country_code;
                        return this;
                }
        }
}