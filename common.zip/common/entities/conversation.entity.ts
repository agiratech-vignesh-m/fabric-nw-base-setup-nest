import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, CreateDateColumn, UpdateDateColumn, OneToMany, OneToOne, JoinColumn, ManyToMany } from 'typeorm';
import { User } from './user.entity';
import { Message } from './message.entity';


@Entity()
export class Conversation {

  @PrimaryGeneratedColumn("uuid")
  id: string;

  @ManyToMany(() => User, (user) => user.conversations)
  members: User[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @OneToOne(() => Message, { onDelete: "CASCADE" })
  @JoinColumn()
  last_message: Message;

  @OneToMany(() => User, (user) => user.id)
  is_deleted: User[];

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.members !== undefined) this.members = data.members;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.last_message !== undefined) this.last_message = data.last_message;
      if (data.is_deleted !== undefined) this.is_deleted = data.is_deleted;
      return this;
    }
  }
}