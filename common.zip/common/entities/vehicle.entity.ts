import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Fleet } from './fleet.entity';
import { Driver } from './driver.entity';
import { User } from './user.entity';
import { DriveCamEnum, ForwardCollisionWarningEnum, ProgressStatus, VehicleClassEnum } from 'src/utils/db.enum';
import { Dongle } from './dongle.entity';
import { VehicleOwner } from './vehicle-owner.entity';
import { VehiclePermit } from './vehicle_permit.entity';

@Entity()
export class Vehicle {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  vehicle_identification_number: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  number_plate: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  vehicle_make: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  vehicle_year: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  registration_type: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  vehicle_model: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  body_type: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  province: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  vehicle_pic: string;

  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @Column({ type: 'boolean', default: false })
  is_deleted: boolean;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToOne(() => User, (user) => user.id)
  updated_by: User;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ nullable: true })
  safety_rating: string;

  @Column({ nullable: true })
  seating_capacity: string;

  @Column({ nullable: true })
  weight: string;

  @Column({
    type: "enum",
    enum: VehicleClassEnum,
  })
  vehicle_class: VehicleClassEnum;

  @Column({ nullable: true })
  vehicle_license_number: string;

  @Column({ nullable: true })
  tlc_permit_license_number: string;


  @Column({ type: 'boolean', nullable: true })
  wheel_chair_accessibility: boolean;

  @Column({
    type: "enum",
    enum: DriveCamEnum,
    nullable: true,
  })
  driver_cam: DriveCamEnum;

  @OneToOne(() => Dongle, (name) => name.id)
  @JoinColumn()
  obd_plug_in: Dongle;


  @OneToOne(() => Dongle, (name) => name.id)
  @JoinColumn()
  dongle: Dongle;

  @Column({ type: 'boolean', nullable: true })
  black_box: boolean;

  @Column({ type: 'boolean', nullable: true })
  gps_navigation: boolean;

  @Column({ type: 'boolean', nullable: true })
  bluetooth: boolean;


  @Column({ type: 'boolean', nullable: true })
  automatic_braking: boolean;

  @Column({ type: 'boolean', nullable: true })
  lane_depature_control: boolean;

  @Column({
    type: "enum",
    enum: ForwardCollisionWarningEnum,
    nullable: true,
  })
  forward_collision_warning: ForwardCollisionWarningEnum;

  @Column({
    type: "enum",
    enum: ForwardCollisionWarningEnum,
    nullable: true,
  })
  lane_departure_warning: ForwardCollisionWarningEnum;


  @Column({ type: 'boolean', nullable: true })
  anti_lock_braking_system: boolean;

  @Column({ type: 'boolean', nullable: true })
  electronic_stability_control: boolean;

  @Column({ type: 'boolean', nullable: true })
  traction_control: boolean;

  @Column({ type: 'boolean', nullable: true })
  tyre_pressure_monitoring_system: boolean;


  @Column({ type: 'boolean', nullable: true })
  event_data_recorder: boolean;


  @Column({ type: 'boolean', nullable: true })
  automatic_pedestrian_alert_sound: boolean;

  @Column({ type: 'boolean', nullable: true })
  automatic_crash_notification: boolean;

@Column({ type: 'boolean', nullable: true })
  blind_spot_warning: boolean;

  @Column({ nullable: true })
  fuel_type: string;

  @Column({
    type: "enum",
    enum: ProgressStatus,
    default: ProgressStatus.PENDING,
  })
  status: ProgressStatus;

  @ManyToOne(() => User, (user) => user)
  user: User[];

  @ManyToOne(() => User, (user) => user.id)
  approved_by: User;

  @Column({ nullable: false, default: false, type: "boolean" })
  entra_verified: boolean;

  @ManyToMany(() => User, { nullable: true })
  @JoinTable()
  vehicle_owner: User[];

  @ManyToMany(() => User, { nullable: true })
  @JoinTable()
  registrant: User[];

  @ManyToMany(() => User, { nullable: true })
  @JoinTable()
  fleet: User[];

  @ManyToMany(() => Driver, { nullable: true })
  @JoinTable()
  driver: Driver[];

  @OneToMany(() => VehiclePermit, (vehiclePermit) => vehiclePermit.vehicle)
  dmv_license_plate_number: VehiclePermit[];

  @Column({ nullable: true })
  current_insurance_carrier: string

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.vehicle_identification_number !== undefined) this.vehicle_identification_number = data.vehicle_identification_number;
      if (data.number_plate !== undefined) this.number_plate = data.number_plate;
      if (data.vehicle_make !== undefined) this.vehicle_make = data.vehicle_make;
      if (data.vehicle_year !== undefined) this.vehicle_year = data.vehicle_year;
      if (data.registration_type !== undefined) this.registration_type = data.registration_type;
      if (data.vehicle_model !== undefined) this.vehicle_model = data.vehicle_model;
      if (data.body_type !== undefined) this.body_type = data.body_type;
      if (data.province !== undefined) this.province = data.province;
      if (data.vehicle_pic !== undefined) this.vehicle_pic = data.vehicle_pic;
      if (data.fleet !== undefined) this.fleet = data.fleet;
      if (data.driver !== undefined) this.driver = data.driver;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.safety_rating !== undefined) this.safety_rating = data.safety_rating;
      if (data.seating_capacity !== undefined) this.seating_capacity = data.seating_capacity;
      if (data.weight !== undefined) this.weight = data.weight;

      if (data.vehicle_class !== undefined) this.vehicle_class = data.vehicle_class;
      if (data.vehicle_license_number !== undefined) this.vehicle_license_number = data.vehicle_license_number;
      if (data.dmv_license_plate_number !== undefined) this.dmv_license_plate_number = data.dmv_license_plate_number;
      if (data.tlc_permit_license_number !== undefined) this.tlc_permit_license_number = data.tlc_permit_license_number;
      if (data.wheel_chair_accessibility !== undefined) this.wheel_chair_accessibility = data.wheel_chair_accessibility;
      if (data.driver_cam !== undefined) this.driver_cam = data.driver_cam;
      if (data.obd_plug_in !== undefined) this.obd_plug_in = data.obd_plug_in;
      if (data.dongle !== undefined) this.dongle = data.dongle;
      if (data.black_box !== undefined) this.black_box = data.black_box;
      if (data.gps_navigation !== undefined) this.gps_navigation = data.gps_navigation;
      if (data.bluetooth !== undefined) this.bluetooth = data.bluetooth;
      if (data.automatic_braking !== undefined) this.automatic_braking = data.automatic_braking;
      if (data.lane_depature_control !== undefined) this.lane_depature_control = data.lane_depature_control;
      if (data.forward_collision_warning !== undefined) this.forward_collision_warning = data.forward_collision_warning;
      if (data.lane_departure_warning !== undefined) this.lane_departure_warning = data.lane_departure_warning;
      if (data.anti_lock_braking_system !== undefined) this.anti_lock_braking_system = data.anti_lock_braking_system;
      if (data.electronic_stability_control !== undefined) this.electronic_stability_control = data.electronic_stability_control;
      if (data.traction_control !== undefined) this.traction_control = data.traction_control;
      if (data.tyre_pressure_monitoring_system !== undefined) this.tyre_pressure_monitoring_system = data.tyre_pressure_monitoring_system;
      if (data.event_data_recorder !== undefined) this.event_data_recorder = data.event_data_recorder;
      if (data.automatic_pedestrian_alert_sound !== undefined) this.automatic_pedestrian_alert_sound = data.automatic_pedestrian_alert_sound;
      if (data.automatic_crash_notification !== undefined) this.automatic_crash_notification = data.automatic_crash_notification;
      if (data.blind_spot_warning !== undefined) this.blind_spot_warning = data.blind_spot_warning;

      if (data.vehicle_owner !== undefined) this.vehicle_owner = data.vehicle_owner;
      if (data.fuel_type !== undefined) this.fuel_type = data.fuel_type;
      if (data.status !== undefined) this.status = data.status;
      if (data.user !== undefined) this.user = data.user;
      if (data.approved_by !== undefined) this.approved_by = data.approved_by;
      if (data.entra_verified !== undefined) this.entra_verified = data.entra_verified;
      if (data.registrant !== undefined) this.registrant = data.registrant;
      if (data.current_insurance_carrier !== undefined) this.current_insurance_carrier = data.current_insurance_carrier;
      if (data.updated_by !== undefined) this.updated_by = data.updated_by;
      return this;
    }
  }
}
