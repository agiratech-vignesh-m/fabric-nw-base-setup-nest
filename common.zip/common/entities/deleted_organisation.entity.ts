import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { Admin } from "./admin.entity";
import { Driver } from "./driver.entity";
import { Employee } from "./employee.entity";
import { Coupon } from "./coupon.entity";
import { User } from "./user.entity";

@Entity()
export class DeletedOrganisation {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: false })
  name: string;

  @OneToMany(() => Admin, (admin) => admin.tenant)
  admin: Admin[];

  @OneToMany(() => Driver, (driver) => driver.tenant)
  driver: Driver[];

  @OneToMany(() => Employee, (employee) => employee.tenant)
  employee: Employee[];

  @OneToMany(() => Coupon, (coupon) => coupon.tenant)
  coupons: Coupon[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // @ManyToOne(() => User, (user) => user.id)
  // created_by: User;
  @Column({type:'json'})
  created_by: any;

  public bind(data: any) {
    if (data) {
        if (data.id !==undefined) this.id = data.id;
        if (data.name !==undefined) this.name = data.name;
        if (data.admin !==undefined) this.admin = data.admin;
        if (data.driver !==undefined) this.driver = data.driver;
        if (data.employee !==undefined) this.employee = data.employee;
        if (data.coupons !==undefined) this.coupons = data.coupons;
        if (data.created_at !==undefined) this.created_at = data.created_at;
        if (data.updated_at !==undefined) this.updated_at = data.updated_at;
        if (data.created_by !==undefined) this.created_by = data.created_by;
        return this;
    }
}
}
