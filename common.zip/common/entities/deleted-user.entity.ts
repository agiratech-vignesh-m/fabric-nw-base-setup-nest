import { DeletedEmployee } from "./deleted.employee.entity";
import { DeletedBroker } from "./deleted_agent.entity";
import { DeletedDriver } from "./deleted_driver.entity";
import { Role } from "./role.entity";
import { SocketSession } from "./socket-session.entity";
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  JoinColumn,
} from "typeorm";

@Entity()
export class DeletedUser {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  password: string;

  @ManyToOne(() => Role, (role) => role.users)
  role: Role;

  @OneToMany(() => SocketSession, (socket) => socket.user)
  socket_session: SocketSession[];

  @ManyToOne(() => DeletedDriver, (driver) => driver.user, { nullable: true })
  @JoinColumn()
  driver: DeletedDriver;

  @OneToOne(() => DeletedEmployee, (employee) => employee.user, { nullable: true })
  employee: DeletedEmployee;

  @ManyToOne(() => DeletedBroker, (admin) => admin.user, { nullable: true })
  @JoinColumn()
  agent: DeletedBroker;

  @CreateDateColumn()
  created_at: Date;

  // @ManyToOne(() => User, (user) => user.id)
  // created_by: User;
  @Column({type:'json'})
  created_by: any;

  @UpdateDateColumn()
  updated_at: Date;

  public bind(data: any) {
    if (data) {
            if (data.id !== undefined) this.id = data.id;
            if (data.email !== undefined) this.email = data.email;
            if (data.password !== undefined) this.password = data.password;
            if (data.role !== undefined) this.role = data.role;
            if (data.socket_session !== undefined) this.socket_session = data.socket_session;
            if (data.driver !== undefined) this.driver = data.driver;
            if (data.employee !== undefined) this.employee = data.employee;
            if (data.agent !== undefined) this.agent = data.agent;
            if (data.created_at !== undefined) this.created_at = data.created_at;
            if (data.created_by !== undefined)this.created_by = data.created_by;
            if (data.updated_at !== undefined)this.updated_at = data.updated_at;

            return this;
    }
}
}
