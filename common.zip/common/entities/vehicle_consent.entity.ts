import {
  Column,
  CreateDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { Consent } from "./consent.entity";

@Entity()
export class VehicleConsent {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  license_number: string;

  @ManyToOne(() => Consent, (consent) => consent.driver_consent)
  consent: Consent;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}