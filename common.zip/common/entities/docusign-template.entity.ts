import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { AdminTemplate } from "./admin-template.entity";


@Entity()
export class DocusignTemplate {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  page_number: string;

  @Column({ nullable: true })
  template_id: string;

  @Column({ nullable: true })
  category: string;

  @ManyToOne(() => AdminTemplate, (template) => template.id,{ nullable: true })
  @JoinColumn()
  document: AdminTemplate;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, (user) => user.id,{ nullable: true })
  @JoinColumn()
  created_by: User;

  public bind(data: any) {
    if (data) {
      if (data.id !==undefined) this.id = data.id;
      if (data.page_number !==undefined) this.page_number = data.page_number;
      if (data.template_id !==undefined) this.template_id = data.template_id;
      if (data.category !==undefined) this.category = data.category;
      if (data.document !==undefined) this.document = data.document;
      if (data.created_at !==undefined) this.created_at = data.created_at;
      if (data.updated_at !==undefined) this.updated_at = data.updated_at;
      return this;
    }
  }
}

