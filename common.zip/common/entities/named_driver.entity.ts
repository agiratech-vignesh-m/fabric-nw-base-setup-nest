import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";

@Entity()
export class NamedDriverEntity {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  //VEHICLE	INSURED	OWNER_OR_REGISTRATION	INSURED_LICENSE	SCHEDULED_DRIVER	DRIVER_DMV	DRIVER_TLC

  @Column({ nullable: true })
  vehicle: string;

  @Column({ nullable: true })
  insured: string;

  @Column({ nullable: true })
  owner_or_registration: string;

  @Column({ nullable: true })
  insured_license: string;

  @Column({ nullable: true })
  scheduled_driver: string;

  @Column({ nullable: true })
  driver_dmv: string;

  @Column({ nullable: true })
  driver_tlc: string;

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.vehicle !== undefined) this.vehicle = data.vehicle;
      if (data.insured !== undefined) this.insured = data.insured;
      if (data.owner_or_registration !== undefined) this.owner_or_registration = data.owner_or_registration;
      if (data.insured_license !== undefined) this.insured_license = data.insured_license;
      if (data.scheduled_driver !== undefined) this.scheduled_driver = data.scheduled_driver;
      if (data.driver_dmv !== undefined) this.driver_dmv = data.driver_dmv;
      if (data.driver_tlc !== undefined) this.driver_tlc = data.driver_tlc;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;

      return this;
    }
  }
}
