import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { Broker } from "./agent.entity";
import { ProgressStatus } from "src/utils/db.enum";

@Entity()
export class AgentUsers {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @OneToOne(() => User, (user) => user.agent_user)
  @JoinColumn()
  user: User;

  @ManyToOne(() => Broker, (broker) => broker.agent_users)
  agent: Broker;

  @Column({
    type: "enum",
    enum: ProgressStatus,
    default: ProgressStatus.PENDING,
  })
  status: ProgressStatus;

  @ManyToOne(() => User, (user) => user.id)
  approved_by: User;

  @Column({ type: "boolean", default: false })
  is_admin: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.status !== undefined) this.status = data.status;
      if (data.user !== undefined) this.user = new User().bind({ id: data.id });
      if (data.agent !== undefined)
        this.agent = new Broker().bind({ id: data.agent });
      if (data.approved_by !== undefined)
        this.approved_by = new User().bind({ id: data.approved_by });
    }
  }
}
