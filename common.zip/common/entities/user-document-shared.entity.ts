import {
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { UserDocument } from './user-document.entity';
import { User } from './user.entity';

@Entity()
export class UserDocumentShared {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(type => User, user => user.user_document_shared)
  user: User;

  @ManyToOne(type => UserDocument, doc => doc.shared_with)
  user_document: UserDocument;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @CreateDateColumn()
  created_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.user !== undefined) this.user = data.user;
      if (data.user_document !== undefined) this.user_document = data.user_document;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;

      return this;
    }
  }
}