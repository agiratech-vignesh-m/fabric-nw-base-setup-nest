import { Driver } from "./driver.entity";
import { User } from "./user.entity";
import {
  Column,
  CreateDateColumn,
  Entity,
  Generated,
  ObjectId,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

@Entity()
export class Wallet {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ unique: true })
  @Generated("increment")
  derivePath: number;

  @Column({ type: "varchar", nullable: true })
  privateKey: string;

  @Column({ type: "varchar", nullable: true })
  publicKey: string;

  @OneToOne(() => Driver, (driver) => driver.wallet)
  driver: Driver;

  @Column({ type: "boolean", default: false })
  isActive: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
