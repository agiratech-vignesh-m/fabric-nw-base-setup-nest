import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./user.entity";
import { UserBadge } from "./user_badge.entity";
import { DriverConsent } from "./driver_consent.entity";
import { VehicleConsent } from "./vehicle_consent.entity";

@Entity()
export class Consent {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  driver_type: string;

  @OneToMany(() => DriverConsent, (driverConsent) => driverConsent.consent)
  driver_consent: DriverConsent[]; 

  @OneToMany(() => VehicleConsent, (vehicleConsent) => vehicleConsent.consent)
  vehicle_consent: VehicleConsent[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.driver_type !== undefined) this.driver_type = data.driver_type;
      if (data.driver_consent !== undefined) this.driver_consent = data.driver_consent;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      return this;
    }
  }
}
