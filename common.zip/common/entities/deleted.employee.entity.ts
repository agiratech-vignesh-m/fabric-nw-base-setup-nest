import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    OneToMany,
    OneToOne,
    JoinColumn,
  } from "typeorm";
  import { Organisation } from "./organisation.entity";
import { DeletedUser } from "./deleted-user.entity";
  
  @Entity()
  export class DeletedEmployee {
    @PrimaryGeneratedColumn("uuid")
    id: string;
  
    @Column({ nullable: true })
    firstname: string;
  
    @Column({ nullable: true })
    lastname: string;
  
    @Column({ nullable: true })
    email: string;
  
    @Column({ default: true, type: "boolean" })
    is_active: boolean;
  
    @Column({ nullable: true })
    otp: string;
  
    @Column({ nullable: false, default: false, type: "boolean" })
    email_verified: boolean;
  
    @Column({ nullable: true, type: "timestamp" })
    otp_expiry_time: Date;
  
    @Column({ nullable: true, default: false })
    is_password_confirmed: boolean;
  
    @Column({ type: "longtext", nullable: true })
    verification_token: string;
  
    @OneToOne(() => DeletedUser, (user) => user.driver, { nullable: true})
    @JoinColumn()
    user: DeletedUser;
  
    @ManyToOne(() => Organisation, (organisation) => organisation.employee)
    @JoinColumn()
    tenant: Organisation;
  
    @CreateDateColumn({ select: false })
    created_at: Date;
  
    @UpdateDateColumn()
    updated_at: Date;
  
    @ManyToOne(() => DeletedUser, { nullable: true })
    @JoinColumn()
    created_by: DeletedUser;
  }
  