import {
  Column,
  CreateDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Fleet } from './fleet.entity';
import { Driver } from './driver.entity';
import { User } from './user.entity';

@Entity()
export class DeletedVehicle {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  vehicle_identification_number: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  number_plate: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  vehicle_make: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  vehicle_year: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  registration_type: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  vehicle_model: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  body_type: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  province: string;

  @Column({ type: 'varchar', nullable: true, length: 255 })
  vehicle_pic: string;


  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @Column({ type: 'boolean', default: false })
  is_deleted: boolean;

  // @ManyToOne(() => User, (user) => user.id)
  // created_by: User;
  @Column({type:'json'})
  created_by: any;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ nullable: true })
  safety_rating: string;

  @Column({ nullable: true })
  seating_capacity: string;

  @Column({ nullable: true })
  weight: string;

  @ManyToMany(() => User,{ nullable: true })
  @JoinTable()
  fleet: User[];

  @ManyToMany(() => Driver,{ nullable: true })
  @JoinTable()
  driver: Driver[];

  public bind(data: any) {
    if (data) {
      if (data.id !==undefined) this.id = data.id;
      if (data.vehicle_identification_number !==undefined) this.vehicle_identification_number = data.vehicle_identification_number;
      if (data.number_plate !==undefined) this.number_plate = data.number_plate;
      if (data.vehicle_make !==undefined) this.vehicle_make = data.vehicle_make;
      if (data.vehicle_year !==undefined) this.vehicle_year = data.vehicle_year;
      if (data.registration_type !==undefined) this.registration_type = data.registration_type;
      if (data.vehicle_model !==undefined) this.vehicle_model = data.vehicle_model;
      if (data.body_type !==undefined) this.body_type = data.body_type;
      if (data.province !==undefined) this.province = data.province;
      if (data.vehicle_pic !==undefined) this.vehicle_pic = data.vehicle_pic;
      if (data.fleet !==undefined) this.fleet = data.fleet;
      if (data.driver !==undefined) this.driver = data.driver;
      if (data.is_active !==undefined) this.is_active = data.is_active;
      if (data.created_by !==undefined) this.created_by = data.created_by;
      if (data.created_at !==undefined) this.created_at = data.created_at;
      if (data.updated_at !==undefined) this.updated_at = data.updated_at;
      if (data.safety_rating !==undefined) this.safety_rating = data.safety_rating;
      if (data.seating_capacity !==undefined) this.seating_capacity = data.seating_capacity;
      if (data.weight !==undefined) this.weight = data.weight;

      return this;
    }
  }
}
