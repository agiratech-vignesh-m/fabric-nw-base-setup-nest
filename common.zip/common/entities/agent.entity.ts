import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
  JoinTable,
} from "typeorm";
import { Organisation } from "./organisation.entity";
import { User } from "./user.entity";
import { AgentUsers } from "./agent_user.entity";
import { Driver } from "./driver.entity";
import { ProfileDocument } from "./profile_document.entity";

@Entity()
export class Broker {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  firstname: string;

  @Column({ nullable: true })
  lastname: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column({ nullable: true })
  password: string;

  @Column({ nullable: false, default: false, type: "boolean" })
  email_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  mobile_verified: boolean;

  @Column({ nullable: true, default: false })
  is_password_confirmed: boolean;

  @Column({ nullable: true })
  primary_language: string;

  @Column({ nullable: true })
  company_name: string;

  @Column({ nullable: true })
  telephone: string;

  @Column({ nullable: true })
  contact_person: string;

  @Column({ nullable: true, unique: true })
  mobile_number: string;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true })
  tele_country_code: string;

  @Column({ nullable: true })
  federal_id: string; //tax_id

  @Column({ nullable: true })
  driver_license_number: string;

  @Column({ nullable: true })
  dfs_insurence_license: string;

  @ManyToOne(() => Organisation, (org) => org.id)
  organisation_id: Organisation;

  @Column({ default: true, type: "boolean" })
  is_active: boolean;

  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @Column({ nullable: true })
  otp: string;

  @Column({ nullable: true })
  business_name: string;

  @Column({ nullable: true })
  insurance_class: string;

  @Column({ nullable: true })
  business_email: string;

  @Column({ nullable: true })
  office_number: string;

  @Column({ nullable: true })
  office_number_code: string;

  @Column({ type: "boolean", default: false })
  kyb_verified: boolean;

  @Column({ nullable: true })
  address_line_one: string;

  @Column({ nullable: true })
  address_line_two: string;

  @Column({ nullable: true, type: "timestamp" })
  otp_expiry_time: Date;

  @OneToOne(() => User, (user) => user.agent, { nullable: true, cascade: true })
  @JoinColumn()
  user: User;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToOne(() => User, (user) => user.id)
  updated_by: User;

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ type: "longtext", nullable: true })
  verification_token: string;

  @OneToMany(() => AgentUsers, (agentUsers) => agentUsers.agent)
  agent_users: AgentUsers[];

  @Column({ type: "boolean", default: false })
  is_individual: boolean;

  @Column({ nullable: true })
  ny_license_number: string;

  @OneToMany(() => ProfileDocument, (object) => object.agent)
  agent_docs: ProfileDocument[];

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.email !== undefined) this.email = data.email;
      if (data.firstname !== undefined) this.firstname = data.firstname;
      if (data.lastname !== undefined) this.lastname = data.lastname;
      if (data.password !== undefined) this.password = data.password;
      if (data.email_verified !== undefined)
        this.email_verified = data.email_verified;
      if (data.mobile_verified !== undefined)
        this.mobile_verified = data.mobile_verified;
      if (data.is_password_confirmed !== undefined)
        this.is_password_confirmed = data.is_password_confirmed;
      if (data.primary_language !== undefined)
        this.primary_language = data.primary_language;
      if (data.company_name !== undefined)
        this.company_name = data.company_name;
      if (data.telephone !== undefined) this.telephone = data.telephone;
      if (data.contact_person !== undefined)
        this.contact_person = data.contact_person;
      if (data.mobile_number !== undefined)
        this.mobile_number = data.mobile_number;
      if (data.country_code !== undefined)
        this.country_code = data.country_code;
      if (data.tele_country_code !== undefined)
        this.tele_country_code = data.tele_country_code;
      if (data.federal_id !== undefined) this.federal_id = data.federal_id;
      if (data.driver_license_number !== undefined)
        this.driver_license_number = data.driver_license_number;
      if (data.dfs_insurence_license !== undefined)
        this.dfs_insurence_license = data.dfs_insurence_license;
      if (data.address_line_1 !== undefined)
        this.address_line_1 = data.address_line_1;
      if (data.address_line_2 !== undefined)
        this.address_line_2 = data.address_line_2;
      if (data.city !== undefined) this.city = data.city;
      if (data.state !== undefined) this.state = data.state;
      if (data.zip_code !== undefined) this.zip_code = data.zip_code;
      if (data.organisation_id !== undefined)
        this.organisation_id = data.organisation_id;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.user !== undefined) this.user = data.user;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.business_name !== undefined)
        this.business_name = data.business_name;
      if (data.insurance_class !== undefined)
        this.insurance_class = data.insurance_class;
      if (data.business_email !== undefined)
        this.business_email = data.business_email;
      if (data.office_number !== undefined)
        this.office_number = data.office_number;
      if (data.office_number_code !== undefined)
        this.office_number_code = data.office_number_code;
      if (data.address_line_one !== undefined)
        this.address_line_one = data.address_line_one;
      if (data.address_line_two !== undefined)
        this.address_line_two = data.address_line_two;
      if (data.verification_token !== undefined)
        this.verification_token = data.verification_token;
      if (data.is_individual !== undefined)
        this.is_individual = data.is_individual;
      if (data.ny_license_number !== undefined)
        this.ny_license_number = data.ny_license_number;
      if (data.kyb_verified !== undefined)
        this.kyb_verified = data.kyb_verified;
      if (data.agent_docs !== undefined) this.agent_docs = data.agent_docs;
      return this;
    }
  }
}
