import { User } from "src/common/entities/user.entity";
import { DeviceTypeEnum, ProgressStatus } from "src/utils/db.enum";
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  JoinColumn,
} from "typeorm";

@Entity()
export class Dongle {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({
    type: "enum",
    enum: DeviceTypeEnum,
    default: DeviceTypeEnum.DONGLE,
  })
  device_type: DeviceTypeEnum;

  // Fields for Dongle

  @Column({ nullable: true })
  dongle_make: string;

  @Column({ nullable: true })
  dongle_model: string;

  @Column({ nullable: true })
  serial_number: string;

  // Fields for OBD

  @Column({ nullable: true })
  obd_parameter_id: string;

  @Column({ nullable: true })
  obd_version: string;

  @Column({
    type: "enum",
    enum: ProgressStatus,
    default: ProgressStatus.PENDING,
  })
  status: ProgressStatus;

  @ManyToOne(() => User, (user) => user)
  user: User[];

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToOne(() => User, (user) => user.id)
  updated_by: User;

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, (user) => user.id)
  approved_by: User;

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.device_type !== undefined) this.device_type = data.device_type;
      if (data.dongle_make !== undefined) this.dongle_make = data.dongle_make;
      if (data.dongle_model !== undefined) this.dongle_model = data.dongle_model;
      if (data.serial_number !== undefined) this.serial_number = data.serial_number;
      if (data.obd_parameter_id !== undefined) this.obd_parameter_id = data.obd_parameter_id;
      if (data.obd_version !== undefined) this.obd_version = data.obd_version;
      if (data.user !== undefined) this.user = data.user;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.updated_by !== undefined) this.updated_by = data.updated_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.approved_by !== undefined) this.approved_by = data.approved_by;

      return this;
    }
  }
}
