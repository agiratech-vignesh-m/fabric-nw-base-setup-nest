import { ICredit } from "../utils/db.enum";
import { Address } from "./address.entity";
import { AdminTemplate } from "./admin-template.entity";
import { DeletedAddress } from "./deleted-address.entity";
import { DeletedAdminTemplate } from "./deleted-admin-template.entity";
import { DeletedUser } from "./deleted-user.entity";
import { DeletedVehicle } from "./deleted_vehicle.entity";
import { Organisation } from "./organisation.entity";
import { User } from "./user.entity";
import { UsersCoupons } from "./usersCoupons.entity";
import { Vehicle } from "./vehicle.entity";
import { Wallet } from "./wallet.entity";
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
} from "typeorm";

@Entity()
export class DeletedDriver {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  firstname: string;

  @Column({ nullable: true })
  lastname: string;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true})
  mobile_number: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  password: string;

  @Column({ default: true, type: "boolean" })
  is_active: boolean;

  @Column({ type: "date", nullable: true })
  dob: Date;

  @Column({ nullable: true })
  gender: string;

  @Column({ nullable: true })
  otp: string;

  @Column({ nullable: false, default: false, type: "boolean" })
  mobile_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  email_verified: boolean;

  @Column({ nullable: false, default: false, type: "boolean" })
  entra_verified: boolean;

  @Column({ nullable: true, type: "timestamp" })
  otp_expiry_time: Date;

  @Column({ nullable: true })
  ddc: string;

  @Column({ nullable: true, default: false })
  is_password_confirmed: boolean;

  @OneToOne(() => Wallet, (wallet) => wallet.driver)
  @JoinColumn()
  wallet: Wallet;

  @OneToMany(() => DeletedUser, (user) => user.agent, { nullable: true })
  user: DeletedUser;

  @OneToMany((type) => UsersCoupons, (usersCoupons) => usersCoupons.driver)
  usersCoupons: UsersCoupons[];

  @ManyToOne(() => Organisation, (organisation) => organisation.driver)
  @JoinColumn()
  tenant: Organisation;

  @Column({ nullable: true })
  driver_license_number: string;

  @Column({ nullable: true })
  hack_license_number: string;

  @Column({ nullable: true })
  home_phone: string;

  @Column({ nullable: true })
  office_phone: string;

  @Column({ nullable: true })
  base_name: string;

  @Column({ type: "enum", enum: ICredit, default: ICredit.NO })
  defensive_credit: ICredit;

  @Column({ type: "enum", enum: ICredit, default: ICredit.NO })
  safe_credit: ICredit;

  @Column({ nullable: true })
  experience: string;

  @Column({ nullable: true })
  ddc_file_name: string;

  @Column({ nullable: true })
  credential_url: string;

  @Column({ type: "longtext", nullable: true })
  verification_token: string;

  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // @ManyToOne(() => User, (user) => user.id)
  // created_by: User;

  @Column({type:'json'})
  created_by: any;

  @Column({ nullable: true })
  ssn: string;

  @Column({ nullable: true })
  middlename: string;

  @Column({ nullable: true })
  motorist_id_licensing_state: string;

  @Column({ nullable: true })
  license_issue_date: string;

  @Column({ nullable: true })
  license_expiration_date: string;

  @Column({ nullable: true })
  license_type: string;

  @Column({ nullable: true })
  hack_license_expiration_date: string;

  @ManyToMany(() => DeletedVehicle, (vehicle) => vehicle.fleet, { nullable: true })
  vehicles: DeletedVehicle[];

  public bind(data: any) {
    if (data) {
            if (data.id !==undefined) this.id = data.id;
            if (data.firstname !==undefined) this.firstname = data.firstname;
            if (data.lastname !==undefined) this.lastname = data.lastname;
            if (data.country_code !==undefined) this.country_code = data.country_code;
            if (data.mobile_number !==undefined) this.mobile_number = data.mobile_number;
            if (data.email !==undefined) this.email = data.email;
            if (data.password !==undefined) this.password = data.password;
            if (data.is_active !==undefined) this.is_active = data.is_active;
            if (data.dob !==undefined) this.dob = data.dob;
            if (data.gender !==undefined) this.gender = data.gender;
            if (data.otp !==undefined) this.otp = data.otp;
            if (data.mobile_verified !==undefined) this.mobile_verified = data.mobile_verified;
            if (data.email_verified !==undefined) this.email_verified = data.email_verified;
            if (data.entra_verified !==undefined) this.entra_verified = data.entra_verified;
            if (data.otp_expiry_time !==undefined) this.otp_expiry_time = data.otp_expiry_time;
            if (data.ddc !== undefined)this.ddc = data.ddc;
            if (data.is_password_confirmed !==undefined) this.is_password_confirmed = data.is_password_confirmed;
            if (data.wallet !==undefined) this.wallet = data.wallet;
            if (data.user !==undefined) this.user = data.user;
            if (data.usersCoupons !==undefined) this.usersCoupons = data.usersCoupons;
            if (data.tenant !==undefined) this.tenant = data.tenant;
            if (data.driver_license_number !==undefined) this.driver_license_number = data.driver_license_number;
            if (data.hack_license_number !==undefined) this.hack_license_number = data.hack_license_number;
            if (data.home_phone !==undefined) this.home_phone = data.home_phone;
            if (data.office_phone !==undefined) this.office_phone = data.office_phone;
            if (data.base_name !==undefined) this.base_name = data.base_name;
            if (data.defensive_credit !==undefined) this.defensive_credit = data.defensive_credit;
            if (data.safe_credit !==undefined) this.safe_credit = data.safe_credit;
            if (data.experience !==undefined) this.experience = data.experience;
            if (data.ddc_file_name !==undefined) this.ddc_file_name = data.ddc_file_name;
            if (data.credential_url !==undefined) this.credential_url = data.credential_url;
            if (data.verification_token !==undefined) this.verification_token = data.verification_token;
            if (data.address_line_1 !==undefined) this.address_line_1 = data.address_line_1;
            if (data.address_line_2 !==undefined) this.address_line_2 = data.address_line_2;
            if (data.city !==undefined) this.city = data.city;
            if (data.state !==undefined) this.state = data.state;
            if (data.zip_code !==undefined) this.zip_code = data.zip_code;
            if (data.created_at !==undefined) this.created_at = data.created_at;
            if (data.updated_at !==undefined) this.updated_at = data.updated_at;
            if (data.created_by !==undefined) this.created_by = data.created_by;
            if (data.ssn !==undefined) this.ssn = data.ssn;
            if (data.middlename !==undefined) this.middlename = data.middlename;
            if (data.motorist_id_licensing_state !==undefined) this.motorist_id_licensing_state = data.motorist_id_licensing_state;
            if (data.license_issue_date !==undefined) this.license_issue_date = data.license_issue_date;
            if (data.license_expiration_date !==undefined) this.license_expiration_date = data.license_expiration_date;
            if (data.license_type !==undefined) this.license_type = data.license_type;
            if (data.hack_license_expiration_date !==undefined) this.hack_license_expiration_date = data.hack_license_expiration_date;
            if (data.vehicles !==undefined) this.vehicles = data.vehicles;

            return this;
    }
}
}
