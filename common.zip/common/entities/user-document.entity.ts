import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { UserDocumentShared } from './user-document-shared.entity';
import { AdminTemplate } from './admin-template.entity';
import { User } from './user.entity';

@Entity()
export class UserDocument {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', nullable: false, length: 255 })
  url: string;

  @ManyToOne(() => AdminTemplate,(template) => {template.user_document},{ nullable: false },)
  @JoinColumn({name:'template'})
  template: AdminTemplate;

  @Column({ type: 'boolean', default: false })
  is_signed: boolean;

  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ nullable: true })
  envelope_id: string;

  @OneToMany(type => UserDocumentShared, doc => doc.user_document)
  shared_with: UserDocumentShared[];

  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;
      if (data.url !== undefined) this.url = data.url;
      if (data.template !== undefined) this.template = data.template;
      if (data.is_signed !== undefined) this.is_signed = data.is_signed;
      if (data.is_active !== undefined) this.is_active = data.is_active;
      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.envelope_id !== undefined) this.envelope_id = data.envelope_id;
      if (data.shared_with !== undefined) this.shared_with = data.shared_with;

      return this;
    }
  }
}