import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

@Entity()
export class Service {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  name: string;

  @Column({ type: "boolean", default: false })
  has_child: boolean;

  @Column({ type: "boolean", default: false })
  has_self: boolean;

  @Column({ type: "boolean", default: false })
  has_others: boolean;

  @Column({ type: "boolean", default: false })
  is_self_required: boolean;

  @Column({ type: "boolean", default: false })
  is_object: boolean;

  @OneToOne(() => Service, (service) => service.id)
  @JoinColumn()
  parent: Service;

  @UpdateDateColumn()
  updated_at: Date;
}
