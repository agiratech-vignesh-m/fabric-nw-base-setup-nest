import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { User } from "./user.entity";
import { IBadges } from "../utils/interface.utils";
import { QrCodeStatusEnum } from "src/utils/db.enum";

@Entity()
export class QrCode {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  pin: string;

  @Column({ type: "enum", enum: QrCodeStatusEnum })
  status: QrCodeStatusEnum;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn()
  user: User;

  @Column({ type: "enum", enum: IBadges })
  type: IBadges;

  @Column({ type: "timestamp" })
  expiry: Date;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn()
  created_by: User;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn()
  updated_by: User;

  public bind(data: any) {

  }
}