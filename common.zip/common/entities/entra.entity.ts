import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

@Entity()
export class Entra {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: true })
  requestId: string;

  @Column({ nullable: true })
  requestStatus: string;

  @Column({ nullable: true })
  state: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
