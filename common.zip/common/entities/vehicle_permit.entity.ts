import { User } from "src/common/entities/user.entity";
import { BaseTypeEnum, DeviceTypeEnum, ProgressStatus, VehicleClassEnum, VehicleTlcLicenseTypeEnum } from "src/utils/db.enum";
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  JoinColumn,
} from "typeorm";
import { Vehicle } from "./vehicle.entity";

@Entity()
export class VehiclePermit {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({
    nullable: true,
    type: "enum",
    enum: VehicleTlcLicenseTypeEnum,
  })
  vehicle_tlc_license_type: VehicleTlcLicenseTypeEnum;

  @Column({ nullable: true })
  vehicle_permit_license_number: string;

  @Column({ nullable: true })
  fhv_vehicle_license_number: string;

  @Column({ nullable: true })
  dmv_license_plate_number: string;

  @Column({
    nullable: true,
    type: "enum",
    enum: VehicleClassEnum,
  })
  vehicle_class: VehicleClassEnum;

  @Column({ nullable: true })
  permit_expiration_date: string;

  @Column({ nullable: true })
  license_name: string;


  //base_details

  @Column({ nullable: true })
  base_name: string;

  @Column({ nullable: true })
  base_number: string;

  @Column({
    nullable: true,
    type: "enum",
    enum: BaseTypeEnum,
  })
  base_type: BaseTypeEnum;

  @Column({ nullable: true })
  country_code: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  website: string;


  @Column({
    type: "enum",
    enum: ProgressStatus,
    default: ProgressStatus.PENDING,
  })
  status: ProgressStatus;

  @ManyToOne(() => User, (user) => user)
  user: User[];

  @ManyToOne(() => User, (user) => user.id)
  created_by: User;

  @ManyToOne(() => User, (user) => user.id)
  updated_by: User;

  @CreateDateColumn({ select: true })
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @ManyToOne(() => User, (user) => user.id)
  approved_by: User;


  @Column({ nullable: true })
  address_line_1: string;

  @Column({ nullable: true })
  address_line_2: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  state: string;

  @Column({ nullable: true })
  zip_code: string;

  @ManyToOne(() => Vehicle, (vehicle) => vehicle.dmv_license_plate_number)
  @JoinColumn()
  vehicle: Vehicle;


  public bind(data: any) {
    if (data) {
      if (data.id !== undefined) this.id = data.id;

      if (data.vehicle_tlc_license_type !== undefined) this.vehicle_tlc_license_type = data.vehicle_tlc_license_type;
      if (data.vehicle_permit_license_number !== undefined) this.vehicle_permit_license_number = data.vehicle_permit_license_number;
      if (data.fhv_vehicle_license_number !== undefined) this.fhv_vehicle_license_number = data.fhv_vehicle_license_number;
      if (data.dmv_license_plate_number !== undefined) this.dmv_license_plate_number = data.dmv_license_plate_number;
      if (data.vehicle_class !== undefined) this.vehicle_class = data.vehicle_class;
      if (data.permit_expiration_date !== undefined) this.permit_expiration_date = data.permit_expiration_date;
      if (data.license_name !== undefined) this.license_name = data.license_name;
      if (data.base_name !== undefined) this.base_name = data.base_name;
      if (data.base_number !== undefined) this.base_number = data.base_number;
      if (data.base_type !== undefined) this.base_type = data.base_type;
      if (data.country_code !== undefined) this.country_code = data.country_code;
      if (data.phone !== undefined) this.phone = data.phone;
      if (data.address !== undefined) this.address = data.address;
      if (data.website !== undefined) this.website = data.website;
      if (data.user !== undefined) this.user = data.user;
      if (data.status !== undefined) this.status = data.status;


      if (data.created_by !== undefined) this.created_by = data.created_by;
      if (data.updated_by !== undefined) this.updated_by = data.updated_by;
      if (data.created_at !== undefined) this.created_at = data.created_at;
      if (data.updated_at !== undefined) this.updated_at = data.updated_at;
      if (data.approved_by !== undefined) this.approved_by = data.approved_by;

      if (data.address_line_1 !== undefined) this.address_line_1 = data.address_line_1;
      if (data.address_line_2 !== undefined) this.address_line_2 = data.address_line_2;
      if (data.city !== undefined) this.city = data.city;
      if (data.state !== undefined) this.state = data.state;
      if (data.zip_code !== undefined) this.zip_code = data.zip_code;
      if (data.vehicle !== undefined) this.vehicle = data.vehicle;


      return this;
    }
  }
}
