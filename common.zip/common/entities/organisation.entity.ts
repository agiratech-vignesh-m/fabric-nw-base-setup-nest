import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { Admin } from "./admin.entity";
import { Driver } from "./driver.entity";
import { Employee } from "./employee.entity";
import { Coupon } from "./coupon.entity";

@Entity()
export class Organisation {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ nullable: false })
  name: string;

  @OneToMany(() => Admin, (admin) => admin.tenant)
  admin: Admin[];

  @OneToMany(() => Driver, (driver) => driver.tenant)
  driver: Driver[];

  @OneToMany(() => Employee, (employee) => employee.tenant)
  employee: Employee[];

  @OneToMany(() => Coupon, (coupon) => coupon.tenant)
  coupons: Coupon[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}
