import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { Organisation } from './organisation.entity';
import { User } from './user.entity';

@Entity()
export class TemplateName {

    @PrimaryGeneratedColumn("uuid")
    id: string;

    @Column({ nullable: true })
    name: string;

    @ManyToOne(() => User, (user) => user.id)
    created_by: User;

    @ManyToOne(() => Organisation, (org) => org.id)
    organisation_id: Organisation;

    @CreateDateColumn()
    created_at: Date;

    @UpdateDateColumn()
    updated_at: Date;

    public bind(data: any) {
        if (data) {
            if (data.id !==undefined) this.id = data.id;
            if (data.name !==undefined) this.name = data.name;
            if (data.organisation_id !==undefined) this.organisation_id = data.organisation_id;
            if (data.created_at !==undefined) this.created_at = data.created_at;
            if (data.updated_at !==undefined) this.updated_at = data.updated_at;
            if (data.created_by !==undefined) this.created_by = data.created_by;
            return this;
        }
    }
}