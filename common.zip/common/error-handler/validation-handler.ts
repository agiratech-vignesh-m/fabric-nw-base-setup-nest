import {
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
} from "@nestjs/common";
import { BaseExceptionFilter } from "@nestjs/core";
import { throwError } from "rxjs";

@Catch(HttpException)
export class ValidationExceptionFilter extends BaseExceptionFilter {
  catch(exception: HttpException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const status = exception.getStatus();

    if (status === HttpStatus.BAD_REQUEST) {
      return throwError({
        statusCode: status,
        message: exception.message
      });
    } else {
      super.catch(exception, host);
    }
  }
}
